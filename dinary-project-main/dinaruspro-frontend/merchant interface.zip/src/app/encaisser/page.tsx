// Fichier : src/app/encaisser/page.tsx

"use client";

import React, { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { QRCodeCanvas } from "qrcode.react";
import { useAuth } from "@/context/AuthContext";
import { v4 as uuidv4 } from "uuid";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";

// --- Interfaces et données ---
interface Product {
  id: string;
  name: string;
  price: number;
  category?: string;
  description?: string;
}
interface CartItem extends Product {
  quantity: number;
}

export default function EncaisserPage() {
  const { user, token } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoadingProducts, setIsLoadingProducts] = useState(true);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [customAmount, setCustomAmount] = useState("");
  const [showAmountModal, setShowAmountModal] = useState(false);
  const [showProductModal, setShowProductModal] = useState(false);
  const [showQRModal, setShowQRModal] = useState(false);
  const [paymentComplete, setPaymentComplete] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filter, setFilter] = useState("all");
  const [qrValue, setQrValue] = useState<string | null>(null);
  const [currentRequestId, setCurrentRequestId] = useState<string | null>(null);
  const pollingRef = useRef<NodeJS.Timeout>();

  const { isLoading: isAuthLoading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!isAuthLoading && user && user.verificationStatus !== "VERIFIED") {
      router.push("/verification");
    }
  }, [isAuthLoading, user, router]);

  // Chargement des produits du vendeur
  useEffect(() => {
    const fetchProducts = async () => {
      if (!token) return;
      setIsLoadingProducts(true);
      try {
        const apiUrl =
          process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001";
        const response = await fetch(`${apiUrl}/products`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (response.ok) setProducts(await response.json());
      } catch (error) {
        console.error("Erreur de récupération des produits:", error);
      } finally {
        setIsLoadingProducts(false);
      }
    };
    fetchProducts();
  }, [token]);

  // Détection automatique du paiement
  useEffect(() => {
    if (!showQRModal || !currentRequestId || !token) {
      if (pollingRef.current) clearInterval(pollingRef.current);
      return;
    }
    pollingRef.current = setInterval(async () => {
      try {
        const apiUrl =
          process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001";
        const response = await fetch(
          `${apiUrl}/wallet/payment-status/${currentRequestId}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        if (!response.ok) return;
        const data = await response.json();
        if (data.status === "completed") {
          clearInterval(pollingRef.current);
          setShowQRModal(false);
          setPaymentComplete(true);
        }
      } catch (error) {
        console.error("Erreur de polling:", error);
      }
    }, 2500);
    return () => {
      if (pollingRef.current) clearInterval(pollingRef.current);
    };
  }, [showQRModal, currentRequestId, token]);

  const customerPays = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const showNotification = (message: string, type = "success") => {
    // Tu peux implémenter un système de notification plus joli ici
    console.log(`Notification (${type}): ${message}`);
  };

  const addToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    showNotification(`${product.name} ajouté`);
  };

  const addCustomAmount = () => {
    if (!customAmount || parseFloat(customAmount) <= 0) {
      showNotification("Montant invalide", "error");
      return;
    }
    setCart([
      ...cart,
      {
        id: `custom-${Date.now()}`,
        name: "💲 Montant personnalisé",
        price: parseFloat(customAmount),
        quantity: 1,
        description: "Saisie manuelle",
        category: "custom",
      },
    ]);
    setCustomAmount("");
    setShowAmountModal(false);
    showNotification("Montant ajouté");
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) =>
          item.id === id
            ? { ...item, quantity: Math.max(0, item.quantity + delta) }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const removeCartItem = (id: string) =>
    setCart(cart.filter((item) => item.id !== id));

  const clearCart = () => {
    setCart([]);
    showNotification("Panier vidé");
  };

  // --- VERSION CORRIGÉE DE LA FONCTION ---
  const handleGenerateQR = () => {
    if (customerPays > 0 && user) {
      const paymentRequestId = uuidv4(); // Crée un ID unique pour cette demande
      const data = {
        merchantUserId: user.id, // On utilise l'ID de l'utilisateur connecté (le marchand)
        amount: parseFloat(customerPays.toFixed(2)),
        paymentRequestId: paymentRequestId, // On inclut cet ID
      };
      setQrValue(JSON.stringify(data)); // On met à jour la valeur du QR code
      setCurrentRequestId(paymentRequestId); // On stocke l'ID pour le suivi
      setShowQRModal(true); // On affiche la modale avec le QR code
    }
  };

  const handleCancelPayment = () => {
    if (pollingRef.current) clearInterval(pollingRef.current);
    setShowQRModal(false);
    setCurrentRequestId(null);
    setQrValue(null);
  };

  const startNewSale = () => {
    setPaymentComplete(false);
    setCart([]);
    setQrValue(null);
    setCurrentRequestId(null);
  };

  const filteredProducts = products.filter((p) =>
    searchTerm ? p.name.toLowerCase().includes(searchTerm.toLowerCase()) : true
  );

  if (isAuthLoading || !user || user.verificationStatus !== "VERIFIED") {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen text-center p-4">
        <Loader2 className="animate-spin text-blue-600 mb-4" size={32} />
        <h2 className="text-lg font-semibold">
          Vérification de votre statut...
        </h2>
        <p className="text-sm text-gray-500">
          Nous nous assurons que votre compte est autorisé à accéder à cette
          fonctionnalité.
        </p>
      </div>
    );
  }

  return (
    <main className="p-4 pb-32 bg-gradient-to-b from-white to-blue-50 min-h-screen max-w-md mx-auto">
      <header className="mb-6 relative">
        <Link
          href="/"
          className="absolute left-0 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center bg-white rounded-full shadow-md"
        >
          <span className="text-gray-600">←</span>
        </Link>
        <h1 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent text-center">
          Encaissement
        </h1>
      </header>
      <div className="bg-white rounded-xl p-4 shadow-md mb-6">
        <div className="flex justify-between items-center mb-3">
          <h2 className="font-bold text-gray-800 mx-auto">Mon panier</h2>
          {cart.length > 0 && (
            <button
              onClick={clearCart}
              className="text-xs text-red-500 font-medium"
            >
              Vider
            </button>
          )}
        </div>
        {cart.length === 0 ? (
          <div className="text-center py-4">
            <p className="text-sm text-gray-500">Votre panier est vide</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-36 overflow-y-auto mb-3">
            {cart.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between py-2 border-b border-gray-100 last:border-b-0"
              >
                <div className="flex-1">
                  <p className="text-sm font-medium">{item.name}</p>
                  <p className="text-xs text-gray-500">
                    {item.price} DA x {item.quantity}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex border border-gray-200 rounded-lg">
                    <button
                      onClick={() => updateQuantity(item.id, -1)}
                      className="px-2 text-gray-500"
                    >
                      -
                    </button>
                    <span className="px-2 text-sm">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.id, 1)}
                      className="px-2 text-gray-500"
                    >
                      +
                    </button>
                  </div>
                  <button
                    onClick={() => removeCartItem(item.id)}
                    className="text-red-400"
                  >
                    ✕
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
        {cart.length > 0 && (
          <>
            <div className="space-y-2 mt-4 pt-2 border-t border-gray-100">
              <div className="flex justify-between items-center text-sm">
                <span className="font-medium">Total client:</span>
                <span className="font-bold text-purple-600">
                  {customerPays.toFixed(2)} DA
                </span>
              </div>
            </div>
            {/* --- CORRECTION DU NOM DANS ONCLICK --- */}
            <button
              onClick={handleGenerateQR}
              className="w-full mt-4 py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-xl font-medium"
            >
              Encaisser {customerPays.toFixed(2)} DA
            </button>
          </>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <button
          onClick={() => setShowAmountModal(true)}
          className="bg-white p-5 rounded-xl shadow-md flex flex-col items-center justify-center"
        >
          <div className="text-3xl mb-2">💲</div>
          <div className="text-sm font-medium">Montant libre</div>
        </button>
        <button
          onClick={() => setShowProductModal(true)}
          className="bg-white p-5 rounded-xl shadow-md flex flex-col items-center justify-center"
        >
          <div className="text-3xl mb-2">🛒</div>
          <div className="text-sm font-medium">Ajouter produits</div>
        </button>
      </div>

      {showAmountModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-5 shadow-xl w-full max-w-md">
            <h2 className="text-xl font-bold mb-4 text-center">
              Montant personnalisé
            </h2>
            <div className="mb-6">
              <div className="relative mb-2">
                <input
                  type="number"
                  value={customAmount}
                  onChange={(e) => setCustomAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full px-4 py-4 text-3xl font-bold text-center border border-gray-300 rounded-xl"
                />
                <div className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 text-xl">
                  DA
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 mb-4">
                {[100, 200, 500, 1000, 1500, 2000].map((amount) => (
                  <button
                    key={amount}
                    onClick={() => setCustomAmount(amount.toString())}
                    className="py-2 bg-gray-100 rounded-lg text-sm"
                  >
                    {amount} DA
                  </button>
                ))}
              </div>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setShowAmountModal(false)}
                className="flex-1 py-3 border border-gray-300 rounded-lg"
              >
                Annuler
              </button>
              <button
                onClick={addCustomAmount}
                className="flex-1 py-3 bg-purple-600 text-white rounded-lg font-medium"
              >
                Ajouter au panier
              </button>
            </div>
          </div>
        </div>
      )}
      {showProductModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md max-h-[90vh] overflow-hidden flex flex-col">
            <div className="p-4 border-b border-gray-100 flex justify-between items-center">
              <h2 className="font-bold text-lg">
                Choisir dans votre inventaire
              </h2>
              <button
                onClick={() => setShowProductModal(false)}
                className="text-gray-400"
              >
                ✕
              </button>
            </div>
            <div className="p-4 border-b border-gray-100">
              <input
                type="text"
                placeholder="Rechercher un de vos produits..."
                className="w-full px-4 py-2 pl-10 rounded-lg bg-gray-100 text-sm"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex-1 overflow-y-auto p-4">
              {isLoadingProducts ? (
                <p className="text-center text-gray-500">Chargement...</p>
              ) : filteredProducts.length > 0 ? (
                <div className="grid grid-cols-2 gap-3">
                  {filteredProducts.map((product) => (
                    <div
                      key={product.id}
                      onClick={() => addToCart(product)}
                      className="bg-white border border-gray-100 rounded-xl p-3 cursor-pointer hover:shadow-md transition"
                    >
                      <div className="font-medium text-sm">{product.name}</div>
                      <div className="text-purple-600 font-bold">
                        {product.price} DA
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-gray-500">
                  Vous n'avez aucun produit dans votre boutique.
                </p>
              )}
            </div>
            <div className="p-4 border-t border-gray-100">
              <button
                onClick={() => setShowProductModal(false)}
                className="w-full py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-xl font-medium"
              >
                Terminer
              </button>
            </div>
          </div>
        </div>
      )}
      {showQRModal && qrValue && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white p-6 rounded-2xl text-center shadow-xl w-full max-w-xs animate-fade-in">
            <h2 className="text-lg font-bold mb-2">Scannez pour payer</h2>
            <p className="text-gray-600 text-sm mb-4">
              Total : {customerPays.toFixed(2)} DA
            </p>
            <div className="p-4 border rounded-xl shadow-inner inline-block">
              <QRCodeCanvas value={qrValue} size={180} />
            </div>
            <div className="mt-4 text-xs text-gray-400 flex items-center justify-center">
              <div className="w-3 h-3 border-2 border-purple-400 border-t-transparent rounded-full animate-spin mr-2"></div>
              En attente du paiement...
            </div>
            <button
              onClick={handleCancelPayment}
              className="mt-4 text-sm text-gray-500 font-semibold"
            >
              Annuler
            </button>
          </div>
        </div>
      )}
      {paymentComplete && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white p-6 rounded-2xl text-center shadow-xl w-80 max-w-[90%]">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-green-500 text-4xl">✓</span>
            </div>
            <h2 className="text-lg font-bold mb-1">Paiement reçu !</h2>
            <p className="text-gray-600 text-sm mb-4">
              Montant: {customerPays.toFixed(2)} DA
            </p>
            <div className="flex flex-col gap-2">
              <button
                onClick={startNewSale}
                className="w-full py-2 bg-purple-600 text-white rounded-lg"
              >
                Nouvelle vente
              </button>
              <Link
                href="/"
                className="w-full py-2 bg-gray-100 text-gray-800 rounded-lg text-center"
              >
                Retour
              </Link>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
