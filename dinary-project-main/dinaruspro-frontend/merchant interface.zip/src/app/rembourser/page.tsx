// src/app/rembourser/page.tsx

"use client";

import React, { useState, useEffect, useRef, useCallback } from "react";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { Html5Qrcode } from "html5-qrcode";
import { Loader2, CheckCircle, XCircle, RefreshCw, Upload } from "lucide-react";
import PageHeader from "@/components/layouts/PageHeader";
import { motion } from "framer-motion";

export default function RembourserPage() {
  const [transactionDetails, setTransactionDetails] = useState<any | null>(
    null
  );
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const { token } = useAuth();
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [cameras, setCameras] = useState([]);
  const [activeCameraId, setActiveCameraId] = useState<string | null>(null);

  const onScanSuccess = useCallback(
    async (decodedText: string) => {
      if (scannerRef.current?.isScanning) {
        await scannerRef.current.stop();
      }
      try {
        const data = JSON.parse(decodedText);
        if (data.transactionId && token) {
          setIsLoading(true);
          setError("");
          const res = await fetch(
            `${process.env.NEXT_PUBLIC_API_URL}/wallet/transaction/${data.transactionId}/details`,
            {
              headers: { Authorization: `Bearer ${token}` },
            }
          );
          if (!res.ok) {
            const errorData = await res.json();
            throw new Error(
              errorData.message ||
                "Impossible de récupérer les détails de la transaction."
            );
          }
          const details = await res.json();
          if (details.status === "refunded") {
            throw new Error("Cette transaction a déjà été remboursée.");
          }
          setTransactionDetails(details);
        } else {
          throw new Error("QR Code non reconnu par Dinary.");
        }
      } catch (e: any) {
        setError(e.message || "QR Code invalide.");
        setTimeout(() => setError(""), 4000);
        // Redémarrer le scanner en cas d'erreur
        if (activeCameraId) startScanner(activeCameraId);
      } finally {
        setIsLoading(false);
      }
    },
    [token, activeCameraId]
  );

  const startScanner = useCallback(
    async (deviceId: string) => {
      if (!scannerRef.current || scannerRef.current.isScanning) return;
      setError("");

      const config = { fps: 10, qrbox: { width: 250, height: 250 } };
      try {
        await scannerRef.current.start(
          { deviceId: { exact: deviceId } },
          config,
          onScanSuccess,
          (err) => {}
        );
      } catch (err) {
        setError(
          "Impossible de démarrer la caméra. Vérifiez les autorisations."
        );
      }
    },
    [onScanSuccess]
  );

  useEffect(() => {
    scannerRef.current = new Html5Qrcode("qr-reader", false);

    Html5Qrcode.getCameras()
      .then((devices) => {
        if (devices && devices.length) {
          setCameras(devices);
          const rearCamera =
            devices.find((d) => d.label.toLowerCase().includes("back")) ||
            devices[0];
          setActiveCameraId(rearCamera.id);
        } else {
          setError("Aucune caméra n'a été trouvée.");
        }
      })
      .catch(() =>
        setError(
          "Erreur d'accès aux caméras. Veuillez autoriser l'accès dans votre navigateur."
        )
      );

    return () => {
      if (scannerRef.current?.isScanning) {
        scannerRef.current.stop().catch(() => {});
      }
    };
  }, []);

  useEffect(() => {
    if (activeCameraId && !transactionDetails && !success) {
      startScanner(activeCameraId);
    }
  }, [activeCameraId, transactionDetails, success, startScanner]);

  const handleRefund = async () => {
    if (!transactionDetails?.id || !token) return;
    setIsLoading(true);
    setError("");
    setSuccess("");
    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/wallet/refund`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ transactionId: transactionDetails.id }),
        }
      );
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || "Le remboursement a échoué.");
      }
      setSuccess(data.message);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white min-h-screen">
      <PageHeader
        title="Remboursement"
        hasBackButton={true}
        backTo="/dashboard"
      />

      <div className="p-5 flex flex-col items-center">
        {success ? (
          <div className="text-center py-8 w-full max-w-sm">
            <CheckCircle className="mx-auto text-green-500 mb-4" size={48} />
            <h2 className="text-xl font-bold">Remboursement réussi</h2>
            <p className="text-gray-600 mt-2">{success}</p>
            <Link
              href="/dashboard"
              className="block w-full mt-6 py-3 bg-black text-white rounded-xl font-semibold"
            >
              Retour à l'accueil
            </Link>
          </div>
        ) : transactionDetails ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gray-50 p-5 rounded-xl w-full max-w-sm"
          >
            <h3 className="font-bold mb-4 text-center text-lg">
              Confirmer le remboursement
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Client:</span>{" "}
                <span className="font-medium">
                  {transactionDetails.clientName}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Montant:</span>{" "}
                <span className="font-medium">
                  {transactionDetails.amount} DA
                </span>
              </div>
              <div className="flex justify-between">
                <span>Date:</span>{" "}
                <span className="font-medium">
                  {new Date(transactionDetails.date).toLocaleDateString(
                    "fr-FR"
                  )}
                </span>
              </div>
            </div>
            {error && (
              <p className="text-red-500 text-center text-sm mt-4">{error}</p>
            )}
            <button
              onClick={handleRefund}
              disabled={isLoading}
              className="w-full mt-6 py-3 bg-red-500 text-white rounded-xl font-bold flex items-center justify-center"
            >
              {isLoading && <Loader2 className="animate-spin mr-2" />}
              {isLoading ? "Remboursement en cours..." : "Rembourser"}
            </button>
            <button
              onClick={() => {
                setTransactionDetails(null);
                setError("");
              }}
              className="w-full mt-2 py-2 text-gray-600"
            >
              Annuler
            </button>
          </motion.div>
        ) : (
          <>
            <div className="w-full max-w-sm aspect-square bg-gray-900 rounded-2xl overflow-hidden shadow-lg border-4 border-gray-200 relative">
              <div id="qr-reader"></div>
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-[70%] h-[70%] border-2 border-white/50 rounded-lg animate-pulse"></div>
              </div>
            </div>
            {error && <p className="text-red-500 text-center mt-4">{error}</p>}
            {isLoading && <Loader2 className="animate-spin mx-auto mt-8" />}
          </>
        )}
      </div>
    </div>
  );
}
