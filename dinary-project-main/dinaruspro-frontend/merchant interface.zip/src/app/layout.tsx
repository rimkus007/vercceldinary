// Fichier : dinaruspro-seller/src/app/layout.tsx

import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { AuthProvider } from "@/context/AuthContext";

// 1. On importe le composant BottomNavbar que tu as déjà créé
import BottomNavbar from "@/components/layouts/BottomNavbar";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Dinarus Pro",
  description: "Votre espace vendeur Dinarus",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr">
      <body className={inter.className}>
        <AuthProvider>
          {/* 2. On ajoute une div pour s'assurer que le contenu ne soit pas caché */}
          <div className="pb-16">{children}</div>

          {/* 3. On ajoute la barre de navigation ici */}
          <BottomNavbar />
        </AuthProvider>
      </body>
    </html>
  );
}
