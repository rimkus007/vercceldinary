"use client";

import React, { useState, useEffect } from "react";
import { Loader2 } from "lucide-react";

interface Product {
  id: string;
  name: string;
  price: number;
  description?: string | null;
  category?: string | null;
  stock?: number;
  emoji?: string;
}

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Omit<Product, "id">) => Promise<boolean>;
  product: Product | null;
}

export default function CreateProductModal({
  isOpen,
  onClose,
  onSave,
  product,
}: ModalProps) {
  const [formData, setFormData] = useState({
    name: "",
    price: "",
    description: "",
    stock: "",
    category: "", // On peut ajouter la gestion des catégories ici
    emoji: "📦",
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (isOpen) {
      if (product) {
        setFormData({
          name: product.name,
          price: product.price.toString(),
          description: product.description || "",
          stock: product.stock?.toString() || "",
          category: product.category || "",
          emoji: product.emoji || "📦",
        });
      } else {
        setFormData({
          name: "",
          price: "",
          description: "",
          stock: "",
          category: "",
          emoji: "📦",
        });
      }
      setError("");
    }
  }, [product, isOpen]);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.price || parseFloat(formData.price) <= 0) {
      setError("Veuillez remplir le nom et un prix valide.");
      return;
    }
    setIsLoading(true);
    setError("");

    const success = await onSave({
      name: formData.name,
      price: parseFloat(formData.price),
      description: formData.description,
      stock: parseInt(formData.stock) || 0,
      category: formData.category,
      emoji: formData.emoji,
    });

    setIsLoading(false);
    if (!success) {
      setError("Une erreur est survenue. Veuillez réessayer.");
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div
        className="bg-white rounded-2xl p-5 w-full max-w-md"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-bold">
            {product ? "Modifier le produit" : "Nouveau produit"}
          </h2>
          <button onClick={onClose} className="text-gray-400">
            ✕
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Nom du produit
            </label>
            <input
              name="name"
              type="text"
              value={formData.name}
              onChange={handleChange}
              className="w-full px-3 py-2 border rounded-lg"
              required
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Prix (DA)
              </label>
              <input
                name="price"
                type="number"
                value={formData.price}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg"
                required
                min="0"
                step="0.01"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Stock
              </label>
              <input
                name="stock"
                type="number"
                value={formData.stock}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg"
                min="0"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description (Optionnel)
            </label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              rows={3}
              className="w-full px-3 py-2 border rounded-lg"
            />
          </div>

          {error && <p className="text-red-500 text-sm">{error}</p>}

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border rounded-lg"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="px-4 py-2 bg-purple-600 text-white rounded-lg flex items-center disabled:opacity-50"
            >
              {isLoading && <Loader2 className="animate-spin mr-2" size={16} />}
              {isLoading ? "Sauvegarde..." : "Sauvegarder"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
