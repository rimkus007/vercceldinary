"use client";

import {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
  useRef,
} from "react";
import { useSearchParams, useRouter } from "next/navigation";

interface User {
  id: string;
  email: string;
  role: string; // <- élargi pour éviter les throws inutiles
  fullName: string;
  username: string;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);
const TOKEN_STORAGE_KEY = "dinary_admin_access_token";

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const searchParams = useSearchParams();
  const router = useRouter();
  const didInit = useRef(false); // évite un double run éventuel

  useEffect(() => {
    if (didInit.current) return;
    didInit.current = true;

    const verifyAdminAuth = async () => {
      let navigated = false; // pour ne pas faire setIsLoading(false) après nav

      try {
        const tokenFromUrl = searchParams.get("token");
        let sessionToken = localStorage.getItem(TOKEN_STORAGE_KEY);

        if (tokenFromUrl) {
          sessionToken = tokenFromUrl;
          localStorage.setItem(TOKEN_STORAGE_KEY, tokenFromUrl);
          // Nettoie l’URL sans query
          router.replace("/admin/dashboard");
        }

        if (!sessionToken) {
          // pas de token -> login
          navigated = true;
          router.push("/login");
          return;
        }

        const userRes = await fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/users/me`,
          { headers: { Authorization: `Bearer ${sessionToken}` } }
        );

        if (!userRes.ok) {
          // log utile pour debugger (CORS/401/500)
          const text = await userRes.text().catch(() => "");
          console.error("Auth /users/me failed:", userRes.status, text);
          throw new Error("Token invalide ou expiré");
        }

        const userData: User = await userRes.json();

        // adapte ce check selon ce que renvoie vraiment ton backend
        const role = (userData.role || "").toUpperCase();
        const isAdmin =
          role === "ADMIN" || role === "ROLE_ADMIN" || role === "SUPER_ADMIN";
        if (!isAdmin) {
          throw new Error("Accès non autorisé.");
        }

        setUser(userData);
        setToken(sessionToken);
      } catch (err) {
        console.error("Échec de la vérification:", err);
        localStorage.removeItem(TOKEN_STORAGE_KEY);
        navigated = true;
        router.push("/login");
      } finally {
        if (!navigated) setIsLoading(false);
      }
    };

    verifyAdminAuth();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // exécuter une seule fois

  const logout = () => {
    localStorage.removeItem(TOKEN_STORAGE_KEY);
    router.push("/login");
  };

  return (
    <AuthContext.Provider value={{ user, token, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth doit être utilisé dans un AuthProvider");
  }
  return context;
};
