// Fichier : src/app/boutique/page.tsx

"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import CreateProductModal from "@/components/modals/CreateProductModal";
import PromoBanner from "@/components/common/PromoBanner";

// --- INTERFACES ---
interface Product {
  id: string;
  name: string;
  price: number;
  description?: string;
  imageUrl?: string;
}

const BoutiquePage = () => {
  const { user, merchantProfile, isLoading, token, refreshUser } = useAuth(); // ✅ On récupère refreshUser
  const router = useRouter();

  const [activeTab, setActiveTab] = useState<
    "profile" | "products" | "settings"
  >("products");
  const [products, setProducts] = useState<Product[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // --- état du formulaire Paramètres ---
  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [address, setAddress] = useState("");
  const [description, setDescription] = useState("");
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState<string | null>(null);
  const [saveErr, setSaveErr] = useState<string | null>(null);

  useEffect(() => {
    if (merchantProfile) {
      setName(merchantProfile.name ?? "");
      setCategory(merchantProfile.category ?? "");
      setAddress(merchantProfile.address ?? "");
      setDescription(merchantProfile.description ?? "");
    }
  }, [merchantProfile]);

  useEffect(() => {
    const fetchProducts = async () => {
      if (!token) return;
      try {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/products`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        if (!response.ok) throw new Error("Erreur de chargement des produits.");
        const data = await response.json();
        setProducts(data);
      } catch (error) {
        console.error(error);
      }
    };
    if (token) {
      fetchProducts();
    }
  }, [token]);

  const handleProductCreated = (newProduct: Product) => {
    // Pour une meilleure UX, on ajoute le nouveau produit au début de la liste
    setProducts((prev) => [newProduct, ...prev]);
  };

  if (isLoading || !user || !merchantProfile) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const needsLocation = !merchantProfile.latitude || !merchantProfile.longitude;

  const storeData = {
    name: merchantProfile.name,
    category: merchantProfile.category || "Restaurant & Café",
    address: merchantProfile.address || "Adresse non fournie",
    phone: user.phoneNumber || "Téléphone non fourni",
    email: user.email,
    owner: user.fullName,
  };

  // --- sauvegarde infos boutique ---
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setSaving(true);
    setSaveErr(null);
    setSaveMsg(null);
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/merchants/me`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ name, category, address, description }),
        }
      );
      const body = await res
        .json()
        .catch(() => ({ message: "Réponse invalide du serveur" }));
      if (!res.ok) {
        throw new Error(body.message || "Échec de la mise à jour");
      }
      setSaveMsg("Informations mises à jour ✅");

      // ✅ On actualise les données pour voir les changements partout
      await refreshUser();

      setTimeout(() => {
        setSaveMsg(null);
      }, 2000);
    } catch (err: any) {
      setSaveErr(err.message || "Erreur inconnue");
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      {isModalOpen && (
        <CreateProductModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onSave={handleProductCreated} // On passe la fonction de sauvegarde
          product={null} // Pour la création, on ne passe pas de produit
        />
      )}

      <main className="p-4 pb-20 bg-gray-50 min-h-screen max-w-md mx-auto">
        <header className="mb-6">
          <h1 className="font-bold text-xl text-center">Ma Boutique</h1>
        </header>

        {needsLocation && (
          <div className="mb-5">
            <PromoBanner
              title="Finalisez votre profil !"
              description="Définissez votre emplacement pour être visible par les clients sur la carte."
              emoji="📍"
              actionLabel="Définir mon emplacement"
              action={() => router.push("/boutique/emplacement")}
              bgColor="bg-amber-50"
              textColor="text-amber-800"
            />
          </div>
        )}

        <section className="bg-white rounded-lg p-4 shadow-sm mb-5 text-center">
          <div className="flex flex-col items-center gap-3 mb-4">
            <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center text-3xl">
              <span>{storeData.name.charAt(0)}</span>
            </div>
            <div>
              <h2 className="font-bold text-lg">{storeData.name}</h2>
              <p className="text-sm text-gray-500">{storeData.category}</p>
            </div>
          </div>
        </section>

        {/* ✅ Onglets : Informations / Produits / Paramètres (design restauré) */}
        <div className="flex border-b mb-5">
          <button
            onClick={() => setActiveTab("profile")}
            className={`flex-1 py-2 text-center text-sm ${
              activeTab === "profile"
                ? "border-b-2 border-blue-500 font-medium text-blue-600"
                : "text-gray-500"
            }`}
          >
            Informations
          </button>
          <button
            onClick={() => setActiveTab("products")}
            className={`flex-1 py-2 text-center text-sm ${
              activeTab === "products"
                ? "border-b-2 border-blue-500 font-medium text-blue-600"
                : "text-gray-500"
            }`}
          >
            Produits
          </button>
          <button
            onClick={() => setActiveTab("settings")}
            className={`flex-1 py-2 text-center text-sm ${
              activeTab === "settings"
                ? "border-b-2 border-blue-500 font-medium text-blue-600"
                : "text-gray-500"
            }`}
          >
            Paramètres
          </button>
        </div>

        {activeTab === "profile" && (
          <div className="bg-white rounded-xl p-4 shadow-sm animate-fade-in">
            <h2 className="font-bold mb-4">Informations de la boutique</h2>
            <div className="space-y-4">
              <div className="text-center">
                <p className="text-sm font-medium">Adresse</p>
                <p className="text-sm text-gray-600 mt-1">
                  {storeData.address}
                </p>
              </div>
              <div className="text-center">
                <p className="text-sm font-medium">Contact</p>
                <p className="text-sm text-gray-600 mt-1">{storeData.phone}</p>
                <p className="text-sm text-gray-600">{storeData.email}</p>
              </div>
              <div className="text-center">
                <p className="text-sm font-medium">Propriétaire</p>
                <p className="text-sm text-gray-600 mt-1">{storeData.owner}</p>
              </div>

              <div className="mt-4 text-center">
                <button
                  onClick={() => setActiveTab("settings")}
                  className="px-4 py-2 rounded-lg bg-gray-900 text-white text-sm font-semibold"
                >
                  Modifier mes informations
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ✅ Onglet Produits restauré */}
        {activeTab === "products" && (
          <div className="bg-white rounded-xl p-4 shadow-sm animate-fade-in">
            <div className="flex justify-between items-center mb-4">
              <h2 className="font-bold">Nos produits</h2>
              <button
                onClick={() => setIsModalOpen(true)}
                className="text-xs bg-blue-500 text-white px-3 py-1.5 rounded-lg hover:bg-blue-600 font-semibold"
              >
                + Ajouter
              </button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {products.length > 0 ? (
                products.map((product) => (
                  <div
                    key={product.id}
                    className="bg-gray-50 p-2 rounded-lg border border-gray-100"
                  >
                    <div className="bg-gray-200 h-24 rounded-md mb-2 flex items-center justify-center text-gray-400">
                      <span className="text-3xl">🛍️</span>
                    </div>
                    <div>
                      <h3 className="font-medium text-sm truncate">
                        {product.name}
                      </h3>
                      <p className="font-bold text-sm mt-1">
                        {product.price.toFixed(2)} DA
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="col-span-2 text-center text-sm text-gray-500 py-8">
                  <p className="font-semibold mb-2">
                    Aucun produit pour le moment
                  </p>
                  <p>
                    Cliquez sur “+ Ajouter” pour créer votre premier produit.
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === "settings" && (
          <div className="bg-white rounded-xl p-4 shadow-sm animate-fade-in">
            <h2 className="font-bold mb-4">Paramètres de la boutique</h2>

            <form onSubmit={handleSaveSettings} className="space-y-3">
              <div>
                <label className="block text-sm font-medium mb-1">Nom</label>
                <input
                  className="w-full p-3 bg-gray-50 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Nom de la boutique"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">
                  Catégorie
                </label>
                <input
                  className="w-full p-3 bg-gray-50 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  placeholder="Ex: Restaurant, Café…"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">
                  Adresse
                </label>
                <input
                  className="w-full p-3 bg-gray-50 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Adresse"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">
                  Description
                </label>
                <textarea
                  className="w-full p-3 bg-gray-50 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Décrivez votre commerce…"
                />
              </div>

              {saveErr && <p className="text-sm text-red-600">{saveErr}</p>}
              {saveMsg && <p className="text-sm text-green-600">{saveMsg}</p>}

              <button
                type="submit"
                disabled={saving}
                className="w-full py-3 bg-black text-white rounded-xl font-semibold disabled:opacity-50"
              >
                {saving ? "Enregistrement..." : "Enregistrer les informations"}
              </button>
            </form>

            {/* ✅ Section "Localisation" restaurée */}
            <div className="mt-6">
              <h3 className="font-medium mb-2">Localisation</h3>
              <p className="text-sm text-gray-600 mb-3">
                Vous pouvez mettre à jour l’emplacement exact de votre boutique.
              </p>
              <button
                onClick={() => router.push("/boutique/emplacement")}
                className="w-full py-3 bg-gray-900 text-white rounded-xl font-semibold"
              >
                Changer ma localisation
              </button>
            </div>
          </div>
        )}
      </main>
    </>
  );
};

export default BoutiquePage;
