// Fichier : src/app/boutique/emplacement/page.tsx

"use client";

import React, { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import PageHeader from "@/components/layouts/PageHeader";
import dynamic from "next/dynamic";
import { useAuth } from "@/context/AuthContext";

const LocationSetter = dynamic(
  () => import("@/components/common/LocationSetter"),
  {
    ssr: false,
    loading: () => (
      <div className="h-[400px] bg-gray-100 rounded-xl flex items-center justify-center">
        <p>Chargement de la carte...</p>
      </div>
    ),
  }
);

export default function EmplacementPage() {
  const [position, setPosition] = useState<[number, number] | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [addressPreview, setAddressPreview] = useState(
    "Détection de l'adresse..."
  );
  const { token, refreshUser } = useAuth(); // ✅ On récupère refreshUser
  const router = useRouter();
  const geocodeTimer = useRef<NodeJS.Timeout | null>(null);

  // Géolocalisation initiale
  useEffect(() => {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const initialPos: [number, number] = [
          pos.coords.latitude,
          pos.coords.longitude,
        ];
        setPosition(initialPos);
        reverseGeocode(initialPos[0], initialPos[1]); // On cherche l'adresse initiale
      },
      () => {
        setPosition([43.70313, 7.26608]); // Fallback sur Nice
      }
    );
  }, []);

  // Fonction pour convertir les coordonnées en adresse (pour l'aperçu)
  const reverseGeocode = async (lat: number, lng: number) => {
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&accept-language=fr`
      );
      if (!response.ok) return;
      const data = await response.json();
      setAddressPreview(data.display_name || "Adresse non trouvée");
    } catch (error) {
      setAddressPreview("Impossible de récupérer l'adresse");
    }
  };

  const handlePositionChange = (lat: number, lng: number) => {
    setPosition([lat, lng]);
    // On attend un peu avant de chercher l'adresse pour ne pas surcharger l'API
    if (geocodeTimer.current) clearTimeout(geocodeTimer.current);
    geocodeTimer.current = setTimeout(() => {
      reverseGeocode(lat, lng);
    }, 500); // Délai de 500ms
  };

  const handleSaveLocation = async () => {
    if (!position || !token) return;
    setIsLoading(true);

    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/merchants/me/location`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            latitude: position[0],
            longitude: position[1],
          }),
        }
      );

      if (!response.ok) {
        throw new Error("La sauvegarde a échoué.");
      }

      // ✅ LA CORRECTION MAGIQUE EST ICI !
      await refreshUser(); // On actualise les données du marchand dans toute l'app

      setTimeout(() => router.push("/boutique"), 1500);
    } catch (err) {
      // Gérer l'erreur
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white min-h-screen mb-16">
      <PageHeader
        title="Mon Emplacement"
        emoji="📍"
        hasBackButton={true}
        backTo="/boutique"
      />
      <div className="px-5 py-4">
        <div className="bg-blue-50 border border-blue-100 rounded-xl p-4 mb-6">
          <h3 className="font-bold text-blue-900 mb-1">
            Définissez votre position
          </h3>
          <p className="text-sm text-blue-800">
            Faites glisser le marqueur pour indiquer l'emplacement exact de
            votre commerce.
          </p>
        </div>

        {position ? (
          <LocationSetter
            initialPosition={position}
            onPositionChange={handlePositionChange}
          />
        ) : (
          <div className="h-[400px] bg-gray-100 rounded-xl flex items-center justify-center">
            <p>Détection de votre position...</p>
          </div>
        )}

        <div className="text-center mt-3 bg-gray-50 p-2 rounded-lg">
          <p className="text-xs text-gray-500">Aperçu de l'adresse</p>
          <p className="text-sm font-medium">{addressPreview}</p>
        </div>

        <button
          onClick={handleSaveLocation}
          disabled={isLoading || !position}
          className="w-full mt-6 py-3 bg-black text-white rounded-xl font-medium disabled:opacity-50"
        >
          {isLoading ? "Enregistrement..." : "Enregistrer mon emplacement"}
        </button>
      </div>
    </div>
  );
}
