// src/app/page.tsx

"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";

export default function RootPage() {
  const router = useRouter();
  const { token, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading) {
      if (token) {
        // L'utilisateur est connecté, le rediriger vers le tableau de bord
        router.push("/dashboard");
      } else {
        // L'utilisateur n'est pas connecté, le rediriger vers la page de login externe
        // Remplacez l'URL ci-dessous par l'adresse de votre page de connexion
        window.location.href = "http://localhost:3001/login";
      }
    }
  }, [token, isLoading, router]);

  // Affiche un état de chargement pendant la vérification
  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
    </div>
  );
}
