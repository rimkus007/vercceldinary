// Fichier : src/app/rewards/page.tsx

"use client";

import React, { useState, useEffect, useRef, useCallback } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { Loader2 } from "lucide-react";

// --- INTERFACES POUR LES DONNÉES DYNAMIQUES ---
interface Referral {
  id: string;
  fullName: string;
  createdAt: string;
}

interface ReferralData {
  referralCode: string;
  referrals: Referral[];
  totalEarned: number;
}

// Données statiques pour les éléments non encore dynamiques
const badges = [
  { id: 1, name: "Premier paiement", icon: "🥇", unlocked: true },
  { id: 2, name: "Top 10 commerçants", icon: "🔥", unlocked: false },
  { id: 3, name: "Niveau 5", icon: "🚀", unlocked: true },
];

const missions = [
  { id: 1, name: "Effectuer 3 encaissements", progress: 2, total: 3 },
  { id: 2, name: "Inviter un commerçant", progress: 0, total: 1 },
];

const bonuses = [
  { milestone: 3, reward: "500 points", achieved: true },
  { milestone: 5, reward: "1000 points", achieved: false },
  { milestone: 10, reward: "Statut VIP", achieved: false },
];

const RewardsPage = () => {
  const { token } = useAuth();
  const searchParams = useSearchParams();
  const tabParam = searchParams.get("tab");

  const [activeTab, setActiveTab] = useState(tabParam || "missions");
  const [referralData, setReferralData] = useState<ReferralData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showCopied, setShowCopied] = useState(false);
  const referralCodeRef = useRef(null);

  // --- NOUVEAU : Récupération des données de parrainage ---
  const fetchReferralData = useCallback(async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/users/me/referral-details`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      if (response.ok) {
        const data = await response.json();
        setReferralData(data);
      } else {
        console.error("Erreur de récupération des données de parrainage.");
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  }, [token]);

  useEffect(() => {
    fetchReferralData();
  }, [fetchReferralData]);

  useEffect(() => {
    if (showCopied) {
      const timer = setTimeout(() => setShowCopied(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [showCopied]);

  const copyReferralCode = () => {
    if (referralData?.referralCode) {
      navigator.clipboard.writeText(referralData.referralCode);
      setShowCopied(true);
    }
  };

  const totalPoints = 320;
  const badgesUnlocked = badges.filter((b) => b.unlocked).length;
  const missionsCompleted = missions.filter(
    (m) => m.progress >= m.total
  ).length;

  return (
    <main className="p-4 pb-24 bg-white min-h-screen text-gray-800 font-sans relative">
      {showCopied && (
        <div className="fixed bottom-20 left-1/2 transform -translate-x-1/2 bg-green-600 text-white px-4 py-2 rounded-lg text-sm shadow-lg animate-bounce z-50">
          Code copié avec succès!
        </div>
      )}

      <section className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-2">
          <Link
            href="/"
            className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-blue-600 text-white flex items-center justify-center shadow-sm"
          >
            ←
          </Link>
          <div>
            <p className="font-medium text-purple-800">Récompenses</p>
            <p className="text-xs text-gray-500">
              {totalPoints} points accumulés
            </p>
          </div>
        </div>
      </section>

      <section className="mb-6 bg-gradient-to-r from-indigo-400 to-purple-500 shadow-md rounded-xl p-4 text-white">
        <div className="grid grid-cols-3 gap-3 mt-4">
          <div className="bg-white/20 rounded-lg p-2 text-center">
            <p className="text-2xl">
              {badgesUnlocked}/{badges.length}
            </p>
            <p className="text-xs mt-1">Badges</p>
          </div>
          <div className="bg-white/20 rounded-lg p-2 text-center">
            <p className="text-2xl">
              {missionsCompleted}/{missions.length}
            </p>
            <p className="text-xs mt-1">Missions</p>
          </div>
          <div className="bg-white/20 rounded-lg p-2 text-center">
            <p className="text-2xl">{referralData?.referrals?.length || 0}</p>
            <p className="text-xs mt-1">Parrainages</p>
          </div>
        </div>
      </section>

      <div className="flex overflow-x-auto gap-2 mb-4 pb-1">
        <button
          onClick={() => setActiveTab("parrainage")}
          className={`px-4 py-2 rounded-full text-sm whitespace-nowrap transition ${
            activeTab === "parrainage"
              ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-md"
              : "bg-gray-100 text-gray-700"
          }`}
        >
          👥 Parrainage
        </button>
      </div>

      {activeTab === "parrainage" && (
        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-10">
              <Loader2 className="animate-spin text-purple-600" />
            </div>
          ) : referralData ? (
            <>
              <div className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm">
                <h2 className="font-bold text-gray-800 mb-3">
                  Votre code de parrainage
                </h2>
                <div className="flex bg-gray-50 border border-gray-100 rounded-lg overflow-hidden">
                  <div
                    ref={referralCodeRef}
                    className="bg-gray-50 py-2 px-4 flex-grow text-center font-mono"
                  >
                    {referralData.referralCode}
                  </div>
                  <button
                    onClick={copyReferralCode}
                    className="px-4 bg-gradient-to-r from-blue-500 to-purple-500 text-white"
                  >
                    Copier
                  </button>
                </div>
              </div>

              <div className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm">
                <div className="flex items-center justify-between mb-3">
                  <h2 className="font-bold text-gray-800">Vos parrainages</h2>
                  <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full">
                    {referralData.referrals.length} complétés
                  </span>
                </div>

                <div className="space-y-2">
                  {referralData.referrals.map((friend) => (
                    <div
                      key={friend.id}
                      className="flex items-center justify-between border-b border-gray-50 last:border-0 py-2"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                          {friend.fullName.charAt(0)}
                        </div>
                        <div>
                          <p className="font-medium text-sm">
                            {friend.fullName}
                          </p>
                          <p className="text-xs text-gray-500">
                            {new Date(friend.createdAt).toLocaleDateString(
                              "fr-FR"
                            )}
                          </p>
                        </div>
                      </div>
                      <div className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">
                        Complété
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <p className="text-center text-gray-500">
              Impossible de charger les données de parrainage.
            </p>
          )}
        </div>
      )}
    </main>
  );
};

export default RewardsPage;
