"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";

// --- INTERFACES POUR LES DONNÉES DYNAMIQUES ---
// On s'assure que les types correspondent à ce que le backend envoie
interface Transaction {
  id: string;
  amount: number;
  user: string;
  type: string;
  date: string;
}

interface DashboardData {
  balance: number;
  xp: number;
  level: number;
  nextLevelXP: number; // Nommé xpMax dans ton JSX original, on l'adapte
  missionProgress: number;
  missionTotal: number;
  recentTransactions: Transaction[];
  // On peut ajouter d'autres champs statiques pour le moment
  totalPoints: number;
  badgesUnlocked: number;
}

const DashboardPage = () => {
  // --- GESTION DES DONNÉES ET DE L'AUTHENTIFICATION ---
  const { merchantProfile, isLoading: isAuthLoading, token } = useAuth();
  const [data, setData] = useState<DashboardData | null>(null);
  const [isLoadingData, setIsLoadingData] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Le reste de tes états pour l'UI
  const [animateXP, setAnimateXP] = useState(false);
  const [showNotification, setShowNotification] = useState<string | null>(null);
  const [currentDate, setCurrentDate] = useState<string>("");

  useEffect(() => {
    // --- APPEL À L'API POUR LES DONNÉES DYNAMIQUES ---
    const fetchDashboardData = async () => {
      if (!token) {
        setIsLoadingData(false);
        setError("Token d'authentification manquant.");
        return;
      }
      try {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/merchants/dashboard`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        if (!response.ok) {
          throw new Error(
            "Impossible de charger les données du tableau de bord."
          );
        }
        const apiData = await response.json();
        // On fusionne les données de l'API avec des données statiques pour les parties non encore dynamiques
        setData({
          ...apiData,
          xpMax: apiData.nextLevelXP, // Renommage pour correspondre au JSX
          totalPoints: 320, // Statique pour l'instant
          badgesUnlocked: 3, // Statique pour l'instant
          dailyChange: 2.4, // Statique pour l'instant
        });
      } catch (err: any) {
        setError(err.message);
      } finally {
        setIsLoadingData(false);
      }
    };

    fetchDashboardData();
  }, [token]);

  // Le reste de tes useEffects pour l'UI reste inchangé
  useEffect(() => {
    const updateDateTime = () => {
      const now = new Date();
      setCurrentDate(
        now.toLocaleDateString("fr-FR", {
          weekday: "long",
          day: "numeric",
          month: "long",
        })
      );
    };
    updateDateTime();
  }, []);

  useEffect(() => {
    setAnimateXP(true);
    const timer = setTimeout(() => setAnimateXP(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  // --- GESTION DE L'AFFICHAGE (CHARGEMENT, ERREUR, SUCCÈS) ---
  if (isAuthLoading || isLoadingData) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen text-center">
        <p className="text-red-500 font-semibold">Une erreur est survenue</p>
        <p className="text-gray-600 mt-2">{error}</p>
      </div>
    );
  }

  if (!merchantProfile || !data) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p>Impossible d'afficher le tableau de bord.</p>
      </div>
    );
  }

  return (
    // --- LE JSX COMPLET DE TON DASHBOARD, MAINTENANT CONNECTÉ ---
    <main className="p-4 pb-24 bg-gradient-to-br from-white to-blue-50 min-h-screen max-w-md mx-auto">
      {showNotification && (
        <div className="fixed bottom-20 left-1/2 transform -translate-x-1/2 bg-purple-600 text-white px-4 py-2 rounded-full text-sm shadow-lg animate-fade-in z-50">
          {showNotification}
        </div>
      )}

      <header className="flex justify-between items-center mb-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-blue-600 text-white flex items-center justify-center shadow-sm">
            🏪
          </div>
          <div>
            <h1 className="font-bold text-gray-800">{merchantProfile.name}</h1>
            <p className="text-xs text-gray-500">{currentDate}</p>
          </div>
        </div>
        <Link href="/profile">
          <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-md relative">
            <span className="text-sm font-medium text-gray-700">
              {merchantProfile.name.charAt(0)}
            </span>
          </div>
        </Link>
      </header>

      <Link href="/wallet" className="block mb-5 w-full">
        <section className="bg-gradient-to-r from-blue-500 to-purple-600 shadow-md rounded-xl p-5 cursor-pointer hover:shadow-lg transition text-white w-full">
          <div className="text-center">
            <p className="text-blue-100">Solde</p>
            <div className="flex flex-wrap items-center justify-center">
              <h2 className="text-3xl font-bold">
                {data.balance.toLocaleString("fr-FR", {
                  minimumFractionDigits: 2,
                })}{" "}
                DA
              </h2>
              <span className="text-xs bg-green-500/20 text-green-100 px-2 py-0.5 rounded-full ml-2 flex items-center gap-1">
                <span>▲</span> {data.dailyChange}%
              </span>
            </div>
          </div>
        </section>
      </Link>

      {/* --- SECTION ACTIONS RAPIDES (PRÉSERVÉE) --- */}
      <section className="mb-6">
        <h2 className="text-sm font-medium text-gray-600 mb-2 text-center">
          Actions rapides
        </h2>
        <Link href="/encaisser" className="block mb-3 w-full">
          <button className="w-full py-4 bg-gradient-to-r from-green-400 to-emerald-500 text-white font-bold rounded-xl shadow-md text-center flex items-center justify-center gap-2 hover:shadow-lg hover:opacity-90 transition-all">
            <span className="text-2xl">💵</span>
            <span>Encaisser</span>
          </button>
        </Link>
        <div className="grid grid-cols-3 gap-2">
          <Link href="/rembourser">
            <button className="w-full py-3 bg-white rounded-xl shadow-sm hover:shadow-md transition flex flex-col items-center gap-1">
              <span className="text-xl">🔁</span>
              <span className="text-xs">Rembourser</span>
            </button>
          </Link>
          <Link href="/inventaire">
            <button className="w-full py-3 bg-white rounded-xl shadow-sm hover:shadow-md transition flex flex-col items-center gap-1">
              <span className="text-xl">📦</span>
              <span className="text-xs">Inventaire</span>
            </button>
          </Link>
          <Link href="/retraits">
            <button className="w-full py-3 bg-white rounded-xl shadow-sm hover:shadow-md transition flex flex-col items-center gap-1">
              <span className="text-xl">💸</span>
              <span className="text-xs">Retraits</span>
            </button>
          </Link>
        </div>
      </section>

      {/* --- SECTION PROGRESSION (DYNAMIQUE) --- */}
      <section className="mb-6 w-full">
        <h2 className="text-sm font-medium text-gray-600 mb-2 text-center">
          Ma progression
        </h2>
        <Link href="/progression" className="block mb-3 w-full">
          <div className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition w-full">
            <div className="text-center mb-2">
              <div className="font-bold text-purple-900">
                Niveau {data.level}
              </div>
              <div className="text-xs text-gray-500">
                {data.xp}/{data.xpMax} XP
              </div>
            </div>
            <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden shadow-inner">
              <div
                className={`h-2 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full ${
                  animateXP ? "animate-pulse" : ""
                }`}
                style={{ width: `${(data.xp / data.xpMax) * 100}%` }}
              ></div>
            </div>
          </div>
        </Link>
      </section>

      {/* --- SECTION RÉCOMPENSES (PRÉSERVÉE ET PARTIELLEMENT DYNAMIQUE) --- */}
      <section className="w-full">
        <h2 className="text-sm font-medium text-gray-600 mb-2 text-center">
          Récompenses
        </h2>
        <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl p-4 shadow-md text-white w-full">
          <div className="text-center mb-2">
            <p className="font-medium">{data.totalPoints} points</p>
            <div className="text-xs text-indigo-100">
              {data.badgesUnlocked} badges débloqués
            </div>
          </div>
          <div className="bg-white/10 rounded-lg p-3 mb-3">
            <div className="text-center text-sm mb-2">
              <span>Mission: Encaisser {data.missionTotal} fois</span>
              <span className="font-medium ml-2">
                {data.missionProgress}/{data.missionTotal}
              </span>
            </div>
            <div className="w-full bg-white/20 rounded-full h-2 overflow-hidden">
              <div
                className="h-2 bg-white rounded-full"
                style={{
                  width: `${(data.missionProgress / data.missionTotal) * 100}%`,
                }}
              ></div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
};

export default DashboardPage;
