"use client";

import { useMemo } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import {
  MapContainer,
  TileLayer,
  Marker,
  Popup,
  useMapEvents,
} from "react-leaflet";
import type { Merchant } from "@/types/merchant";
import { MERCHANT_CATEGORIES } from "@/types/merchant";

// --- CONFIGURATION DES ICÔNES ---
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "/images/leaflet/marker-icon-2x.png",
  iconUrl: "/images/leaflet/marker-icon.png",
  shadowUrl: "/images/leaflet/marker-shadow.png",
});

const createEmojiIcon = (emoji: string, color: string) => {
  return L.divIcon({
    html: `<div style="background-color: ${color}; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.2); border: 2px solid white;">${emoji}</div>`,
    className: "emoji-marker",
    iconSize: [36, 36],
    iconAnchor: [18, 18],
  });
};

interface MerchantMapProps {
  merchants: Merchant[];
  mapCenter: [number, number];
  onMoveEnd: (lat: number, lng: number) => void;
  activeFilters?: string[];
  searchQuery?: string;
  loading: boolean; // Ajout de la prop de chargement
}

function MapEventsHandler({
  onMoveEnd,
}: {
  onMoveEnd: (lat: number, lng: number) => void;
}) {
  useMapEvents({
    moveend: (e) => {
      const center = e.target.getCenter();
      onMoveEnd(center.lat, center.lng);
    },
  });
  return null;
}

export default function MerchantMap({
  merchants,
  mapCenter,
  onMoveEnd,
  activeFilters = [],
  searchQuery = "",
  loading, // Utilisation de la prop de chargement
}: MerchantMapProps) {
  const filteredMerchants = useMemo(() => {
    return merchants.filter((merchant) => {
      const matchesFilter =
        activeFilters.length === 0 || activeFilters.includes(merchant.category);
      const matchesSearch =
        searchQuery === "" ||
        merchant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (merchant.address &&
          merchant.address.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesFilter && matchesSearch;
    });
  }, [merchants, activeFilters, searchQuery]);

  return (
    <div style={{ height: "100%", width: "100%", position: "relative" }}>
      <MapContainer
        // CORRECTION : La 'key' force le re-rendu complet de la carte
        key={`${mapCenter[0]}_${mapCenter[1]}`}
        center={mapCenter}
        zoom={13}
        style={{ height: "100%", width: "100%", zIndex: 0 }}
        scrollWheelZoom={true}
      >
        <MapEventsHandler onMoveEnd={onMoveEnd} />
        <TileLayer
          attribution='© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {filteredMerchants
          .map((merchant) => {
            // Determine latitude/longitude from either the optional location
            // object or from flat latitude/longitude fields. Some records
            // returned from the API only include `latitude` and `longitude`.
            const lat: number | null =
              (merchant as any).location?.lat ?? (merchant as any).latitude ?? null;
            const lng: number | null =
              (merchant as any).location?.lng ?? (merchant as any).longitude ?? null;
            if (lat == null || lng == null) {
              return null;
            }
            // Find category details. In case the category list is unavailable,
            // fall back to the default Leaflet icon.
            const category = Array.isArray(MERCHANT_CATEGORIES)
              ? MERCHANT_CATEGORIES.find((cat: any) => cat.id === (merchant as any).category)
              : null;
            const icon = category
              ? createEmojiIcon((category as any).emoji, (category as any).color)
              : new L.Icon.Default();
            return (
              <Marker key={merchant.id} position={[lat, lng]} icon={icon}>
                <Popup minWidth={250}>
                  <div className="p-1">
                    <h3 className="text-md font-bold mb-1">{merchant.name}</h3>
                    <p className="text-gray-600 text-sm mb-2">
                      {merchant.address}
                    </p>
                    {lat != null && lng != null && (
                      <a
                        href={`https://maps.google.com/?q=${lat},${lng}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full inline-block text-center px-3 py-1.5 bg-blue-500 text-white rounded-md text-sm hover:bg-blue-600 transition-colors"
                      >
                        Itinéraire
                      </a>
                    )}
                  </div>
                </Popup>
              </Marker>
            );
          })
          .filter(Boolean)}
      </MapContainer>
      {/* CORRECTION : N'affiche ce message que si le chargement est terminé */}
      {filteredMerchants.length === 0 && !loading && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-[1000]">
          <div className="bg-white bg-opacity-80 rounded-lg px-6 py-4 shadow text-gray-600 text-lg font-semibold">
            Aucun commerçant trouvé dans cette zone.
          </div>
        </div>
      )}
    </div>
  );
}
