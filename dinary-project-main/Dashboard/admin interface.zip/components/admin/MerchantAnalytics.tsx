"use client";

import { useState } from "react";
import { Bar, Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Clock, TrendingUp, Users, ShoppingBag } from "lucide-react";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend
);

import type { Merchant } from "@/types/merchant";
interface MerchantAnalyticsProps {
  className?: string;
  merchants?: Merchant[];
}

export default function MerchantAnalytics({
  className = "",
  merchants = [],
}: MerchantAnalyticsProps) {
  const [timeRange, setTimeRange] = useState<"day" | "week" | "month">("week");
  const [activeTab, setActiveTab] = useState<"traffic" | "sales" | "ratings">(
    "traffic"
  );

  // Example: traffic = number of merchants added per day (simulate with createdAt if available)
  const trafficLabels = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];
  const trafficCounts = Array(7).fill(0);
  merchants.forEach((m) => {
    if (m.createdAt) {
      const day = new Date(m.createdAt).getDay();
      trafficCounts[day === 0 ? 6 : day - 1] += 1; // JS: 0=Sun, 1=Mon...
    }
  });
  const trafficData = {
    labels: trafficLabels,
    datasets: [
      {
        label: "Nouveaux commerçants",
        data: trafficCounts,
        backgroundColor: "rgba(0, 165, 165, 0.5)",
        borderColor: "#00a5a5",
        borderWidth: 2,
      },
    ],
  };

  // Example: sales = sum of revenue per day (simulate with createdAt if available)
  const salesCounts = Array(7).fill(0);
  merchants.forEach((m) => {
    if (m.createdAt) {
      const day = new Date(m.createdAt).getDay();
      salesCounts[day === 0 ? 6 : day - 1] += m.revenue ?? 0;
    }
  });
  const salesData = {
    labels: trafficLabels,
    datasets: [
      {
        label: "Revenus",
        data: salesCounts,
        backgroundColor: "rgba(52, 211, 153, 0.5)",
        borderColor: "#34d399",
        borderWidth: 2,
      },
    ],
  };

  // Example: ratings = average rating per day (simulate with createdAt if available)
  const ratingSums = Array(7).fill(0);
  const ratingCounts = Array(7).fill(0);
  merchants.forEach((m) => {
    if (m.createdAt && m.rating) {
      const day = new Date(m.createdAt).getDay();
      ratingSums[day === 0 ? 6 : day - 1] += m.rating;
      ratingCounts[day === 0 ? 6 : day - 1] += 1;
    }
  });
  const ratingAverages = ratingSums.map((sum, i) =>
    ratingCounts[i] > 0 ? sum / ratingCounts[i] : 0
  );
  const ratingData = {
    labels: trafficLabels,
    datasets: [
      {
        label: "Note moyenne",
        data: ratingAverages,
        backgroundColor: "rgba(251, 191, 36, 0.5)",
        borderColor: "#fbbf24",
        borderWidth: 2,
        tension: 0.3,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        mode: "index" as const,
        intersect: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          display: true,
          color: "rgba(0, 0, 0, 0.05)",
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
  };

  // Example dynamic stats from merchants
  const quickStats = [
    {
      icon: Users,
      label: "Commerçants actifs",
      value: merchants.filter((m) => m.status === "active").length,
      trend: "",
      color: "text-blue-500",
    },
    {
      icon: ShoppingBag,
      label: "Total Commerçants",
      value: merchants.length,
      trend: "",
      color: "text-green-500",
    },
    {
      icon: TrendingUp,
      label: "Revenu total",
      value: merchants
        .reduce((sum, m) => sum + (m.revenue ?? 0), 0)
        .toLocaleString(),
      trend: "",
      color: "text-purple-500",
    },
    {
      icon: Clock,
      label: "Revenu moyen",
      value:
        merchants.length > 0
          ? (
              merchants.reduce((sum, m) => sum + (m.revenue ?? 0), 0) /
              merchants.length
            ).toFixed(2)
          : "0",
      trend: "",
      color: "text-orange-500",
    },
  ];

  return (
    <div className={`bg-white rounded-lg shadow-sm p-6 ${className}`}>
      {/* En-tête avec sélection de période */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold">Analyses des commerçants</h2>
        <div className="flex items-center space-x-2">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value as any)}
            className="px-3 py-1.5 border rounded-md text-sm focus:ring-2 focus:ring-dinary-turquoise focus:border-transparent"
          >
            <option value="day">Aujourd'hui</option>
            <option value="week">Cette semaine</option>
            <option value="month">Ce mois</option>
          </select>
        </div>
      </div>

      {/* Statistiques rapides */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {quickStats.map((stat, index) => (
          <div key={index} className="p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center mb-2">
              <stat.icon className={`w-5 h-5 ${stat.color} mr-2`} />
              <span className="text-sm text-gray-600">{stat.label}</span>
            </div>
            <div className="flex items-baseline justify-between">
              <span className="text-2xl font-semibold">{stat.value}</span>
              <span
                className={`text-sm ${
                  stat.trend.startsWith("+") ? "text-green-500" : "text-red-500"
                }`}
              >
                {stat.trend}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Onglets des graphiques */}
      <div className="flex space-x-4 mb-6">
        <button
          onClick={() => setActiveTab("traffic")}
          className={`px-4 py-2 text-sm font-medium rounded-md ${
            activeTab === "traffic"
              ? "bg-dinary-turquoise text-white"
              : "text-gray-600 hover:bg-gray-100"
          }`}
        >
          Trafic
        </button>
        <button
          onClick={() => setActiveTab("sales")}
          className={`px-4 py-2 text-sm font-medium rounded-md ${
            activeTab === "sales"
              ? "bg-dinary-turquoise text-white"
              : "text-gray-600 hover:bg-gray-100"
          }`}
        >
          Ventes
        </button>
        <button
          onClick={() => setActiveTab("ratings")}
          className={`px-4 py-2 text-sm font-medium rounded-md ${
            activeTab === "ratings"
              ? "bg-dinary-turquoise text-white"
              : "text-gray-600 hover:bg-gray-100"
          }`}
        >
          Avis
        </button>
      </div>

      {/* Zone du graphique */}
      <div className="h-[300px]">
        {activeTab === "traffic" && (
          <Bar data={trafficData} options={options} />
        )}
        {activeTab === "sales" && <Bar data={salesData} options={options} />}
        {activeTab === "ratings" && (
          <Line data={ratingData} options={options} />
        )}
      </div>
    </div>
  );
}
