"use client";

import React, { useState, useEffect, useMemo, useCallback } from "react";
import VerificationDetailModal from "@/components/admin/VerificationDetailModal";
import {
  Search,
  Filter,
  MoreHorizontal,
  MessageSquare,
  Shield,
  UserX,
  TrendingUp,
  RefreshCw,
  CreditCard,
  DollarSign,
  User,
  UserCheck,
  BarChart2,
  Mail,
  Phone,
  X,
  Users as UsersIcon,
  Store as StoreIcon,
  Clock,
  Check, // Ajout de l'icône
} from "lucide-react";
import { format } from "date-fns";
import { useAuth } from "@/contexts/AuthContext";
import UserLevelSystem from "@/components/admin/UserLevelSystem";
import { userStats as mockUserStats } from "@/lib/mock-data";

// --- INTERFACES ---

interface VerificationRequest {
  id: string;
  documentType: string;
  frontImageUrl: string;
  backImageUrl?: string | null;
  selfieImageUrl?: string | null;
  selfieInstruction?: string | null;
  user: {
    fullName: string;
    email: string;
    role: "USER" | "MERCHANT";
  };
  createdAt: string;
}

interface UserData {
  id: string;
  email: string;
  username: string;
  fullName: string;
  phoneNumber: string;
  role: string;
  createdAt: string;
  updatedAt: string;
  isVerified: boolean;
  profile: {
    level: number;
    xp: number;
  } | null;
  wallet: {
    _count: {
      sentTransactions: number;
      receivedTransactions: number;
    };
  } | null;
}

// Interface pour les demandes de recharge
interface RechargeRequest {
  id: string;
  amount: number;
  reference: string | null;
  createdAt: string;
  status: string;
  receiver: {
    user: {
      fullName: string;
      email: string;
    };
  };
}

// --- COMPOSANTS INTERNES ---

const StatusBadge = ({
  isVerified,
  isBlocked = false,
}: {
  isVerified: boolean;
  isBlocked?: boolean;
}) => {
  const status = isBlocked ? "blocked" : isVerified ? "active" : "inactive";
  const getStatusColor = (s: string) => {
    switch (s) {
      case "active":
        return "bg-green-100 text-green-800 border-green-200";
      case "inactive":
        return "bg-gray-100 text-gray-800 border-gray-200";
      case "blocked":
        return "bg-red-100 text-red-800 border-red-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };
  return (
    <span
      className={`px-2 py-1 text-xs font-medium rounded-full border ${getStatusColor(
        status
      )}`}
    >
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
};

const Tabs = ({
  tabs,
  activeTab,
  setActiveTab,
  rechargeData,
  verificationData,
}: {
  tabs: { id: string; label: string; icon: React.ReactNode }[];
  activeTab: string;
  setActiveTab: (id: string) => void;
  rechargeData: any[];
  verificationData: any[];
}) => (
  <div className="flex space-x-1 overflow-x-auto pb-2 border-b">
    {tabs.map((tab) => (
      <button
        key={tab.id}
        onClick={() => setActiveTab(tab.id)}
        className={`px-4 py-2 flex items-center space-x-2 rounded-t-lg transition-colors ${
          activeTab === tab.id
            ? "bg-white text-dinary-turquoise border-b-2 border-dinary-turquoise font-medium"
            : "text-gray-600 hover:text-dinary-turquoise hover:bg-gray-50"
        }`}
      >
        {tab.icon}
        <span>{tab.label}</span>
        {tab.id === "recharge-requests" && (
          <span className="bg-red-100 text-red-600 text-xs px-2 py-0.5 rounded-full">
            {rechargeData.filter((req: any) => req.status === "PENDING").length}
          </span>
        )}
        {tab.id === "verifications" && (
          <span className="bg-amber-100 text-amber-600 text-xs px-2 py-0.5 rounded-full">
            {verificationData.length}
          </span>
        )}
      </button>
    ))}
  </div>
);

const UserDetailModal = ({
  user,
  onClose,
}: {
  user: UserData;
  onClose: () => void;
}) => {
  const formatDate = (dateString: string) =>
    format(new Date(dateString), "dd MMM yyyy");

  const totalTransactions =
    (user.wallet?._count?.sentTransactions ?? 0) +
    (user.wallet?._count?.receivedTransactions ?? 0);

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50 overflow-y-auto">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-5xl max-h-[90vh] overflow-hidden flex flex-col">
        <div className="bg-gray-50 border-b px-6 py-4 flex justify-between items-center sticky top-0 z-10">
          <div className="flex items-center space-x-4">
            <div className="h-16 w-16 rounded-full bg-dinary-turquoise text-white text-xl flex items-center justify-center font-medium">
              {user.fullName.charAt(0)}
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                {user.fullName} <StatusBadge isVerified={user.isVerified} />
                <span className="text-sm text-gray-500">
                  #{user.id.substring(0, 8)}
                </span>
              </h2>
              <div className="flex items-center mt-1 text-sm text-gray-600">
                <div className="flex items-center mr-4">
                  <Mail size={14} className="mr-1" /> {user.email}
                </div>
                <div className="flex items-center">
                  <Phone size={14} className="mr-1" /> {user.phoneNumber}
                </div>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-800"
          >
            <X size={24} />
          </button>
        </div>
        <div className="overflow-y-auto p-6 flex-grow">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-6">
              <div className="bg-white border rounded-lg p-5 shadow-sm">
                <h3 className="text-lg font-medium text-gray-800 mb-4">
                  Informations générales
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Inscrit le</span>
                    <span className="text-sm font-medium">
                      {formatDate(user.createdAt)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">
                      Dernière activité
                    </span>
                    <span className="text-sm font-medium">
                      {formatDate(user.updatedAt)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Statut</span>
                    <StatusBadge isVerified={user.isVerified} />
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Transactions</span>
                    <span className="text-sm font-medium">
                      {totalTransactions}
                    </span>
                  </div>
                </div>
              </div>
              <UserLevelSystem
                userType="user"
                level={user.profile?.level ?? 1}
                xp={user.profile?.xp ?? 0}
                xpToNextLevel={1000}
                points={user.profile?.xp ?? 0}
                starPoints={0}
                challenges={[]}
              />
            </div>
            <div className="bg-white border rounded-lg p-5 shadow-sm md:col-span-2">
              <h3 className="text-lg font-medium text-gray-800">
                Activités et Transactions
              </h3>
              <p className="text-gray-500 text-sm mt-2">
                Cette section sera bientôt connectée aux données réelles.
              </p>
            </div>
          </div>
        </div>
        <div className="bg-gray-50 border-t px-6 py-4 flex justify-between items-center sticky bottom-0">
          <div className="flex space-x-2">
            <button className="px-4 py-2 bg-blue-50 text-blue-600 rounded-md flex items-center text-sm hover:bg-blue-100">
              <MessageSquare size={16} className="mr-2" /> Envoyer un message
            </button>
            <button className="px-4 py-2 bg-purple-50 text-purple-600 rounded-md flex items-center text-sm hover:bg-purple-100">
              <TrendingUp size={16} className="mr-2" /> Ajouter des points
            </button>
          </div>
          <div className="flex space-x-2">
            <button className="px-4 py-2 bg-amber-50 text-amber-600 rounded-md flex items-center text-sm hover:bg-amber-100">
              <Shield size={16} className="mr-2" /> Bloquer
            </button>
            <button className="px-4 py-2 bg-red-50 text-red-600 rounded-md flex items-center text-sm hover:bg-red-100">
              <UserX size={16} className="mr-2" /> Supprimer
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const UserStatCard = ({
  title,
  value,
  icon,
  colorClass,
}: {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  colorClass: string;
}) => (
  <div className="bg-white rounded-lg border shadow-sm p-4 transition-transform hover:shadow-md hover:scale-[1.02] duration-300">
    <div className="flex justify-between items-start">
      <div>
        <p className="text-sm text-gray-500">{title}</p>
        <p className="text-xl font-bold mt-1">{value}</p>
      </div>
      <div className={`p-2 rounded-full ${colorClass}`}>{icon}</div>
    </div>
  </div>
);

// --- COMPOSANT PRINCIPAL DE LA PAGE ---
export default function UsersPage() {
  const [activeTab, setActiveTab] = useState("overview");
  const [loading, setLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [verificationTypeFilter, setVerificationTypeFilter] = useState<
    "USER" | "MERCHANT"
  >("USER");
  const [users, setUsers] = useState<UserData[]>([]);
  const [stats, setStats] = useState({
    ...mockUserStats,
    totalUsers: 0,
    activeUsers: 0,
    newUsersToday: 0,
    pendingVerifications: 0,
  });
  const [rechargeRequests, setRechargeRequests] = useState<RechargeRequest[]>(
    []
  );
  const [selectedUserDetail, setSelectedUserDetail] = useState<UserData | null>(
    null
  );
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [verifications, setVerifications] = useState<VerificationRequest[]>([]);
  const [selectedVerification, setSelectedVerification] =
    useState<VerificationRequest | null>(null);
  const [isLoadingVerifications, setIsLoadingVerifications] = useState(false);

  const { token, logout } = useAuth();

  const fetchData = useCallback(async () => {
    if (!token) {
      setError("Authentification requise.");
      setLoading(false);
      return;
    }
    setError(null);

    try {
      const [
        usersResponse,
        statsResponse,
        rechargeResponse,
        verificationsResponse,
      ] = await Promise.all([
        fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/users`, {
          headers: { Authorization: `Bearer ${token}` },
        }),
        fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/stats`, {
          headers: { Authorization: `Bearer ${token}` },
        }),
        fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/recharges/pending`, {
          headers: { Authorization: `Bearer ${token}` },
        }),
        fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/identity/pending`, {
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      if (
        [
          usersResponse,
          statsResponse,
          rechargeResponse,
          verificationsResponse,
        ].some((res) => res.status === 401)
      ) {
        logout();
        throw new Error("Session expirée. Veuillez vous reconnecter.");
      }

      if (
        !usersResponse.ok ||
        !statsResponse.ok ||
        !rechargeResponse.ok ||
        !verificationsResponse.ok
      ) {
        throw new Error("Échec du chargement des données.");
      }

      const usersData: UserData[] = await usersResponse.json();
      const statsData = await statsResponse.json();
      const rechargeData: RechargeRequest[] = await rechargeResponse.json();
      const verificationsData = await verificationsResponse.json();

      setUsers(usersData || []);
      setRechargeRequests(rechargeData || []);
      setVerifications(verificationsData || []);

      setStats((prev) => ({
        ...prev,
        totalUsers: statsData.totalUsers,
        activeUsers: usersData.filter((u) => u.isVerified).length,
        newUsersToday: statsData.newUsersToday,
        inactiveUsers: usersData.filter((u) => !u.isVerified).length,
        pendingRecharges: rechargeData.filter((r) => r.status === "PENDING")
          .length,
        pendingVerifications: verificationsData.length,
      }));
    } catch (err: any) {
      setError(err.message);
    }
  }, [token, logout]);

  const fetchVerifications = useCallback(async () => {
    // ... (fonction inchangée)
  }, [token, verificationTypeFilter, logout]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchData();
    setIsRefreshing(false);
  };

  const handleProcessRecharge = async (
    id: string,
    action: "approve" | "reject"
  ) => {
    const reason =
      action === "reject" ? prompt("Veuillez entrer le motif du rejet :") : "";
    if (action === "reject" && !reason) {
      alert("Un motif est obligatoire pour rejeter une demande.");
      return;
    }

    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/admin/recharges/${id}/${action}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ reason }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `L'action a échoué.`);
      }

      alert(
        `La demande a été ${action === "approve" ? "approuvée" : "rejetée"}.`
      );
      handleRefresh(); // Recharger toutes les données pour mettre à jour les listes et stats
    } catch (err: any) {
      setError(err.message);
    }
  };

  useEffect(() => {
    setLoading(true);
    fetchData().finally(() => setLoading(false));
  }, [fetchData]);

  useEffect(() => {
    if (activeTab === "verifications") {
      fetchVerifications();
    }
  }, [activeTab, fetchVerifications]);

  const filteredUsers = useMemo(
    () =>
      users.filter((user) => {
        const searchMatch =
          user.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
          user.phoneNumber.includes(searchQuery);
        let statusMatch = true;
        if (selectedStatus === "active") statusMatch = user.isVerified;
        if (selectedStatus === "inactive") statusMatch = !user.isVerified;
        return searchMatch && statusMatch;
      }),
    [users, searchQuery, selectedStatus]
  );

  const tabs = [
    { id: "overview", label: "Vue d'ensemble", icon: <BarChart2 size={18} /> },
    { id: "users-list", label: "Liste utilisateurs", icon: <User size={18} /> },
    {
      id: "recharge-requests",
      label: "Demandes de rechargement",
      icon: <CreditCard size={18} />,
    },
    {
      id: "manual-recharge",
      label: "Rechargement libre",
      icon: <DollarSign size={18} />,
    },
    {
      id: "verifications",
      label: "Vérifications",
      icon: <UserCheck size={18} />,
    },
  ];

  if (loading)
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-dinary-turquoise"></div>
      </div>
    );
  if (error)
    return (
      <div className="p-4 bg-red-50 text-red-600 text-center rounded-lg">
        {error}
      </div>
    );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-2xl font-bold text-gray-800">
          Gestion des utilisateurs
        </h1>
        <button
          onClick={handleRefresh}
          disabled={isRefreshing}
          className="bg-dinary-turquoise text-white px-4 py-2 rounded-lg hover:bg-opacity-90 transition-colors flex items-center space-x-2 disabled:opacity-50"
        >
          <RefreshCw size={16} className={isRefreshing ? "animate-spin" : ""} />
          <span>{isRefreshing ? "Chargement..." : "Actualiser"}</span>
        </button>
      </div>

      <Tabs
        tabs={tabs}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        rechargeData={rechargeRequests}
        verificationData={verifications}
      />

      <div className="bg-white rounded-lg p-6 border shadow-sm">
        {activeTab === "overview" && (
          <div className="space-y-6">
            <h2 className="text-lg font-medium text-gray-800 mb-4">
              Statistiques utilisateurs
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              <UserStatCard
                title="Total utilisateurs"
                // Affiche la valeur si c'est un objet, sinon la stat elle-même
                value={stats.totalUsers?.value ?? stats.totalUsers}
                icon={<User className="h-5 w-5 text-white" />}
                colorClass="bg-blue-500"
              />
              <UserStatCard
                title="Utilisateurs actifs"
                value={stats.activeUsers?.value ?? stats.activeUsers}
                icon={<UserCheck className="h-5 w-5 text-white" />}
                colorClass="bg-green-500"
              />
              <UserStatCard
                title="Nouveaux aujourd'hui"
                value={stats.newUsersToday?.value ?? stats.newUsersToday}
                icon={<TrendingUp className="h-5 w-5 text-white" />}
                colorClass="bg-purple-500"
              />
              <UserStatCard
                title="Recharges en attente"
                value={stats.pendingRecharges?.value ?? stats.pendingRecharges}
                icon={<Clock className="h-5 w-5 text-white" />}
                colorClass="bg-amber-500"
              />
              <UserStatCard
                title="Vérifications en attente"
                value={
                  stats.pendingVerifications?.value ??
                  stats.pendingVerifications
                }
                icon={<UserCheck className="h-5 w-5 text-white" />}
                colorClass="bg-yellow-500"
              />
            </div>
          </div>
        )}

        {activeTab === "users-list" && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
              <div className="relative w-full sm:w-96">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search size={18} className="text-gray-400" />
                </div>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Rechercher par nom, email ou téléphone"
                  className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:border-dinary-turquoise focus:outline-none text-sm"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Filter size={18} className="text-gray-500" />
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:border-dinary-turquoise bg-white text-gray-800 text-sm"
                >
                  <option value="all">Tous les statuts</option>
                  <option value="active">Actif</option>
                  <option value="inactive">Inactif</option>
                </select>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Utilisateur
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Statut
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Niveau
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Inscription
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Dernière activité
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Points
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Transactions
                    </th>
                    <th scope="col" className="relative px-6 py-3">
                      <span className="sr-only">Actions</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredUsers.map((user) => (
                    <tr
                      key={user.id}
                      className="hover:bg-gray-50 cursor-pointer"
                      onClick={() => setSelectedUserDetail(user)}
                    >
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10 rounded-full bg-dinary-turquoise text-white flex items-center justify-center font-medium">
                            {user.fullName.charAt(0)}
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">
                              {user.fullName}
                            </div>
                            <div className="text-xs text-gray-500">
                              {user.email}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <StatusBadge isVerified={user.isVerified} />
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {user.profile?.level ?? 1}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {format(new Date(user.createdAt), "dd MMM yyyy")}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {format(new Date(user.updatedAt), "dd MMM yyyy")}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {user.profile?.xp ?? 0}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {(user.wallet?._count?.sentTransactions ?? 0) +
                          (user.wallet?._count?.receivedTransactions ?? 0)}
                      </td>
                      <td
                        className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="relative group">
                          <button className="text-gray-400 hover:text-gray-500">
                            <MoreHorizontal size={20} />
                          </button>
                          <div className="absolute right-0 w-48 mt-2 bg-white rounded-md shadow-lg hidden group-hover:block z-10"></div>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === "recharge-requests" && (
          <div>
            <h2 className="text-lg font-medium text-gray-800 mb-4">
              Demandes de rechargement en attente
            </h2>
            {rechargeRequests.filter((req) => req.status === "PENDING")
              .length === 0 ? (
              <p className="text-center py-4 text-gray-500">
                Aucune demande de recharge en attente.
              </p>
            ) : (
              <div className="space-y-4">
                {rechargeRequests
                  .filter((req) => req.status === "PENDING")
                  .map((req) => (
                    <div
                      key={req.id}
                      className="bg-gray-50 p-4 rounded-lg border"
                    >
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                        <div>
                          <p className="text-sm text-gray-500">Utilisateur</p>
                          <p className="font-medium">
                            {req.receiver.user.fullName}
                          </p>
                          <p className="text-xs text-gray-400">
                            {req.receiver.user.email}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Montant</p>
                          <p className="font-bold text-lg">
                            {req.amount.toLocaleString("fr-FR")} DA
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Référence</p>
                          <p className="font-mono bg-gray-200 p-1 rounded text-xs inline-block">
                            {req.reference || "N/A"}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() =>
                              handleProcessRecharge(req.id, "approve")
                            }
                            className="flex-1 bg-green-100 text-green-700 px-3 py-2 rounded-lg hover:bg-green-200 text-sm flex items-center justify-center gap-2"
                          >
                            <Check size={16} /> Approuver
                          </button>
                          <button
                            onClick={() =>
                              handleProcessRecharge(req.id, "reject")
                            }
                            className="flex-1 bg-red-100 text-red-700 px-3 py-2 rounded-lg hover:bg-red-200 text-sm flex items-center justify-center gap-2"
                          >
                            <X size={16} /> Rejeter
                          </button>
                        </div>
                      </div>
                      <p className="text-xs text-gray-400 mt-2 text-right">
                        Demandé le:{" "}
                        {new Date(req.createdAt).toLocaleString("fr-FR")}
                      </p>
                    </div>
                  ))}
              </div>
            )}
          </div>
        )}

        {activeTab === "manual-recharge" && (
          <div>
            <h2 className="text-lg font-medium text-gray-800 mb-4">
              Rechargement libre
            </h2>
            <form
              className="max-w-lg mx-auto bg-white p-6 rounded-lg shadow"
              onSubmit={async (e) => {
                e.preventDefault();
                const form = e.target as HTMLFormElement;
                const phone = (
                  form.elements.namedItem("phone") as HTMLInputElement
                ).value;
                const amount = (
                  form.elements.namedItem("amount") as HTMLInputElement
                ).value;
                const reference = (
                  form.elements.namedItem("reference") as HTMLInputElement
                ).value;
                if (!phone) {
                  alert("Veuillez renseigner un numéro de téléphone.");
                  return;
                }
                if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
                  alert("Veuillez entrer un montant valide.");
                  return;
                }
                try {
                  const res = await fetch(
                    `${process.env.NEXT_PUBLIC_API_URL}/admin/recharges/manual`,
                    {
                      method: "POST",
                      headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`,
                      },
                      body: JSON.stringify({
                        phone,
                        amount: Number(amount),
                        reference,
                      }),
                    }
                  );
                  const data = await res.json();
                  if (res.ok) {
                    alert("Recharge effectuée avec succès !");
                    form.reset();
                  } else {
                    alert(data.message || "Erreur lors du rechargement.");
                  }
                } catch (err) {
                  alert("Erreur réseau ou serveur.");
                }
              }}
            >
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Numéro de téléphone
                </label>
                <input
                  name="phone"
                  type="text"
                  className="w-full border rounded px-3 py-2"
                  placeholder="Numéro de téléphone"
                />
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Montant
                </label>
                <input
                  name="amount"
                  type="number"
                  min="1"
                  className="w-full border rounded px-3 py-2"
                  placeholder="Montant à recharger"
                  required
                />
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Référence (optionnel)
                </label>
                <input
                  name="reference"
                  type="text"
                  className="w-full border rounded px-3 py-2"
                  placeholder="Référence"
                />
              </div>
              <button
                type="submit"
                className="bg-dinary-turquoise text-white px-4 py-2 rounded hover:bg-opacity-90"
              >
                Recharger
              </button>
            </form>
          </div>
        )}
        {activeTab === "verifications" && (
          <div>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-medium">Demandes de vérification</h2>
              <div className="flex p-1 bg-gray-100 rounded-lg">
                <button
                  onClick={() => setVerificationTypeFilter("USER")}
                  className={`px-3 py-1 text-sm rounded-md flex items-center ${
                    verificationTypeFilter === "USER" ? "bg-white shadow" : ""
                  }`}
                >
                  <UsersIcon size={16} className="mr-2" /> Clients
                </button>
                <button
                  onClick={() => setVerificationTypeFilter("MERCHANT")}
                  className={`px-3 py-1 text-sm rounded-md flex items-center ${
                    verificationTypeFilter === "MERCHANT"
                      ? "bg-white shadow"
                      : ""
                  }`}
                >
                  <StoreIcon size={16} className="mr-2" /> Vendeurs
                </button>
              </div>
            </div>
            {isLoadingVerifications ? (
              <p>Chargement...</p>
            ) : (
              <table className="w-full">
                <thead>
                  <tr className="text-left text-sm text-gray-500">
                    <th className="p-2">Utilisateur</th>
                    <th className="p-2">Date de soumission</th>
                    <th className="p-2">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {verifications.length === 0 ? (
                    <tr>
                      <td colSpan={3} className="text-center p-4 text-gray-500">
                        Aucune demande en attente.
                      </td>
                    </tr>
                  ) : (
                    verifications.map((req) => (
                      <tr key={req.id} className="border-t">
                        <td className="p-2">
                          <div className="font-medium">{req.user.fullName}</div>
                          <div className="text-xs text-gray-500">
                            {req.user.email}
                          </div>
                        </td>
                        <td className="p-2 text-sm">
                          {new Date(req.createdAt).toLocaleDateString("fr-FR")}
                        </td>
                        <td className="p-2">
                          <button
                            onClick={() => setSelectedVerification(req)}
                            className="text-blue-500 hover:underline text-sm"
                          >
                            Examiner
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            )}
          </div>
        )}
      </div>

      {selectedUserDetail && (
        <UserDetailModal
          user={selectedUserDetail}
          onClose={() => setSelectedUserDetail(null)}
        />
      )}
      <VerificationDetailModal
        request={selectedVerification}
        onClose={() => setSelectedVerification(null)}
        onAction={fetchVerifications}
        token={token}
      />
    </div>
  );
}
