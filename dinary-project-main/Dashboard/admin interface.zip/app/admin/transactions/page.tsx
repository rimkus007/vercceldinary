"use client";

import { useState, useEffect, useMemo } from "react";
import { useAuth } from "@/contexts/AuthContext";
import ChartComponent from "@/components/admin/ChartComponent";
import {
  Search,
  ArrowUp,
  ArrowDown,
  RefreshCw,
  Download,
} from "lucide-react";

// Interface représentant une transaction renvoyée par l'API /admin/transactions
interface TransactionRecord {
  id: string;
  amount: number;
  type: string;
  status: string | null;
  createdAt: string;
  senderName: string | null;
  senderEmail: string | null;
  receiverName: string | null;
  receiverEmail: string | null;
  description: string | null;
}

/**
 * Page listant l'ensemble des transactions de la plateforme.
 *
 * Cette page interroge le backend via l'endpoint `/admin/transactions` pour récupérer
 * toutes les transactions avec les informations sur l'expéditeur et le destinataire.
 * Elle fournit des statistiques globales, un graphique par type de transaction et un tableau détaillé.
 */
export default function TransactionsPage() {
  const { token } = useAuth();
  const [transactions, setTransactions] = useState<TransactionRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortField, setSortField] = useState<
    "createdAt" | "amount"
  >("createdAt");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">(
    "desc"
  );
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Chargement initial des transactions
  useEffect(() => {
    if (!token) return;
    const fetchTransactions = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/admin/transactions`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        if (!res.ok) {
          throw new Error(
            "Erreur lors du chargement des transactions de la plateforme."
          );
        }
        const json = await res.json();
        setTransactions(json);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchTransactions();
  }, [token]);

  // Rafraîchissement manuel des données
  const handleRefresh = () => {
    setIsRefreshing(true);
    if (!token) return;
    fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/transactions`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => res.json())
      .then((json) => setTransactions(json))
      .catch(() => {})
      .finally(() => setIsRefreshing(false));
  };

  // Filtrage selon la recherche
  const filtered = useMemo(() => {
    const search = searchTerm.toLowerCase();
    return transactions.filter((t) => {
      return (
        t.id.toLowerCase().includes(search) ||
        (t.senderName ?? "").toLowerCase().includes(search) ||
        (t.receiverName ?? "").toLowerCase().includes(search) ||
        (t.description ?? "").toLowerCase().includes(search)
      );
    });
  }, [transactions, searchTerm]);

  // Tri selon le champ sélectionné
  const sorted = useMemo(() => {
    return [...filtered].sort((a, b) => {
      let valA: number | string = a[sortField];
      let valB: number | string = b[sortField];
      // Pour la date, on convertit en timestamp pour trier correctement
      if (sortField === "createdAt") {
        valA = new Date(a.createdAt).getTime();
        valB = new Date(b.createdAt).getTime();
      }
      if (valA < valB) return sortDirection === "asc" ? -1 : 1;
      if (valA > valB) return sortDirection === "asc" ? 1 : -1;
      return 0;
    });
  }, [filtered, sortField, sortDirection]);

  // Statistiques globales
  const totalAmount = useMemo(
    () => transactions.reduce((sum, t) => sum + (t.amount || 0), 0),
    [transactions]
  );
  const totalCount = transactions.length;

  // Répartition des transactions par type
  const typeCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const t of transactions) {
      counts[t.type] = (counts[t.type] || 0) + 1;
    }
    return counts;
  }, [transactions]);
  const typeChartData = useMemo(() => {
    const labels = Object.keys(typeCounts);
    const values = labels.map((label) => typeCounts[label]);
    return {
      labels,
      datasets: [
        {
          data: values,
          backgroundColor: labels.map((_, idx) => {
            // Génère une palette de couleurs cohérente pour le graphique
            const colors = [
              "#4DD0E1",
              "#66BB6A",
              "#FFA726",
              "#9575CD",
              "#EF5350",
              "#26A69A",
              "#FF7043",
            ];
            return colors[idx % colors.length];
          }),
          borderWidth: 1,
          borderColor: "#fff",
        },
      ],
    };
  }, [typeCounts]);

  // Changement de tri
  const toggleSort = (field: "createdAt" | "amount") => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("desc");
    }
  };

  if (loading) return <div className="p-6">Chargement...</div>;
  if (error)
    return <div className="p-6 text-red-500">Erreur : {error}</div>;

  return (
    <div className="space-y-6">
      {/* Titre et actions */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">
            Transactions de la plateforme
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Liste complète des transactions et analyse par type
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleRefresh}
            className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
            disabled={isRefreshing}
          >
            <RefreshCw
              size={18}
              className={`text-gray-600 ${isRefreshing ? "animate-spin" : ""}`}
            />
          </button>
          <button className="flex items-center px-3 py-2 bg-dinary-turquoise hover:bg-dinary-turquoise/90 text-white rounded-lg">
            <Download size={16} className="mr-2" />
            Exporter
          </button>
        </div>
      </div>
      {/* Cartes récapitulatives */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg shadow p-5 border border-gray-100">
          <p className="text-sm text-gray-500 mb-1">
            Montant total des transactions
          </p>
          <h3 className="text-xl font-bold">
            {totalAmount.toLocaleString("fr-DZ", {
              style: "currency",
              currency: "DZD",
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })}
          </h3>
        </div>
        <div className="bg-white rounded-lg shadow p-5 border border-gray-100">
          <p className="text-sm text-gray-500 mb-1">
            Nombre total de transactions
          </p>
          <h3 className="text-xl font-bold">
            {totalCount.toLocaleString()}
          </h3>
        </div>
        <div className="bg-white rounded-lg shadow p-5 border border-gray-100">
          <p className="text-sm text-gray-500 mb-1">
            Types de transactions
          </p>
          <h3 className="text-xl font-bold">
            {Object.keys(typeCounts).length}
          </h3>
        </div>
      </div>
      {/* Diagramme de répartition des types de transaction */}
      <div className="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-5 border border-gray-100">
          <div className="mb-4">
            <h3 className="text-lg font-medium text-gray-800">
              Répartition par type
            </h3>
            <p className="text-sm text-gray-500">Nombre de transactions par type</p>
          </div>
          <div className="h-64">
            <ChartComponent
              type="doughnut"
              data={typeChartData}
              options={{
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    position: "bottom",
                    labels: {
                      boxWidth: 12,
                      padding: 15,
                      usePointStyle: true,
                    },
                  },
                },
              }}
            />
          </div>
        </div>
      </div>
      {/* Table des transactions */}
      <div className="bg-white rounded-lg shadow p-5 border border-gray-100">
        <div className="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-5">
          <h3 className="text-lg font-medium text-gray-800">
            Liste des transactions
          </h3>
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <Search size={16} className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Rechercher..."
                className="pl-10 pr-3 py-2 border rounded-lg w-full md:w-64 focus:ring-2 focus:ring-dinary-turquoise focus:border-dinary-turquoise"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  ID
                </th>
                <th
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => toggleSort("createdAt")}
                >
                  <div className="flex items-center">
                    Date
                    {sortField === "createdAt" && (
                      sortDirection === "asc" ? (
                        <ArrowUp size={14} className="ml-1" />
                      ) : (
                        <ArrowDown size={14} className="ml-1" />
                      )
                    )}
                  </div>
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => toggleSort("amount")}
                >
                  <div className="flex items-center">
                    Montant
                    {sortField === "amount" && (
                      sortDirection === "asc" ? (
                        <ArrowUp size={14} className="ml-1" />
                      ) : (
                        <ArrowDown size={14} className="ml-1" />
                      )
                    )}
                  </div>
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Expéditeur
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Destinataire
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Description
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {sorted.map((t) => (
                <tr key={t.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {t.id}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(t.createdAt).toLocaleString("fr-DZ")}
                  </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {t.type}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {t.amount.toLocaleString("fr-DZ", {
                      style: "currency",
                      currency: "DZD",
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    })}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {t.senderName || "-"}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {t.receiverName || "-"}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {t.description || "-"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}