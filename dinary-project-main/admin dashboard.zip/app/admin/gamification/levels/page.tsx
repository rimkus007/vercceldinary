"use client";

import { useState, useEffect, useCallback } from "react";
import { Trophy, Plus, Edit, Trash2, X, Star, Shield } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { motion, AnimatePresence } from "framer-motion";

// Interface pour les règles de niveau
interface LevelRule {
  id: string;
  level: number;
  name: string;
  xpRequired: number;
  icon?: string;
}

export default function LevelRulesPage() {
  const [levelRules, setLevelRules] = useState<LevelRule[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { token } = useAuth();

  // Rôle sélectionné pour les règles de niveau : 'USER' (clients) ou 'MERCHANT' (commerçants)
  const [ruleRole, setRuleRole] = useState<'USER' | 'MERCHANT'>('USER');

  // États pour le modal de création/édition
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentRule, setCurrentRule] = useState<Partial<LevelRule>>({});

  const fetchLevelRules = useCallback(async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/admin/gamification/level-rules?role=${ruleRole}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      if (!response.ok)
        throw new Error("Impossible de charger les règles de niveaux.");
      const data = await response.json();
      setLevelRules(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [token, ruleRole]);

  useEffect(() => {
    fetchLevelRules();
  }, [fetchLevelRules]);

  // Fonctions de gestion du modal (CRUD)
  const openModalForCreate = () => {
    setIsEditing(false);
    setCurrentRule({
      level:
        (levelRules.length > 0
          ? Math.max(...levelRules.map((r) => r.level))
          : 0) + 1,
      name: "",
      xpRequired: 0,
      icon: "🏆",
    });
    setIsModalOpen(true);
  };

  const openModalForEdit = (rule: LevelRule) => {
    setIsEditing(true);
    setCurrentRule(rule);
    setIsModalOpen(true);
  };

  const closeModal = () => setIsModalOpen(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    setCurrentRule((prev) => ({
      ...prev,
      [name]: type === "number" ? parseInt(value) || 0 : value,
    }));
  };

  const handleSaveRule = async () => {
    if (
      !currentRule.name ||
      currentRule.level == null ||
      currentRule.xpRequired == null
    ) {
      alert("Veuillez remplir tous les champs requis.");
      return;
    }

    const url = isEditing
      ? `${process.env.NEXT_PUBLIC_API_URL}/admin/gamification/level-rules/${currentRule.id}`
      : `${process.env.NEXT_PUBLIC_API_URL}/admin/gamification/level-rules`;
    const method = isEditing ? "PATCH" : "POST";

    try {
      // Transmet le rôle sélectionné pour la règle
      const payload = { ...currentRule, role: ruleRole };
      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.message || "Échec de l'opération.");
      }
      closeModal();
      await fetchLevelRules();
    } catch (err: any) {
      alert("Erreur: " + err.message);
    }
  };

  const handleDeleteRule = async (ruleId: string) => {
    if (
      window.confirm(
        "Êtes-vous sûr de vouloir supprimer cette règle de niveau ?"
      )
    ) {
      try {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/admin/gamification/level-rules/${ruleId}`,
          {
            method: "DELETE",
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        if (!response.ok) throw new Error("Échec de la suppression.");
        await fetchLevelRules();
      } catch (error: any) {
        alert("Erreur: " + error.message);
      }
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return <div className="text-center p-8 text-red-500">{error}</div>;
  }

  return (
    <>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Règles des Niveaux
            </h1>
            <p className="text-gray-600">
              Définissez les paliers de progression pour les{' '}
              {ruleRole === 'MERCHANT' ? 'commerçants' : 'utilisateurs'}.
            </p>
          </div>
          <button
            onClick={openModalForCreate}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <Plus className="w-5 h-5 mr-2" />
            Ajouter un Niveau
          </button>
        </div>

        {/* Sélecteur de rôle pour filtrer les règles selon le public ciblé */}
        <div className="flex items-center space-x-2 mb-4">
          <button
            type="button"
            onClick={() => setRuleRole('USER')}
            className={`px-3 py-1 rounded-md text-sm border transition-colors ${
              ruleRole === 'USER'
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-gray-100 text-gray-700 border-gray-300 hover:bg-gray-200'
            }`}
          >
            Clients
          </button>
          <button
            type="button"
            onClick={() => setRuleRole('MERCHANT')}
            className={`px-3 py-1 rounded-md text-sm border transition-colors ${
              ruleRole === 'MERCHANT'
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-gray-100 text-gray-700 border-gray-300 hover:bg-gray-200'
            }`}
          >
            Commerçants
          </button>
        </div>

        <div className="bg-white rounded-lg shadow-sm border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Icône
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Niveau
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Nom du Niveau
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    XP Requis
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {levelRules.map((rule) => (
                  <tr key={rule.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-2xl">{rule.icon || "🏆"}</td>
                    <td className="px-6 py-4 font-bold text-lg text-gray-800">
                      {rule.level}
                    </td>
                    <td className="px-6 py-4 font-medium text-gray-700">
                      {rule.name}
                    </td>
                    <td className="px-6 py-4 text-blue-600 font-semibold">
                      {rule.xpRequired.toLocaleString()} XP
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button
                        onClick={() => openModalForEdit(rule)}
                        className="btn-icon-secondary mr-2"
                      >
                        <Edit size={16} />
                      </button>
                      <button
                        onClick={() => handleDeleteRule(rule.id)}
                        className="btn-icon-danger"
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
          >
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 50, opacity: 0 }}
              className="bg-white rounded-lg shadow-xl w-full max-w-md"
            >
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSaveRule();
                }}
              >
                <div className="p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-semibold">
                      {isEditing ? "Modifier le Niveau" : "Nouveau Niveau"}
                    </h2>
                    <button
                      type="button"
                      onClick={closeModal}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      <X size={24} />
                    </button>
                  </div>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="label-primary">Niveau</label>
                        <input
                          type="number"
                          name="level"
                          value={currentRule.level || ""}
                          onChange={handleInputChange}
                          className="input-primary"
                          required
                        />
                      </div>
                      <div>
                        <label className="label-primary">Icône (Emoji)</label>
                        <input
                          type="text"
                          name="icon"
                          value={currentRule.icon || ""}
                          onChange={handleInputChange}
                          className="input-primary"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="label-primary">Nom du Niveau</label>
                      <input
                        type="text"
                        name="name"
                        value={currentRule.name || ""}
                        onChange={handleInputChange}
                        className="input-primary"
                        placeholder="Ex: Débutant, Apprenti..."
                        required
                      />
                    </div>
                    <div>
                      <label className="label-primary">XP Requis</label>
                      <input
                        type="number"
                        name="xpRequired"
                        value={currentRule.xpRequired || 0}
                        onChange={handleInputChange}
                        className="input-primary"
                        required
                      />
                    </div>
                  </div>
                </div>
                <div className="bg-gray-50 px-6 py-3 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={closeModal}
                    className="btn-secondary"
                  >
                    Annuler
                  </button>
                  <button type="submit" className="btn-primary">
                    Sauvegarder
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
