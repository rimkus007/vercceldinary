"use client";

import { useState, useEffect, useCallback } from "react";
import {
  Star,
  Users,
  Zap,
  Plus,
  Edit,
  Trash2,
  X,
  Trophy,
  Crown,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { motion, AnimatePresence } from "framer-motion";

// --- INTERFACES POUR LES DONNÉES DYNAMIQUES ---
interface XpRule {
  id: string;
  action: string;
  xpValue: number;
  description: string | null;
  isActive: boolean;
}

interface Level {
  id: string;
  level: number;
  name: string;
  xpRequired: number;
  icon: string;
  isActive: boolean;
}

interface UserProgression {
  id: string;
  username: string;
  currentLevel: number;
  totalXP: number;
  xpToNextLevel: number;
  progressPercentage: number;
}

interface GamificationStats {
  totalUsers: number;
  totalXPAwarded: number;
  activeRules: number;
  avgLevel: number;
}

export default function XPSystemPage() {
  const [xpRules, setXpRules] = useState<XpRule[]>([]);
  const [levels, setLevels] = useState<Level[]>([]);
  const [userProgressions, setUserProgressions] = useState<UserProgression[]>(
    []
  );
  const [stats, setStats] = useState<GamificationStats | null>(null);

  const [activeTab, setActiveTab] = useState<"rules" | "levels" | "users">(
    "rules"
  );
  const [loading, setLoading] = useState(true);
  const { token } = useAuth();

  // Rôle actuellement sélectionné pour l'affichage des règles. "USER" pour les clients,
  // "MERCHANT" pour les commerçants. Permet de charger dynamiquement les règles
  // selon le type de profil ciblé.
  const [ruleRole, setRuleRole] = useState<'USER' | 'MERCHANT'>('USER');

  // États pour le modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentRule, setCurrentRule] = useState<Partial<XpRule>>({});
  const [error, setError] = useState<string | null>(null);

  const fetchAllData = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    setError(null);
    try {
      const [rulesRes, levelsRes, usersRes, statsRes] = await Promise.all([
        fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/admin/gamification/xp-rules?role=${ruleRole}`,
          { headers: { Authorization: `Bearer ${token}` } }
        ),
        // On utilise l'endpoint level-rules plutôt que levels pour récupérer les paliers
        fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/admin/gamification/level-rules?role=${ruleRole}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        ),
        fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/admin/gamification/user-progressions`,
          { headers: { Authorization: `Bearer ${token}` } }
        ),
        fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/gamification/stats`, {
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      if (!rulesRes.ok || !levelsRes.ok || !usersRes.ok || !statsRes.ok) {
        throw new Error("Une partie des données n'a pas pu être chargée.");
      }

      setXpRules(await rulesRes.json());
      setLevels(await levelsRes.json());
      if (ruleRole === 'MERCHANT') {
        // Les progressions et statistiques ne sont pas pertinentes pour les commerçants
        setUserProgressions([]);
        setStats(null);
      } else {
        setUserProgressions(await usersRes.json());
        setStats(await statsRes.json());
      }
    } catch (error: any) {
      console.error("Erreur de chargement des données de gamification:", error);
      setError(error.message || "Impossible de charger les données.");
    } finally {
      setLoading(false);
    }
  }, [token, ruleRole]);

  useEffect(() => {
    fetchAllData();
  }, [fetchAllData]);

  // Fonctions de gestion du modal (CRUD)
  const openModalForCreate = () => {
    setIsEditing(false);
    setCurrentRule({
      action: "",
      xpValue: 10,
      description: "",
      isActive: true,
    });
    setIsModalOpen(true);
    setError(null);
  };

  const openModalForEdit = (rule: XpRule) => {
    setIsEditing(true);
    setCurrentRule(rule);
    setIsModalOpen(true);
    setError(null);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value, type } = e.target;
    if (type === "checkbox") {
      const { checked } = e.target as HTMLInputElement;
      setCurrentRule((prev) => ({ ...prev, [name]: checked }));
    } else {
      setCurrentRule((prev) => ({
        ...prev,
        [name]: type === "number" ? parseInt(value) || 0 : value,
      }));
    }
  };

  const handleSaveRule = async () => {
    if (!currentRule.action || !currentRule.xpValue) {
      setError("L'action et la valeur XP sont requises.");
      return;
    }

    const url = isEditing
      ? `${process.env.NEXT_PUBLIC_API_URL}/admin/gamification/xp-rules/${currentRule.id}`
      : `${process.env.NEXT_PUBLIC_API_URL}/admin/gamification/xp-rules`;
    const method = isEditing ? "PATCH" : "POST";

    try {
      // Inclut le rôle sélectionné dans le payload pour que l'API sache à qui
      // s'applique cette règle. Pour une modification, si le rôle n'a pas été
      // changé, celui-ci sera conservé côté backend.
      const payload = { ...currentRule, role: ruleRole };
      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(
          errData.message || "Échec de la sauvegarde de la règle."
        );
      }
      closeModal();
      await fetchAllData(); // Recharger toutes les données pour être à jour
    } catch (err: any) {
      setError(err.message || "Une erreur est survenue.");
    }
  };

  const handleDeleteRule = async (ruleId: string) => {
    if (window.confirm("Êtes-vous sûr de vouloir supprimer cette règle ?")) {
      try {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/admin/gamification/xp-rules/${ruleId}`,
          {
            method: "DELETE",
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        if (!response.ok) throw new Error("Échec de la suppression.");
        await fetchAllData(); // Recharger les données
      } catch (error) {
        console.error("Erreur de suppression:", error);
        alert("Une erreur est survenue lors de la suppression.");
      }
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <>
      <div className="p-6 max-w-7xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Gestion du Système d'XP
              </h1>
              <p className="text-gray-600">
                Gérez les points d'expérience, les niveaux et la progression des{' '}
                {ruleRole === 'MERCHANT' ? 'commerçants' : 'utilisateurs'}.
              </p>
            </div>
            <button
              onClick={openModalForCreate}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <Plus className="w-5 h-5 mr-2" />
              Ajouter une Règle
            </button>
          </div>

          {/* Sélecteur de rôle pour afficher les règles des clients ou des commerçants */}
          <div className="flex items-center space-x-2 mb-6">
            <button
              type="button"
              onClick={() => setRuleRole('USER')}
              className={`px-3 py-1 rounded-md text-sm border transition-colors ${
                ruleRole === 'USER'
                  ? 'bg-blue-600 text-white border-blue-600'
                  : 'bg-gray-100 text-gray-700 border-gray-300 hover:bg-gray-200'
              }`}
            >
              Clients
            </button>
            <button
              type="button"
              onClick={() => setRuleRole('MERCHANT')}
              className={`px-3 py-1 rounded-md text-sm border transition-colors ${
                ruleRole === 'MERCHANT'
                  ? 'bg-blue-600 text-white border-blue-600'
                  : 'bg-gray-100 text-gray-700 border-gray-300 hover:bg-gray-200'
              }`}
            >
              Commerçants
            </button>
          </div>

          {ruleRole === 'USER' && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <div className="bg-white p-6 rounded-lg shadow-sm border">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      Utilisateurs
                    </p>
                    <p className="text-2xl font-bold">
                      {stats?.totalUsers?.toLocaleString() || 0}
                    </p>
                  </div>
                  <Users className="w-8 h-8 text-blue-500" />
                </div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-sm border">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      XP Distribués
                    </p>
                    <p className="text-2xl font-bold text-green-600">
                      {stats?.totalXPAwarded?.toLocaleString() || 0}
                    </p>
                  </div>
                  <Star className="w-8 h-8 text-green-500" />
                </div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-sm border">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      Règles Actives
                    </p>
                    <p className="text-2xl font-bold text-purple-600">
                      {stats?.activeRules || 0}
                    </p>
                  </div>
                  <Zap className="w-8 h-8 text-purple-500" />
                </div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-sm border">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      Niveau Moyen
                    </p>
                    <p className="text-2xl font-bold text-orange-600">
                      {stats ? stats.avgLevel.toFixed(1) : 0}
                    </p>
                  </div>
                  <Trophy className="w-8 h-8 text-orange-500" />
                </div>
              </div>
            </div>
          )}

          <div className="bg-white rounded-lg shadow-sm border mb-6">
            <div className="border-b border-gray-200">
              <nav className="-mb-px flex">
                <button
                  onClick={() => setActiveTab("rules")}
                  className={`px-6 py-3 text-sm font-medium border-b-2 ${
                    activeTab === "rules"
                      ? "border-blue-500 text-blue-600"
                      : "border-transparent text-gray-500"
                  }`}
                >
                  Règles d'XP
                </button>
                <button
                  onClick={() => setActiveTab("levels")}
                  className={`px-6 py-3 text-sm font-medium border-b-2 ${
                    activeTab === "levels"
                      ? "border-blue-500 text-blue-600"
                      : "border-transparent text-gray-500"
                  }`}
                >
                  Système de Niveaux
                </button>
                <button
                  onClick={() => setActiveTab("users")}
                  className={`px-6 py-3 text-sm font-medium border-b-2 ${
                    activeTab === "users"
                      ? "border-blue-500 text-blue-600"
                      : "border-transparent text-gray-500"
                  }`}
                >
                  Progression Utilisateurs
                </button>
              </nav>
            </div>
            <div className="p-6">
              {activeTab === "rules" && (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          Action
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          Valeur XP
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          Description
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          Statut
                        </th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {xpRules.map((rule) => (
                        <tr key={rule.id}>
                          <td className="px-6 py-4 whitespace-nowrap font-mono text-sm text-gray-800">
                            {rule.action}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-blue-600">
                            {rule.xpValue} XP
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-600 max-w-sm truncate">
                            {rule.description || "-"}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span
                              className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                rule.isActive
                                  ? "bg-green-100 text-green-800"
                                  : "bg-gray-100 text-gray-800"
                              }`}
                            >
                              {rule.isActive ? "Active" : "Inactive"}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button
                              onClick={() => openModalForEdit(rule)}
                              className="text-blue-600 hover:text-blue-900 mr-4"
                            >
                              <Edit size={18} />
                            </button>
                            <button
                              onClick={() => handleDeleteRule(rule.id)}
                              className="text-red-600 hover:text-red-900"
                            >
                              <Trash2 size={18} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              {activeTab === "levels" && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {levels.map((level) => (
                    <div key={level.id} className="border rounded-lg p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{level.icon || "🏆"}</span>
                          <div>
                            <h3 className="text-lg font-semibold">
                              Niveau {level.level}
                            </h3>
                            <p className="text-sm text-gray-600">
                              {level.name}
                            </p>
                          </div>
                        </div>
                        <Crown className="w-6 h-6 text-yellow-500" />
                      </div>
                      <p className="text-sm text-blue-600 font-semibold">
                        XP Requis: {level.xpRequired.toLocaleString()}
                      </p>
                    </div>
                  ))}
                </div>
              )}

              {/* Onglet PROGRESSION UTILISATEURS (maintenant dynamique) */}
              {activeTab === "users" && (
                <div className="space-y-4">
                  {userProgressions.map((user) => (
                    <div key={user.id} className="border rounded-lg p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-lg font-semibold">
                            {user.username}
                          </h3>
                          <p className="text-sm text-gray-600">
                            Niveau {user.currentLevel} •{" "}
                            {user.totalXP.toLocaleString()} XP
                          </p>
                        </div>
                        <div className="text-right w-1/3">
                          <div className="text-sm text-gray-600 mb-1">
                            {user.xpToNextLevel.toLocaleString()} XP pour
                            prochain niveau
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-blue-600 h-2 rounded-full"
                              style={{ width: `${user.progressPercentage}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <AnimatePresence>
        {isModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
          >
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 50, opacity: 0 }}
              className="bg-white rounded-lg shadow-xl w-full max-w-md"
            >
              <div className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-semibold">
                    {isEditing ? "Modifier la Règle" : "Ajouter une Règle"}
                  </h2>
                  <button
                    onClick={closeModal}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <X size={24} />
                  </button>
                </div>
                {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Action
                    </label>
                    <input
                      type="text"
                      name="action"
                      value={currentRule.action || ""}
                      onChange={handleInputChange}
                      className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Ex: transfer, payment, referral"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Valeur XP
                    </label>
                    <input
                      type="number"
                      name="xpValue"
                      value={currentRule.xpValue || 0}
                      onChange={handleInputChange}
                      className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Description
                    </label>
                    <textarea
                      name="description"
                      value={currentRule.description || ""}
                      onChange={handleInputChange}
                      rows={3}
                      className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Décrivez à quoi correspond cette action"
                    />
                  </div>
                  <div className="flex items-center">
                    <input
                      id="isActive"
                      name="isActive"
                      type="checkbox"
                      checked={currentRule.isActive || false}
                      onChange={handleInputChange}
                      className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                    />
                    <label
                      htmlFor="isActive"
                      className="ml-2 block text-sm text-gray-900"
                    >
                      Règle active
                    </label>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 px-6 py-3 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={closeModal}
                  className="px-4 py-2 bg-white border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
                >
                  Annuler
                </button>
                <button
                  type="button"
                  onClick={handleSaveRule}
                  className="px-4 py-2 bg-blue-600 border border-transparent rounded-md text-sm font-medium text-white hover:bg-blue-700"
                >
                  Sauvegarder
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
