"use client";

import { useState, useEffect, useCallback, useMemo } from "react";
import {
  Trophy,
  Medal,
  Crown,
  Star,
  Award,
  TrendingUp,
  Users,
  Zap,
  Search,
  ArrowUp,
  ArrowDown,
  Eye,
  MoreHorizontal,
  Flame,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

// Interface pour les données utilisateur
interface RankedUser {
  id: string;
  username: string;
  level: number;
  totalXP: number;
  weeklyXP: number;
  rank: number;
  previousRank: number;
  achievements: number;
  streakDays: number;
  tier: "bronze" | "silver" | "gold" | "platinum" | "diamond";
}

// Interface pour les statistiques
interface RankingStats {
  totalUsers: number;
  totalXPAwarded: number;
  topPerformer: RankedUser | null;
}

export default function RankingsPage() {
  const [globalRanking, setGlobalRanking] = useState<RankedUser[]>([]);
  const [weeklyRanking, setWeeklyRanking] = useState<RankedUser[]>([]);
  const [stats, setStats] = useState<RankingStats | null>(null);

  const [selectedBoard, setSelectedBoard] = useState<"global" | "weekly">(
    "global"
  );
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { token } = useAuth();

  const fetchData = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    setError(null);
    try {
      const [globalRes, weeklyRes, statsRes] = await Promise.all([
        fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/admin/gamification/rankings`,
          { headers: { Authorization: `Bearer ${token}` } }
        ),
        fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/admin/gamification/rankings/weekly`,
          { headers: { Authorization: `Bearer ${token}` } }
        ),
        fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/gamification/stats`, {
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      if (!globalRes.ok || !weeklyRes.ok || !statsRes.ok)
        throw new Error("Erreur de chargement des données.");

      const globalData = await globalRes.json();
      const weeklyData = await weeklyRes.json();
      const statsData = await statsRes.json();

      setGlobalRanking(globalData);
      setWeeklyRanking(weeklyData);
      setStats({
        totalUsers: statsData.totalUsers,
        totalXPAwarded: statsData.totalXPAwarded,
        topPerformer: globalData[0] || null,
      });
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const displayedUsers = useMemo(() => {
    const users = selectedBoard === "global" ? globalRanking : weeklyRanking;
    if (!searchTerm) return users;
    return users.filter((user) =>
      user.username.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [selectedBoard, globalRanking, weeklyRanking, searchTerm]);

  const getTierColor = (tier: RankedUser["tier"]) => {
    switch (tier) {
      case "bronze":
        return "text-orange-600 bg-orange-100";
      case "silver":
        return "text-gray-600 bg-gray-100";
      case "gold":
        return "text-yellow-600 bg-yellow-100";
      case "platinum":
        return "text-purple-600 bg-purple-100";
      case "diamond":
        return "text-blue-600 bg-blue-100";
      default:
        return "text-gray-600 bg-gray-100";
    }
  };

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown className="w-6 h-6 text-yellow-500" />;
    if (rank === 2) return <Medal className="w-6 h-6 text-gray-400" />;
    if (rank === 3) return <Award className="w-6 h-6 text-orange-500" />;
    return (
      <span className="w-6 h-6 flex items-center justify-center text-sm font-bold text-gray-600">
        #{rank}
      </span>
    );
  };

  const getRankChange = (user: RankedUser) => {
    const change = user.previousRank - user.rank;
    if (change > 0)
      return (
        <div className="flex items-center gap-1 text-green-600">
          <ArrowUp className="w-4 h-4" />
          <span className="text-xs">+{change}</span>
        </div>
      );
    if (change < 0)
      return (
        <div className="flex items-center gap-1 text-red-600">
          <ArrowDown className="w-4 h-4" />
          <span className="text-xs">{change}</span>
        </div>
      );
    return <div className="text-gray-400 text-xs">-</div>;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  if (error) {
    return <div className="text-center p-8 text-red-500">{error}</div>;
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Classements</h1>
          <p className="text-gray-600">
            Suivez les classements et la compétition entre utilisateurs.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <p className="text-sm font-medium text-gray-600">
            Utilisateurs Classés
          </p>
          <p className="text-2xl font-bold text-gray-900">
            {stats?.totalUsers.toLocaleString()}
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <p className="text-sm font-medium text-gray-600">
            Total XP Distribué
          </p>
          <p className="text-2xl font-bold text-purple-600">
            {stats?.totalXPAwarded.toLocaleString()}
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <p className="text-sm font-medium text-gray-600">Meilleur Joueur</p>
          <p className="text-lg font-bold text-orange-600">
            {stats?.topPerformer?.username || "N/A"}
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <p className="text-sm font-medium text-gray-600">XP du Meilleur</p>
          <p className="text-lg font-bold text-green-600">
            {stats?.topPerformer?.totalXP.toLocaleString() || 0} XP
          </p>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border mb-6">
        <div className="p-6 border-b border-gray-200">
          <div className="flex flex-wrap gap-4 items-center">
            <div className="flex gap-2">
              <button
                onClick={() => setSelectedBoard("global")}
                className={`px-4 py-2 rounded-lg text-sm font-medium ${
                  selectedBoard === "global"
                    ? "bg-blue-600 text-white"
                    : "bg-gray-100 hover:bg-gray-200"
                }`}
              >
                Classement Général
              </button>
              <button
                onClick={() => setSelectedBoard("weekly")}
                className={`px-4 py-2 rounded-lg text-sm font-medium ${
                  selectedBoard === "weekly"
                    ? "bg-blue-600 text-white"
                    : "bg-gray-100 hover:bg-gray-200"
                }`}
              >
                Champions de la Semaine
              </button>
            </div>
            <div className="relative ml-auto">
              <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Chercher un utilisateur..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg"
              />
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="th-admin">Rang</th>
                <th className="th-admin">Utilisateur</th>
                <th className="th-admin">Niveau</th>
                <th className="th-admin">
                  {selectedBoard === "weekly" ? "XP Semaine" : "XP Total"}
                </th>
                <th className="th-admin">Succès</th>
                <th className="th-admin">Série</th>
                <th className="th-admin">Changement</th>
                <th className="th-admin">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {displayedUsers.map((user) => (
                <tr key={user.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      {getRankIcon(user.rank)}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center font-semibold">
                        {user.username.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          {user.username}
                        </div>
                        <span
                          className={`px-2 py-1 text-xs font-medium rounded-full ${getTierColor(
                            user.tier
                          )}`}
                        >
                          {user.tier}
                        </span>
                      </div>
                    </div>
                  </td>
                  <td className="td-admin font-medium">{user.level}</td>
                  <td className="td-admin font-semibold text-blue-600">
                    {selectedBoard === "weekly"
                      ? user.weeklyXP.toLocaleString()
                      : user.totalXP.toLocaleString()}
                  </td>
                  <td className="td-admin">
                    <div className="flex items-center gap-2">
                      <Trophy className="w-4 h-4 text-yellow-500" />
                      <span>{user.achievements}</span>
                    </div>
                  </td>
                  <td className="td-admin">
                    <div className="flex items-center gap-2">
                      <Flame className="w-4 h-4 text-orange-500" />
                      <span>{user.streakDays}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">{getRankChange(user)}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button className="btn-icon-secondary">
                        <Eye size={16} />
                      </button>
                      <button className="btn-icon-secondary">
                        <MoreHorizontal size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
