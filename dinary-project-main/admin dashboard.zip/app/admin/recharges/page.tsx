"use client";

import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext"; // Assurez-vous que le chemin est correct

// Interface pour les demandes de recharge
interface RechargeRequest {
  id: string;
  amount: number;
  reference: string | null;
  createdAt: string;
  receiver: {
    user: {
      fullName: string;
      email: string;
    };
  };
}

export default function RechargesPage() {
  const [requests, setRequests] = useState<RechargeRequest[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");
  const { token } = useAuth();

  const fetchRequests = async () => {
    if (!token) return;
    try {
      setIsLoading(true);
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/admin/recharges/pending`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      if (!response.ok) throw new Error("Erreur de chargement des demandes.");
      const data = await response.json();
      setRequests(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchRequests();
  }, [token]);

  const handleProcessRequest = async (
    id: string,
    action: "approve" | "reject"
  ) => {
    const reason = action === "reject" ? prompt("Motif du rejet :") : "";
    if (action === "reject" && !reason) return; // Annulation si aucun motif

    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/admin/recharges/${id}/${action}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ reason }),
        }
      );

      if (!response.ok) throw new Error(`Échec de l'action : ${action}`);

      // Mettre à jour la liste en retirant la demande traitée
      setRequests((prev) => prev.filter((req) => req.id !== id));
      alert(
        `La demande a été ${
          action === "approve" ? "approuvée" : "rejetée"
        } avec succès.`
      );
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">
        Demandes de Recharge en Attente
      </h1>

      {isLoading && <p>Chargement des demandes...</p>}
      {error && <p className="text-red-500">{error}</p>}

      {!isLoading && requests.length === 0 && (
        <p className="text-gray-500">Aucune demande de recharge en attente.</p>
      )}

      <div className="space-y-4">
        {requests.map((req) => (
          <div
            key={req.id}
            className="bg-white p-4 rounded-lg shadow border border-gray-200"
          >
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <p className="text-sm text-gray-500">Utilisateur</p>
                <p className="font-medium">
                  {req.receiver.user.fullName} ({req.receiver.user.email})
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Montant</p>
                <p className="font-bold text-lg">
                  {req.amount.toLocaleString("fr-FR")} DA
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Référence Virement</p>
                <p className="font-mono bg-gray-100 p-1 rounded">
                  {req.reference || "N/A"}
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handleProcessRequest(req.id, "approve")}
                  className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 w-full"
                >
                  Approuver
                </button>
                <button
                  onClick={() => handleProcessRequest(req.id, "reject")}
                  className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 w-full"
                >
                  Rejeter
                </button>
              </div>
            </div>
            <p className="text-xs text-gray-400 mt-2">
              Demandé le: {new Date(req.createdAt).toLocaleString("fr-FR")}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
