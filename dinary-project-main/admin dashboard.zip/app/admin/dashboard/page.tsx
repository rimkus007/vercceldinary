// app/admin/dashboard/page.tsx
"use client";

import { useEffect, useState } from "react";
import StatCard from "@/components/admin/StatCard";
import UserManagement from "@/components/admin/UserManagement";
import MerchantManagement from "@/components/admin/MerchantManagement";
import { useAuth } from "@/contexts/AuthContext";
import {
  Users,
  UserCheck,
  Store,
  Banknote,
  Receipt,
  AlertTriangle,
} from "lucide-react";

// Interface mise à jour pour correspondre à la nouvelle réponse de l'API
interface StatData {
  value: number;
  change?: number;
}

interface DashboardStats {
  totalUsers: StatData;
  activeUsers: StatData;
  totalMerchants: StatData;
  totalVolume: StatData;
  totalTransactions: StatData;
  pendingVerifications: StatData;
}

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { token } = useAuth();

  useEffect(() => {
    if (!token) return;

    const fetchStats = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/admin/stats`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        if (!response.ok)
          throw new Error("Erreur lors du chargement des statistiques.");
        const data: DashboardStats = await response.json();
        setStats(data);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, [token]);

  // Fonction de formatage améliorée
  const formatChangeText = (
    change: number | undefined,
    period: "week" | "month" = "month"
  ) => {
    if (typeof change !== "number" || isNaN(change)) return "";
    const sign = change >= 0 ? "+" : "";
    const periodText = period === "week" ? "vs 7j préc." : "vs mois préc.";
    return `${sign}${change}% ${periodText}`;
  };

  if (loading) return <div className="p-6">Chargement...</div>;
  if (error) return <div className="p-6 text-red-500">Erreur : {error}</div>;

  return (
    <div className="min-h-screen bg-gray-50/50">
      <div className="p-4 xl:p-6">
        <h1 className="text-2xl font-bold mb-6">Tableau de bord</h1>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
          <StatCard
            title="Utilisateurs Totaux"
            value={stats?.totalUsers.value.toLocaleString() ?? 0}
            change={formatChangeText(stats?.totalUsers.change)}
            icon={<Users size={18} />}
          />
          <StatCard
            title="Utilisateurs Actifs"
            value={stats?.activeUsers.value.toLocaleString() ?? 0}
            change={formatChangeText(stats?.activeUsers.change, "week")}
            icon={<UserCheck size={18} />}
          />
          <StatCard
            title="Commerçants"
            value={stats?.totalMerchants.value.toLocaleString() ?? 0}
            change={formatChangeText(stats?.totalMerchants.change)}
            icon={<Store size={18} />}
          />
          <StatCard
            title="Volume Total"
            value={`${stats?.totalVolume.value.toLocaleString() ?? 0} DZD`}
            change={formatChangeText(stats?.totalVolume.change)}
            icon={<Banknote size={18} />}
          />
          <StatCard
            title="Transactions"
            value={stats?.totalTransactions.value.toLocaleString() ?? 0}
            change={formatChangeText(stats?.totalTransactions.change)}
            icon={<Receipt size={18} />}
          />
          <StatCard
            title="Vérifications en attente"
            value={stats?.pendingVerifications.value ?? 0}
            change="Action requise"
            isAlert={stats && stats.pendingVerifications.value > 0}
            icon={<AlertTriangle size={18} />}
          />
        </div>
        <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <UserManagement />
          </div>
          <div className="lg:col-span-1">
            <MerchantManagement />
          </div>
        </div>
      </div>
    </div>
  );
}
