"use client";

import { useState, useEffect, useCallback } from "react";
import dynamic from "next/dynamic";
import {
  Store,
  Users,
  DollarSign,
  TrendingUp,
  Search,
  BellDot,
  Filter,
  Map as MapIcon,
} from "lucide-react";
import MerchantStatCard from "@/components/admin/MerchantStatCard";
import MerchantAnalytics from "@/components/admin/MerchantAnalytics";
import { MERCHANT_CATEGORIES } from "@/types/merchant";
import type { Merchant } from "@/types/merchant";
import type { SuggestedMerchant } from "@/types/suggestion";
import { useAuth } from "@/contexts/AuthContext";

const MapWithNoSSR = dynamic(() => import("@/components/admin/MerchantMap"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full w-full items-center justify-center bg-gray-100">
      Chargement de la carte...
    </div>
  ),
});

export default function MerchantMapPage() {
  // Cette variable contiendra la liste FINALE et COMBINÉE pour la carte
  const [allMerchantsForMap, setAllMerchantsForMap] = useState<Merchant[]>([]);
  const [pendingSuggestions, setPendingSuggestions] = useState<
    SuggestedMerchant[]
  >([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [mapCenter, setMapCenter] = useState<[number, number]>([
    43.70313, 7.26608,
  ]);
  const [searchAreaCenter, setSearchAreaCenter] = useState<
    [number, number] | null
  >(null);
  const [showSearchButton, setShowSearchButton] = useState(false);
  const { token } = useAuth();
  const [activeFilters, setActiveFilters] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [view, setView] = useState<"map" | "analytics">("map");

  // --- LA CORRECTION EST ICI ---
  const fetchMapData = useCallback(
    async (center: [number, number]) => {
      if (!token) return setError("Token administrateur manquant.");
      setLoading(true);
      setError(null);
      setShowSearchButton(false);
      try {
        const [merchantsRes, suggestionsRes] = await Promise.all([
          // 1. On récupère les commerçants "officiels"
          fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/merchants`, {
            headers: { Authorization: `Bearer ${token}` },
          }),
          // 2. On récupère TOUTES les suggestions
          fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/suggestions`, {
            headers: { Authorization: `Bearer ${token}` },
          }),
        ]);

        if (!merchantsRes.ok || !suggestionsRes.ok)
          throw new Error("Erreur lors du chargement des données.");

        const merchantsData = await merchantsRes.json();
        const suggestionsData = await suggestionsRes.json();

        // 3. On formate les commerçants officiels, en s'assurant qu'ils ne sont pas marqués comme suggestion
        const officialMerchants = (
          Array.isArray(merchantsData) ? merchantsData : []
        ).map((m: any) => ({
          ...m,
          isSuggestion: false,
          location: { lat: m.latitude ?? null, lng: m.longitude ?? null },
        }));

        // 4. On filtre et formate les suggestions APPROUVÉES pour les ajouter à la carte
        const approvedSuggestions = (
          Array.isArray(suggestionsData) ? suggestionsData : []
        )
          .filter(
            (s: any) => s.status === "approved" && s.latitude && s.longitude
          )
          .map((s: any) => ({
            id: s.id,
            name: s.name,
            address: s.address,
            category: s.category,
            latitude: s.latitude,
            longitude: s.longitude,
            isSuggestion: true, // On les marque comme "suggestion" pour l'icône
            location: { lat: s.latitude, lng: s.longitude },
            status: "active" as const,
          }));

        // 5. On combine les deux listes en une seule pour la carte
        setAllMerchantsForMap([...officialMerchants, ...approvedSuggestions]);

        // 6. On garde les suggestions EN ATTENTE pour la barre latérale
        const pending = (
          Array.isArray(suggestionsData) ? suggestionsData : []
        ).filter((s) => s.status === "pending");
        setPendingSuggestions(pending);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    },
    [token]
  );

  useEffect(() => {
    if (token) {
      fetchMapData(mapCenter);
    }
  }, [token, fetchMapData, mapCenter]);

  // Le reste du fichier est identique, mais utilise `allMerchantsForMap`

  const handleMapMoveEnd = useCallback((lat: number, lng: number) => {
    setSearchAreaCenter([lat, lng]);
    setShowSearchButton(true);
  }, []);

  const handleSearchZone = () => {
    if (searchAreaCenter) {
      setMapCenter(searchAreaCenter);
      fetchMapData(searchAreaCenter);
    }
  };

  const mapStats = {
    totalMerchants: allMerchantsForMap.length,
    activeMerchants: allMerchantsForMap.filter((m) => m.status === "active")
      .length,
    totalRevenue: allMerchantsForMap.reduce(
      (sum, m) => sum + (m.revenue ?? 0),
      0
    ),
    averageRevenue:
      allMerchantsForMap.length > 0
        ? allMerchantsForMap.reduce((sum, m) => sum + (m.revenue ?? 0), 0) /
          allMerchantsForMap.length
        : 0,
    merchantsByRegion: (() => {
      const getRegion = (m: Merchant) => m.city || "Autre";
      return allMerchantsForMap.reduce((acc, m) => {
        const region = getRegion(m);
        acc[region] = (acc[region] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);
    })(),
    topCities: (() => {
      const cityCounts: Record<string, number> = {};
      allMerchantsForMap.forEach((m) => {
        const city = m.city ?? "Autre";
        cityCounts[city] = (cityCounts[city] || 0) + 1;
      });
      return Object.entries(cityCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([city, count]) => ({ city, count }));
    })(),
  };

  const toggleFilter = (categoryId: string) =>
    setActiveFilters((prev) =>
      prev.includes(categoryId)
        ? prev.filter((id) => id !== categoryId)
        : [...prev, categoryId]
    );

  return (
    <div className="p-6 space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MerchantStatCard
          title="Total Commerçants"
          value={mapStats.totalMerchants}
          Icon={Store}
        />
        <MerchantStatCard
          title="Commerçants Actifs"
          value={mapStats.activeMerchants}
          Icon={Users}
        />
        <MerchantStatCard
          title="Revenus Totaux"
          value={mapStats.totalRevenue}
          Icon={DollarSign}
          format="currency"
        />
        <MerchantStatCard
          title="Revenu Moyen"
          value={mapStats.averageRevenue}
          Icon={TrendingUp}
          format="currency"
        />
      </div>
      <div className="bg-white p-4 rounded-lg shadow-sm border space-y-4">
        <div className="flex flex-col md:flex-row md:items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-dinary-turquoise focus:border-transparent"
              placeholder="Rechercher un commerçant..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setView("map")}
              className={`flex items-center px-4 py-2 rounded-lg ${
                view === "map"
                  ? "bg-dinary-turquoise text-white"
                  : "bg-gray-100 text-gray-600 hover:bg-gray-200"
              }`}
            >
              <MapIcon className="w-5 h-5 mr-2" /> Carte
            </button>
            <button
              onClick={() => setView("analytics")}
              className={`flex items-center px-4 py-2 rounded-lg ${
                view === "analytics"
                  ? "bg-dinary-turquoise text-white"
                  : "bg-gray-100 text-gray-600 hover:bg-gray-200"
              }`}
            >
              <TrendingUp className="w-5 h-5 mr-2" /> Analyses
            </button>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <div className="flex items-center mr-2">
            <Filter className="w-5 h-5 text-gray-400" />
          </div>
          {MERCHANT_CATEGORIES.map((category) => (
            <button
              key={category.id}
              onClick={() => toggleFilter(category.id)}
              className={`flex items-center px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
                activeFilters.includes(category.id)
                  ? "bg-opacity-100 text-white"
                  : "bg-opacity-10 text-gray-600 hover:bg-opacity-20"
              }`}
              style={{
                backgroundColor: activeFilters.includes(category.id)
                  ? category.color
                  : `${category.color}19`,
              }}
            >
              <span className="mr-2">{category.emoji}</span> {category.name}
            </button>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 bg-white rounded-lg shadow-sm border">
          {view === "map" ? (
            <div className="h-[600px] relative rounded-lg overflow-hidden">
              <MapWithNoSSR
                merchants={merchants}
                suggestions={suggestions}
                mapCenter={mapCenter}
                onMoveEnd={handleMapMoveEnd}
                activeFilters={activeFilters}
                searchQuery={searchQuery}
                loading={loading}
              />
              {showSearchButton && (
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-[1000]">
                  <button
                    onClick={handleSearchZone}
                    className="bg-black text-white px-4 py-2 rounded-full shadow-lg text-sm font-semibold flex items-center"
                  >
                    <Search className="w-4 h-4 mr-2" /> Rechercher dans cette
                    zone
                  </button>
                </div>
              )}
              {loading && (
                <div className="absolute inset-0 flex justify-center items-center bg-white bg-opacity-60 z-[999]">
                  <span>Chargement...</span>
                </div>
              )}
              {error && (
                <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-red-100 text-red-700 px-4 py-2 rounded-lg shadow-lg z-[1000]">
                  {error}
                </div>
              )}
            </div>
          ) : (
            <MerchantAnalytics merchants={merchants} />
          )}
        </div>
        <div className="space-y-6">
          <div className="bg-white rounded-lg shadow-sm border p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Suggestions</h3>
              <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-sm font-medium rounded-full">
                {suggestions.length} en attente
              </span>
            </div>
            <div className="space-y-4 max-h-[200px] overflow-y-auto">
              {suggestions.length > 0 ? (
                suggestions.map((suggestion) => (
                  <div
                    key={suggestion.id}
                    className="p-3 bg-gray-50 rounded-lg"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-medium text-gray-900">
                          {suggestion.name}
                        </h4>
                        <p className="text-sm text-gray-600">
                          {suggestion.address}
                        </p>
                      </div>
                      <BellDot className="w-5 h-5 text-yellow-500" />
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-500 text-center py-4">
                  Aucune suggestion pour le moment.
                </p>
              )}
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border p-4">
            <h3 className="text-lg font-semibold mb-4">
              Distribution par Région
            </h3>
            <div className="space-y-3">
              {Object.entries(mapStats.merchantsByRegion).map(
                ([region, count]) => (
                  <div
                    key={region}
                    className="flex items-center justify-between"
                  >
                    <span className="text-gray-600">{region}</span>
                    <span className="font-semibold">{count}</span>
                  </div>
                )
              )}
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border p-4">
            <h3 className="text-lg font-semibold mb-4">Top 5 des Villes</h3>
            <div className="space-y-3">
              {mapStats.topCities.map((city, index) => (
                <div
                  key={city.city}
                  className="flex items-center justify-between"
                >
                  <div className="flex items-center">
                    <span className="w-6 text-sm text-gray-500">
                      #{index + 1}
                    </span>
                    <span className="text-gray-600">{city.city}</span>
                  </div>
                  <span className="font-semibold">{city.count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
