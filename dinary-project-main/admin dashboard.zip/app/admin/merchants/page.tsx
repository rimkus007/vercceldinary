"use client";

import React, { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import { PlusCircle, Search } from "lucide-react";
import { format } from "date-fns";
import { useAuth } from "@/contexts/AuthContext";
import MerchantSuggestionForm from "@/components/admin/MerchantSuggestionForm";

// --- INTERFACES ---
interface Merchant {
  id: string;
  name: string;
  status: "active" | "inactive" | "pending";
  updatedAt: string;
  user: {
    email: string;
  };
}

interface Suggestion {
  id: string;
  name: string;
  address: string;
  category: string;
  status: "pending" | "approved" | "rejected";
  createdAt: string;
  suggestedBy: {
    fullName: string;
    email: string;
    phoneNumber: string;
  };
}

// --- COMPOSANT PRINCIPAL ---
export default function MerchantsPage() {
  const [activeTab, setActiveTab] = useState("overview");
  const [merchants, setMerchants] = useState<Merchant[]>([]);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { token } = useAuth();
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [selectedSuggestion, setSelectedSuggestion] =
    useState<Suggestion | null>(null);

  const fetchData = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    setError(null);
    try {
      const [merchantsRes, suggestionsRes] = await Promise.all([
        fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/merchants`, {
          headers: { Authorization: `Bearer ${token}` },
        }),
        fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/suggestions`, {
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      if (!merchantsRes.ok || !suggestionsRes.ok) {
        throw new Error("Erreur lors du chargement des données.");
      }
      const merchantsData = await merchantsRes.json();
      const suggestionsData = await suggestionsRes.json();

      setMerchants(merchantsData);
      setSuggestions(suggestionsData);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleSuggestionDelete = async (id: string) => {
    if (
      !window.confirm(
        "Voulez-vous vraiment supprimer ce commerçant suggéré ? Il sera définitivement retiré."
      )
    )
      return;
    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/admin/suggestions/${id}`,
        {
          method: "DELETE",
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      if (!response.ok) throw new Error("La suppression a échoué.");
      fetchData();
    } catch (err: any) {
      alert(`Erreur: ${err.message}`);
    }
  };

  const handleSuggestionAction = async (
    id: string,
    action: "approve" | "reject"
  ) => {
    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/admin/suggestions/${id}/${action}`,
        {
          method: "PATCH",
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      if (!response.ok) throw new Error(`L'action a échoué.`);
      if (action === "approve") {
        setActiveTab("approved_suggestions");
      }
      fetchData();
    } catch (err: any) {
      alert(`Erreur: ${err.message}`);
    }
  };

  const pendingSuggestions = suggestions.filter((s) => s.status === "pending");
  const approvedSuggestions = suggestions.filter(
    (s) => s.status === "approved"
  );

  const filteredMerchants = merchants.filter((merchant) => {
    const nameMatch = merchant.name
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const statusMatch =
      selectedStatus === "all" || merchant.status === selectedStatus;
    return nameMatch && statusMatch;
  });

  if (loading) return <div className="p-6">Chargement...</div>;
  if (error) return <div className="p-6 text-red-500">Erreur : {error}</div>;

  return (
    <>
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="sm:flex sm:items-center">
          <div className="sm:flex-auto">
            <h1 className="text-xl font-semibold text-gray-900">Commerçants</h1>
            <p className="mt-2 text-sm text-gray-700">
              Gérez les commerçants et leurs suggestions.
            </p>
          </div>
          <div className="mt-4 sm:mt-0 sm:ml-16 sm:flex-none">
            <button
              onClick={() => router.push("/admin/merchants/nouveau")}
              type="button"
              className="inline-flex items-center rounded-md border border-transparent bg-dinary-turquoise px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-dinary-turquoise-dark focus:outline-none focus:ring-2 focus:ring-dinary-turquoise focus:ring-offset-2"
            >
              <PlusCircle className="mr-2 -ml-1 h-5 w-5" /> Nouveau commerçant
            </button>
          </div>
        </div>

        <div className="mt-8">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8" aria-label="Onglets">
              <button
                onClick={() => setActiveTab("overview")}
                className={`${
                  activeTab === "overview"
                    ? "border-dinary-turquoise text-dinary-turquoise"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
              >
                Commerçants
              </button>
              <button
                onClick={() => setActiveTab("approved_suggestions")}
                className={`${
                  activeTab === "approved_suggestions"
                    ? "border-dinary-turquoise text-dinary-turquoise"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center`}
              >
                Commerçants Suggérés
                {approvedSuggestions.length > 0 && (
                  <span className="ml-3 py-0.5 px-2.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    {approvedSuggestions.length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab("suggestions")}
                className={`${
                  activeTab === "suggestions"
                    ? "border-dinary-turquoise text-dinary-turquoise"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center`}
              >
                Suggestions en attente
                {pendingSuggestions.length > 0 && (
                  <span className="ml-3 py-0.5 px-2.5 rounded-full text-xs font-medium bg-dinary-turquoise text-white">
                    {pendingSuggestions.length}
                  </span>
                )}
              </button>
            </nav>
          </div>

          {activeTab === "overview" && (
            <div className="mt-6">
              <div className="mt-6 flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0">
                <div className="w-full sm:max-w-xs relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="block w-full rounded-md border-gray-300 pl-10 focus:border-dinary-turquoise focus:ring-dinary-turquoise sm:text-sm"
                    placeholder="Rechercher..."
                  />
                </div>
                <div className="flex items-center space-x-4">
                  <select
                    value={selectedStatus}
                    onChange={(e) => setSelectedStatus(e.target.value)}
                    className="block w-full rounded-md border-gray-300 py-2 pl-3 pr-10 text-base focus:border-dinary-turquoise focus:outline-none focus:ring-dinary-turquoise sm:text-sm"
                  >
                    <option value="all">Tous les statuts</option>
                    <option value="active">Actifs</option>
                    <option value="inactive">Inactifs</option>
                    <option value="pending">En attente</option>
                  </select>
                </div>
              </div>
              <div className="mt-8 flex flex-col">
                <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                  <div className="inline-block min-w-full py-2 align-middle">
                    <table className="min-w-full divide-y divide-gray-300">
                      <thead>
                        <tr>
                          <th
                            scope="col"
                            className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6 lg:pl-8"
                          >
                            Commerçant
                          </th>
                          <th
                            scope="col"
                            className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900"
                          >
                            Statut
                          </th>
                          <th
                            scope="col"
                            className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900"
                          >
                            Dernière activité
                          </th>
                          <th
                            scope="col"
                            className="relative py-3.5 pl-3 pr-4 sm:pr-6 lg:pr-8"
                          >
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200 bg-white">
                        {filteredMerchants.map((merchant) => (
                          <tr key={merchant.id} className="hover:bg-gray-50">
                            <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6 lg:pl-8">
                              {merchant.name}
                            </td>
                            <td className="whitespace-nowrap px-3 py-4 text-sm">
                              <span
                                className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${
                                  merchant.status === "active"
                                    ? "bg-green-100 text-green-800"
                                    : merchant.status === "inactive"
                                    ? "bg-red-100 text-red-800"
                                    : "bg-yellow-100 text-yellow-800"
                                }`}
                              >
                                {merchant.status}
                              </span>
                            </td>
                            <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                              {format(
                                new Date(merchant.updatedAt),
                                "dd/MM/yyyy"
                              )}
                            </td>
                            <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-6 lg:pr-8">
                              <button className="text-dinary-turquoise hover:text-dinary-turquoise-dark">
                                Voir détails
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "approved_suggestions" && (
            <div className="mt-6">
              <div className="mt-8 flex flex-col">
                {approvedSuggestions.length === 0 ? (
                  <p className="text-center text-gray-500 py-8">
                    Aucun commerçant suggéré et approuvé.
                  </p>
                ) : (
                  <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                    <div className="inline-block min-w-full py-2 align-middle">
                      <table className="min-w-full divide-y divide-gray-300">
                        <thead>
                          <tr>
                            <th
                              scope="col"
                              className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6 lg:pl-8"
                            >
                              Commerçant
                            </th>
                            <th
                              scope="col"
                              className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900"
                            >
                              Adresse
                            </th>
                            <th
                              scope="col"
                              className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900"
                            >
                              Date d'Approbation
                            </th>
                            <th
                              scope="col"
                              className="relative py-3.5 pl-3 pr-4 sm:pr-6 lg:pr-8"
                            >
                              <span className="sr-only">Actions</span>
                            </th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200 bg-white">
                          {approvedSuggestions.map((suggestion) => (
                            <tr key={suggestion.id}>
                              <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6 lg:pl-8">
                                {suggestion.name}
                              </td>
                              <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                {suggestion.address}
                              </td>
                              <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                {format(
                                  new Date(suggestion.createdAt),
                                  "dd/MM/yyyy"
                                )}
                              </td>
                              <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-6 lg:pr-8">
                                <button
                                  onClick={() =>
                                    handleSuggestionDelete(suggestion.id)
                                  }
                                  className="text-red-600 hover:text-red-900"
                                >
                                  Supprimer
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === "suggestions" && (
            <div className="mt-6">
              {pendingSuggestions.length === 0 ? (
                <p className="text-center text-gray-500 py-8">
                  Aucune suggestion en attente.
                </p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {pendingSuggestions.map((suggestion) => (
                    <div
                      key={suggestion.id}
                      className="bg-white border rounded-lg shadow-sm p-5 flex flex-col justify-between cursor-pointer hover:shadow-lg transition-shadow"
                      onClick={() => setSelectedSuggestion(suggestion)}
                    >
                      <div>
                        <div className="flex justify-between items-start">
                          <h3 className="font-bold text-lg">
                            {suggestion.name}
                          </h3>
                          <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">
                            En attente
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">
                          {suggestion.address}
                        </p>
                        <p className="text-sm text-gray-500 capitalize">
                          {suggestion.category}
                        </p>
                        <div className="mt-4 border-t pt-3">
                          <p className="text-xs text-gray-500 mb-1">
                            Suggéré par :
                          </p>
                          <p className="font-medium">
                            {suggestion.suggestedBy.fullName}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {selectedSuggestion && (
        <MerchantSuggestionForm
          suggestion={{
            ...selectedSuggestion,
            suggestedAt: selectedSuggestion.createdAt,
            location: {
              lat: selectedSuggestion.latitude,
              lng: selectedSuggestion.longitude,
            },
            suggestedBy: {
              id: "",
              name: selectedSuggestion.suggestedBy.fullName,
              phone: selectedSuggestion.suggestedBy.phoneNumber || "Non fourni",
            },
          }}
          onClose={() => setSelectedSuggestion(null)}
          onApprove={() => {
            handleSuggestionAction(selectedSuggestion.id, "approve");
            setSelectedSuggestion(null);
          }}
          onReject={() => {
            handleSuggestionAction(selectedSuggestion.id, "reject");
            setSelectedSuggestion(null);
          }}
        />
      )}
    </>
  );
}
