'use client'

import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { 
  MessageSquare, Search, Users, Send, 
  Paperclip, Smile, MoreVertical, Phone,
  Video, Info, ArrowDown, Clock, UserPlus,
  ChevronDown, ChevronRight, CheckCircle
} from 'lucide-react';

// Interfaces for conversations and messages
interface ChatMessage {
  id: string;
  senderId: string;
  content: string;
  timestamp: string;
  read: boolean;
}

interface Conversation {
  id: string; // user id
  user: {
    id: string;
    name: string;
    avatar: string;
    status: 'online' | 'away' | 'offline';
    lastSeen: string | Date;
    isBusiness?: boolean;
  };
  lastMessage: ChatMessage | null;
  unreadCount: number;
}

// Fonction pour formater la date
const formatMessageTime = (dateString) => {
  const date = new Date(dateString);
  const now = new Date();
  const diffDays = Math.floor((now - date) / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) {
    // Aujourd'hui, montrer uniquement l'heure
    return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  } else if (diffDays === 1) {
    // Hier
    return `Hier ${date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}`;
  } else if (diffDays < 7) {
    // Cette semaine
    return date.toLocaleDateString('fr-FR', { weekday: 'long' });
  } else {
    // Plus d'une semaine
    return date.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' });
  }
};

export default function MessagesPage() {
  const { token } = useAuth();
  // Conversations list fetched from backend
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [filteredConversations, setFilteredConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  // Messages for the selected conversation
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [newMessage, setNewMessage] = useState('');
  const [loadingConversations, setLoadingConversations] = useState<boolean>(true);
  const [loadingMessages, setLoadingMessages] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch conversations on mount or when token changes
  useEffect(() => {
    if (!token) return;
    const fetchConversations = async () => {
      setLoadingConversations(true);
      setError(null);
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/messages`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) throw new Error('Impossible de charger les conversations.');
        const data: any[] = await res.json();
        setConversations(data);
        setFilteredConversations(data);
        if (data.length > 0) {
          setActiveConversationId(data[0].id);
        }
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoadingConversations(false);
      }
    };
    fetchConversations();
  }, [token]);

  // Fetch messages when active conversation changes
  useEffect(() => {
    if (!token || !activeConversationId) return;
    const fetchMessages = async () => {
      setLoadingMessages(true);
      setError(null);
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/messages/${activeConversationId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) throw new Error("Impossible de charger l'historique de conversation.");
        const data: any[] = await res.json();
        // update messages state
        setMessages(data);
        // mark conversation as read by setting unreadCount to 0 locally and updating lastMessage
        setConversations((prev) =>
          prev.map((conv) =>
            conv.id === activeConversationId
              ? {
                  ...conv,
                  unreadCount: 0,
                  lastMessage: data.length > 0 ? data[data.length - 1] : conv.lastMessage,
                }
              : conv,
          ),
        );
        // Also update filteredConversations accordingly
        setFilteredConversations((prev) =>
          prev.map((conv) =>
            conv.id === activeConversationId
              ? {
                  ...conv,
                  unreadCount: 0,
                  lastMessage: data.length > 0 ? data[data.length - 1] : conv.lastMessage,
                }
              : conv,
          ),
        );
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoadingMessages(false);
      }
    };
    fetchMessages();
  }, [token, activeConversationId]);

  // Filter conversations based on search term
  const handleSearch = (e: any) => {
    const term = e.target.value.toLowerCase();
    setSearchTerm(term);
    if (term === '') {
      setFilteredConversations(conversations);
    } else {
      const filtered = conversations.filter((conv) => conv.user.name.toLowerCase().includes(term));
      setFilteredConversations(filtered);
    }
  };

  // Current conversation object and last messages fetched
  const currentConversation = conversations.find((conv) => conv.id === activeConversationId) || null;

  // Send a new message to the backend and update state
  const handleSendMessage = async (e: any) => {
    e.preventDefault();
    if (!newMessage.trim() || !activeConversationId) return;
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/admin/messages/${activeConversationId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ content: newMessage.trim() }),
      });
      if (!res.ok) throw new Error('Échec de l\'envoi du message.');
      const newMsg: ChatMessage = await res.json();
      // Append to messages list
      setMessages((prev) => [...prev, newMsg]);
      // Update last message in conversation list
      setConversations((prev) =>
        prev.map((conv) =>
          conv.id === activeConversationId
            ? { ...conv, lastMessage: newMsg }
            : conv,
        ),
      );
      setFilteredConversations((prev) =>
        prev.map((conv) =>
          conv.id === activeConversationId
            ? { ...conv, lastMessage: newMsg }
            : conv,
        ),
      );
      // Clear input
      setNewMessage('');
    } catch (err: any) {
      setError(err.message);
    }
  };

  // Show loading or error states
  if (loadingConversations) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-64px)]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  if (error) {
    return (
      <div className="p-6 text-red-600">{error}</div>
    );
  }
  
  return (
    <div className="flex h-[calc(100vh-64px)] -mx-6 -mb-6 overflow-hidden">
      {/* Sidebar - Conversations List */}
      <div className="w-80 border-r bg-white flex flex-col">
        {/* Search */}
        <div className="p-4 border-b">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Rechercher une conversation..."
              className="w-full pl-10 pr-4 py-2 rounded-lg border focus:border-dinary-turquoise focus:outline-none text-sm"
              value={searchTerm}
              onChange={handleSearch}
            />
          </div>
        </div>
        
        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto">
          {filteredConversations.length === 0 ? (
            <div className="p-4 text-center text-gray-500">
              Aucune conversation trouvée.
            </div>
          ) : (
            filteredConversations.map((conv) => (
              <div
                key={conv.id}
                className={`p-3 border-b hover:bg-gray-50 cursor-pointer ${
                  conv.id === activeConversationId ? 'bg-dinary-turquoise/10 border-l-4 border-l-dinary-turquoise' : ''
                }`}
                onClick={() => setActiveConversationId(conv.id)}
              >
                <div className="flex items-center">
                  <div className="relative">
                    <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center text-gray-600 font-medium">
                      {conv.user.name.charAt(0)}
                    </div>
                    <div className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-white ${
                      conv.user.status === 'online' ? 'bg-green-500' :
                      conv.user.status === 'away' ? 'bg-yellow-500' : 'bg-gray-400'
                    }`}></div>
                  </div>
                  
                  <div className="ml-3 flex-1">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <h3 className="text-sm font-medium text-gray-900">{conv.user.name}</h3>
                        {conv.user.isBusiness && (
                          <span className="ml-1.5 bg-blue-100 text-blue-800 text-xs px-1.5 py-0.5 rounded">
                            Pro
                          </span>
                        )}
                      </div>
                      <span className="text-xs text-gray-500">
                        {conv.lastMessage ? formatMessageTime(conv.lastMessage.timestamp) : ''}
                      </span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <p className="text-xs text-gray-500 truncate w-40">
                        {conv.lastMessage ? conv.lastMessage.content : 'Nouvelle conversation'}
                      </p>
                      
                      {conv.unreadCount > 0 && (
                        <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-dinary-turquoise text-white text-xs">
                          {conv.unreadCount}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
        
        {/* New Conversation Button */}
        <div className="p-4 border-t">
          <button className="btn-primary w-full flex items-center justify-center">
            <MessageSquare size={16} className="mr-2" /> Nouvelle conversation
          </button>
        </div>
      </div>
      
      {/* Main Content - Chat */}
      <div className="flex-1 flex flex-col bg-gray-50">
        {currentConversation ? (
          <>
            {/* Chat Header */}
            <div className="h-16 border-b bg-white flex items-center justify-between px-4">
              <div className="flex items-center">
                <div className="relative">
                  <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-600 font-medium">
                    {currentConversation.user.name.charAt(0)}
                  </div>
                  <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${
                    currentConversation.user.status === 'online' ? 'bg-green-500' :
                    currentConversation.user.status === 'away' ? 'bg-yellow-500' : 'bg-gray-400'
                  }`}></div>
                </div>
                
                <div className="ml-3">
                  <h3 className="text-sm font-medium">{currentConversation.user.name}</h3>
                  <p className="text-xs text-gray-500">
                    {currentConversation.user.status === 'online' 
                      ? 'En ligne'
                      : currentConversation.user.status === 'away'
                      ? 'Absent(e)'
                      : `Dernière connexion ${formatMessageTime(currentConversation.user.lastSeen)}`
                    }
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <button className="p-2 rounded-full hover:bg-gray-100 text-gray-500">
                  <Phone size={18} />
                </button>
                <button className="p-2 rounded-full hover:bg-gray-100 text-gray-500">
                  <Video size={18} />
                </button>
                <button className="p-2 rounded-full hover:bg-gray-100 text-gray-500">
                  <Info size={18} />
                </button>
                <button className="p-2 rounded-full hover:bg-gray-100 text-gray-500">
                  <MoreVertical size={18} />
                </button>
              </div>
            </div>
            
            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4">
              {messages.map((message, index) => {
                const isAdmin = message.senderId === 'admin';
                const previousMessage = index > 0 ? messages[index - 1] : null;
                const showSenderInfo = !previousMessage || previousMessage.senderId !== message.senderId;
                return (
                  <div
                    key={message.id}
                    className={`flex ${isAdmin ? 'justify-end' : 'justify-start'} mb-3`}
                  >
                    {!isAdmin && showSenderInfo && currentConversation && (
                      <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-gray-600 font-medium mr-2">
                        {currentConversation.user.name.charAt(0)}
                      </div>
                    )}
                    <div className={`max-w-[70%] ${!isAdmin && !showSenderInfo ? 'ml-10' : ''}`}>
                      {showSenderInfo && currentConversation && (
                        <div className={`flex items-center mb-1 ${isAdmin ? 'justify-end' : 'justify-start'}`}>
                          <span className="text-xs font-medium text-gray-500">
                            {isAdmin ? 'Vous' : currentConversation.user.name}
                          </span>
                          <span className="text-xs text-gray-400 ml-2">
                            {formatMessageTime(message.timestamp)}
                          </span>
                        </div>
                      )}
                      <div
                        className={`rounded-lg py-2 px-3 inline-block ${
                          isAdmin ? 'bg-dinary-turquoise text-white' : 'bg-white text-gray-800 border'
                        }`}
                      >
                        {message.content}
                      </div>
                      {isAdmin && (
                        <div className="flex justify-end mt-1">
                          {message.read ? (
                            <CheckCircle size={14} className="text-dinary-turquoise" />
                          ) : (
                            <Clock size={14} className="text-gray-400" />
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
            
            {/* Input Area */}
            <div className="border-t bg-white p-4">
              <form onSubmit={handleSendMessage} className="flex items-end">
                <button type="button" className="text-gray-400 hover:text-gray-600 mr-2">
                  <Paperclip size={20} />
                </button>
                
                <div className="flex-1 border rounded-lg focus-within:border-dinary-turquoise focus-within:ring-1 focus-within:ring-dinary-turquoise">
                  <textarea
                    className="w-full px-3 py-2 focus:outline-none rounded-lg resize-none"
                    placeholder="Écrivez votre message..."
                    rows={3}
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                  ></textarea>
                </div>
                
                <div className="ml-2 flex items-center">
                  <button type="button" className="text-gray-400 hover:text-gray-600 mr-2">
                    <Smile size={20} />
                  </button>
                  
                  <button
                    type="submit"
                    className={`p-2 rounded-full ${
                      newMessage.trim() === '' 
                        ? 'bg-gray-200 text-gray-500 cursor-not-allowed' 
                        : 'bg-dinary-turquoise text-white'
                    }`}
                    disabled={newMessage.trim() === ''}
                  >
                    <Send size={18} />
                  </button>
                </div>
              </form>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center">
            <MessageSquare size={64} className="text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-500">Sélectionnez une conversation</h3>
            <p className="text-sm text-gray-400 mt-2">
              Choisissez une conversation dans la liste ou créez-en une nouvelle.
            </p>
          </div>
        )}
      </div>
      
      {/* Info Panel - Optional */}
      <div className="w-64 border-l bg-white hidden lg:block p-4">
        <h3 className="text-sm font-semibold text-gray-700 mb-4">Informations</h3>
        
        {currentConversation && (
          <div>
            <div className="flex flex-col items-center mb-6">
              <div className="w-20 h-20 rounded-full bg-gray-200 flex items-center justify-center text-gray-600 text-2xl font-medium mb-2">
                {currentConversation.user.name.charAt(0)}
              </div>
              <h3 className="font-medium">{currentConversation.user.name}</h3>
              <p className="text-xs text-gray-500">ID: {currentConversation.user.id}</p>
            </div>
            
            <div className="space-y-4">
              <div className="border-t pt-4">
                <h4 className="text-xs font-semibold text-gray-500 uppercase mb-2">Actions</h4>
                <div className="space-y-2">
                  <button className="btn-secondary w-full flex items-center justify-center text-xs py-1.5">
                    <UserPlus size={14} className="mr-1.5" />
                    Ajouter à un groupe
                  </button>
                  <button className="btn-secondary w-full flex items-center justify-center text-xs py-1.5">
                    <Info size={14} className="mr-1.5" />
                    Voir le profil
                  </button>
                </div>
              </div>
              
              <div className="border-t pt-4">
                <h4 className="text-xs font-semibold text-gray-500 uppercase mb-2">Fichiers partagés</h4>
                <div className="text-xs text-gray-500 text-center py-2">
                  Aucun fichier partagé
                </div>
              </div>
              
              <div className="border-t pt-4">
                <h4 className="flex items-center justify-between text-xs font-semibold text-gray-500 uppercase mb-2">
                  <span>Étiquettes</span>
                  <button className="text-dinary-turquoise">Ajouter</button>
                </h4>
                <div className="flex flex-wrap gap-1">
                  <span className="text-xs px-2 py-1 bg-blue-100 text-blue-800 rounded-full">
                    Support
                  </span>
                  <span className="text-xs px-2 py-1 bg-green-100 text-green-800 rounded-full">
                    Active
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
