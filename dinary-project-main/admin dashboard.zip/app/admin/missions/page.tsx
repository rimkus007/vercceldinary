"use client";

import { useState, useEffect, useCallback, useMemo } from "react";
import {
  Target,
  Search,
  Filter,
  CheckCircle,
  Award,
  Calendar,
  Trophy,
  Star,
  Users,
  Plus,
  Trash2,
  Edit,
  Eye,
  ChevronDown,
  Clock,
  X,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

// Interface alignée avec le backend (Prisma Schema et DTO)
interface Mission {
  id: string;
  title: string;
  description: string;
  xpReward: number;
  goal: number;
  type: string;
  icon: string;
  status: "ACTIVE" | "DRAFT";
  createdAt: string;
  updatedAt: string;
}

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001/api";

export default function MissionsPage() {
  const [missions, setMissions] = useState<Mission[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // State pour le modal de création/édition
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingMission, setEditingMission] = useState<Mission | null>(null);

  // State pour les filtres et la recherche
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  // Récupérer les missions depuis le backend
  const fetchMissions = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      // TODO: Remplacer par le vrai token de l'admin
      const token = localStorage.getItem("dinary_admin_access_token");
      const response = await fetch(`${API_URL}/admin/missions`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!response.ok) throw new Error("Erreur de récupération des missions");
      const data = await response.json();
      setMissions(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchMissions();
  }, [fetchMissions]);

  // Logique de filtrage
  const filteredMissions = useMemo(() => {
    return missions.filter((mission) => {
      const matchesSearch =
        searchTerm === "" ||
        mission.title.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus =
        statusFilter === "all" || mission.status.toLowerCase() === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [missions, searchTerm, statusFilter]);

  // Fonctions pour ouvrir le modal
  const handleOpenCreateModal = () => {
    setEditingMission(null);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (mission: Mission) => {
    setEditingMission(mission);
    setIsModalOpen(true);
  };

  // Fonction pour supprimer une mission
  const handleDeleteMission = async (missionId: string) => {
    if (!window.confirm("Êtes-vous sûr de vouloir supprimer cette mission ?")) {
      return;
    }
    try {
      const token = localStorage.getItem("dinary_admin_access_token");
      const response = await fetch(`${API_URL}/admin/missions/${missionId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!response.ok) {
        throw new Error("La suppression a échoué");
      }
      // Rafraîchir la liste après la suppression
      fetchMissions();
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-6">
      {/* En-tête de la page */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold flex items-center">
            <Target className="mr-2" /> Gestion des missions
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Créez et gérez les défis pour vos utilisateurs.
          </p>
        </div>
        <button className="btn-primary" onClick={handleOpenCreateModal}>
          <Plus size={16} className="mr-1" /> Nouvelle mission
        </button>
      </div>

      {/* Filtres */}
      <div className="flex gap-4">
        <div className="relative flex-grow">
          <Search
            size={18}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
          />
          <input
            type="text"
            placeholder="Rechercher par titre..."
            className="input-primary pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <select
          className="select-primary"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="all">Tous les statuts</option>
          <option value="ACTIVE">Actives</option>
          <option value="DRAFT">Brouillons</option>
        </select>
      </div>

      {/* Tableau des missions */}
      <div className="bg-white rounded-lg shadow overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="th-admin">Titre</th>
              <th className="th-admin">Type</th>
              <th className="th-admin">Récompense XP</th>
              <th className="th-admin">Objectif</th>
              <th className="th-admin">Statut</th>
              <th className="th-admin">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {isLoading ? (
              <tr>
                <td colSpan={6} className="p-4 text-center">
                  Chargement...
                </td>
              </tr>
            ) : error ? (
              <tr>
                <td colSpan={6} className="p-4 text-center text-red-500">
                  {error}
                </td>
              </tr>
            ) : (
              filteredMissions.map((mission) => (
                <tr key={mission.id}>
                  <td className="td-admin font-medium">{mission.title}</td>
                  <td className="td-admin">{mission.type}</td>
                  <td className="td-admin">{mission.xpReward} XP</td>
                  <td className="td-admin">{mission.goal}</td>
                  <td className="td-admin">
                    <span
                      className={`badge ${
                        mission.status === "ACTIVE"
                          ? "badge-success"
                          : "badge-info"
                      }`}
                    >
                      {mission.status === "ACTIVE" ? "Actif" : "Brouillon"}
                    </span>
                  </td>
                  <td className="td-admin">
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleOpenEditModal(mission)}
                        className="btn-icon-secondary"
                      >
                        <Edit size={16} />
                      </button>
                      <button
                        onClick={() => handleDeleteMission(mission.id)}
                        className="btn-icon-danger"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Modal pour créer/modifier une mission */}
      <AnimatePresence>
        {isModalOpen && (
          <MissionFormModal
            mission={editingMission}
            onClose={() => setIsModalOpen(false)}
            onSave={fetchMissions} // Rafraîchit la liste après sauvegarde
          />
        )}
      </AnimatePresence>
    </div>
  );
}

// --- Composant Modal pour le formulaire ---
const MissionFormModal = ({ mission, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    title: mission?.title || "",
    description: mission?.description || "",
    xpReward: mission?.xpReward || 0,
    goal: mission?.goal || 1,
    type: mission?.type || "",
    icon: mission?.icon || "🎯",
    status: mission?.status || "DRAFT",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]:
        type === "checkbox"
          ? checked
          : name === "xpReward" || name === "goal"
          ? parseInt(value)
          : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    const token = localStorage.getItem("dinary_admin_access_token");
    const url = mission
      ? `${API_URL}/admin/missions/${mission.id}`
      : `${API_URL}/admin/missions`;
    const method = mission ? "PATCH" : "POST";

    try {
      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });
      if (!response.ok) throw new Error("Échec de l'opération");
      onSave(); // Appelle fetchMissions sur la page parente
      onClose();
    } catch (error) {
      alert(error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <motion.div
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div
        className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: -50, opacity: 0 }}
      >
        <form onSubmit={handleSubmit}>
          <div className="p-6 border-b">
            <h2 className="text-xl font-bold">
              {mission ? "Modifier la mission" : "Créer une mission"}
            </h2>
          </div>
          <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
            {/* Champs du formulaire */}
            <div>
              <label className="label-primary">Titre</label>
              <input
                name="title"
                value={formData.title}
                onChange={handleChange}
                className="input-primary"
                required
              />
            </div>
            <div>
              <label className="label-primary">Description</label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleChange}
                className="input-primary"
                rows={3}
              ></textarea>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label-primary">Récompense XP</label>
                <input
                  name="xpReward"
                  type="number"
                  value={formData.xpReward}
                  onChange={handleChange}
                  className="input-primary"
                  required
                />
              </div>
              <div>
                <label className="label-primary">Objectif (quantité)</label>
                <input
                  name="goal"
                  type="number"
                  value={formData.goal}
                  onChange={handleChange}
                  className="input-primary"
                  required
                />
              </div>
            </div>
            <div>
              <label className="label-primary">Type de mission</label>
              <select
                name="type"
                value={formData.type}
                onChange={handleChange}
                className="select-primary"
                required
              >
                <option value="">Sélectionner...</option>
                <option value="TRANSFER">Transfert</option>
                <option value="PAYMENT">Paiement</option>
                <option value="RECHARGE">Recharge</option>
                <option value="CUSTOM">Personnalisé</option>
              </select>
              <p className="text-xs text-gray-500 mt-1">
                Choisissez le type d'action qui déclenche la mission. <br />
                <b>TRANSFER</b> = Transfert d'argent, <b>PAYMENT</b> = Paiement
                QR, <b>RECHARGE</b> = Recharge portefeuille.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label-primary">Icône (Emoji)</label>
                <input
                  name="icon"
                  value={formData.icon}
                  onChange={handleChange}
                  className="input-primary"
                />
              </div>
              <div>
                <label className="label-primary">Statut</label>
                <select
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                  className="select-primary"
                >
                  <option value="DRAFT">Brouillon</option>
                  <option value="ACTIVE">Actif</option>
                </select>
              </div>
            </div>
          </div>
          <div className="p-4 bg-gray-50 flex justify-end gap-3">
            <button type="button" onClick={onClose} className="btn-secondary">
              Annuler
            </button>
            <button
              type="submit"
              className="btn-primary"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Sauvegarde..." : "Sauvegarder"}
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
};
