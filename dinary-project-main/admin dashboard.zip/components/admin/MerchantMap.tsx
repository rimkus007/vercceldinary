"use client";

import { useMemo } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import {
  MapContainer,
  TileLayer,
  Marker,
  Popup,
  useMapEvents,
} from "react-leaflet";
import type { Merchant } from "@/types/merchant";
import { MERCHANT_CATEGORIES } from "@/types/merchant";

// --- CONFIGURATION DES ICÔNES ---
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "/images/leaflet/marker-icon-2x.png",
  iconUrl: "/images/leaflet/marker-icon.png",
  shadowUrl: "/images/leaflet/marker-shadow.png",
});

// Fonction pour créer les icônes des commerçants officiels
const createEmojiIcon = (emoji: string, color: string) => {
  return L.divIcon({
    html: `<div style="background-color: ${color}; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.2); border: 2px solid white;">${emoji}</div>`,
    className: "emoji-marker",
    iconSize: [36, 36],
    iconAnchor: [18, 18],
  });
};

// --- MODIFICATION: Icône spéciale pour les commerçants suggérés ---
const suggestedMerchantIcon = createEmojiIcon("🌟", "#14B8A6"); // Emoji étoile sur fond turquoise

// Icône pour les suggestions en attente (non approuvées)
const pendingSuggestionIcon = new L.Icon({
  iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
  iconRetinaUrl:
    "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",
  shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
  className: "leaflet-marker-suggestion", // Style pour la rendre grisée
});

interface MerchantMapProps {
  merchants: Merchant[];
  suggestions?: any[];
  mapCenter: [number, number];
  onMoveEnd: (lat: number, lng: number) => void;
  activeFilters?: string[];
  searchQuery?: string;
  loading: boolean;
}

function MapEventsHandler({
  onMoveEnd,
}: {
  onMoveEnd: (lat: number, lng: number) => void;
}) {
  useMapEvents({
    moveend: (e) => {
      const center = e.target.getCenter();
      onMoveEnd(center.lat, center.lng);
    },
  });
  return null;
}

export default function MerchantMap({
  merchants,
  suggestions = [],
  mapCenter,
  onMoveEnd,
  activeFilters = [],
  searchQuery = "",
  loading,
}: MerchantMapProps) {
  const filteredMerchants = useMemo(() => {
    return merchants.filter((merchant) => {
      const matchesFilter =
        activeFilters.length === 0 || activeFilters.includes(merchant.category);
      const matchesSearch =
        searchQuery === "" ||
        merchant.name.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesFilter && matchesSearch;
    });
  }, [merchants, activeFilters, searchQuery]);

  const defaultCategory = MERCHANT_CATEGORIES.find(
    (cat) => cat.id === "other"
  ) || { id: "other", name: "Autre", emoji: "📍", color: "#808080" };

  return (
    <div style={{ height: "100%", width: "100%", position: "relative" }}>
      <style>
        {`.leaflet-marker-suggestion { filter: grayscale(100%) opacity(0.7); }`}
      </style>
      <MapContainer
        key={`${mapCenter[0]}_${mapCenter[1]}`}
        center={mapCenter}
        zoom={13}
        style={{ height: "100%", width: "100%", zIndex: 0 }}
        scrollWheelZoom={true}
      >
        <MapEventsHandler onMoveEnd={onMoveEnd} />
        <TileLayer
          attribution='© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {/* --- MODIFICATION: Logique d'affichage des commerçants --- */}
        {filteredMerchants.map((merchant) => {
          const lat = merchant.latitude;
          const lng = merchant.longitude;
          if (typeof lat !== "number" || typeof lng !== "number") return null;

          let icon;
          // Si le commerçant vient d'une suggestion, on utilise l'icône spéciale
          if (merchant.isSuggestion) {
            icon = suggestedMerchantIcon;
          } else {
            // Sinon, on utilise la logique existante avec les catégories
            let category =
              MERCHANT_CATEGORIES.find((cat) => cat.id === merchant.category) ||
              defaultCategory;
            icon = createEmojiIcon(category.emoji, category.color);
          }

          return (
            <Marker key={merchant.id} position={[lat, lng]} icon={icon}>
              <Popup minWidth={250}>
                <div className="p-1">
                  <h3 className="text-md font-bold mb-1">{merchant.name}</h3>
                  <p className="text-gray-600 text-sm mb-2">
                    {merchant.address}
                  </p>

                  {/* --- MODIFICATION: Ajout du message de parrainage --- */}
                  {merchant.isSuggestion && (
                    <div className="mt-2 pt-2 border-t border-gray-200">
                      <p className="text-sm text-dinary-turquoise font-semibold">
                        🌟 Devenez le parrain de ce nouveau commerçant et gagnez
                        des récompenses !
                      </p>
                    </div>
                  )}
                </div>
              </Popup>
            </Marker>
          );
        })}

        {/* AFFICHAGE DES SUGGESTIONS EN ATTENTE (NON APPROUVÉES) */}
        {suggestions.map((suggestion) => {
          if (!suggestion.latitude || !suggestion.longitude) return null;

          return (
            <Marker
              key={`sugg-${suggestion.id}`}
              position={[suggestion.latitude, suggestion.longitude]}
              icon={pendingSuggestionIcon}
            >
              <Popup minWidth={250}>
                <div className="p-1">
                  <h3 className="text-md font-bold mb-1">
                    Suggestion: {suggestion.name}
                  </h3>
                  <p className="text-gray-600 text-sm mb-2">
                    {suggestion.address}
                  </p>
                  <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">
                    En attente d'approbation
                  </span>
                </div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>

      {filteredMerchants.length === 0 &&
        suggestions.length === 0 &&
        !loading && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-[1000]">
            <div className="bg-white bg-opacity-80 rounded-lg px-6 py-4 shadow text-gray-600 text-lg font-semibold">
              Aucun point d'intérêt dans cette zone.
            </div>
          </div>
        )}
    </div>
  );
}
