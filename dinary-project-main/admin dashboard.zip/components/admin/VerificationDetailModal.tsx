// dans @/components/admin/VerificationDetailModal.tsx

"use client";

import React, { useState } from "react";
import { X, CheckCircle, XCircle, Eye } from "lucide-react"; // On importe l'icône "Eye"

// --- INTERFACES ---
interface VerificationRequest {
  id: string;
  documentType: string;
  frontImageUrl: string;
  backImageUrl?: string | null;
  selfieImageUrl?: string | null;
  selfieInstruction?: string | null;
  user: {
    fullName: string;
    email: string;
  };
  createdAt: string;
}

interface ModalProps {
  request: VerificationRequest | null;
  onClose: () => void;
  onAction: () => void;
  token: string | null;
}

// --- COMPOSANT POUR L'AGRANDISSEMENT (INCHANGÉ) ---
const ImageViewer = ({
  src,
  onClose,
}: {
  src: string;
  onClose: () => void;
}) => (
  <div
    className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-4"
    onClick={onClose}
  >
    <button
      onClick={onClose}
      className="absolute top-4 right-4 text-white text-3xl z-[110]"
    >
      &times;
    </button>
    <img
      src={src}
      alt="Document en grand"
      className="max-w-[90vw] max-h-[90vh] object-contain"
      onClick={(e) => e.stopPropagation()}
    />
  </div>
);

// --- COMPOSANT PRINCIPAL (MODIFIÉ) ---
export default function VerificationDetailModal({
  request,
  onClose,
  onAction,
  token,
}: ModalProps) {
  const [imageToView, setImageToView] = useState<string | null>(null);

  if (!request) return null;

  const API_URL = (
    process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001"
  ).replace("/api", "");

  const handleAction = async (action: "approve" | "reject") => {
    const reason =
      action === "reject"
        ? prompt("Veuillez indiquer la raison du rejet :")
        : null;
    if (action === "reject" && !reason) return;

    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/admin/identity/${request.id}/${action}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ reason }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `Échec de l'action : ${action}`);
      }

      alert(
        `La vérification a été ${
          action === "approve" ? "approuvée" : "rejetée"
        } avec succès.`
      );
      onAction();
      onClose();
    } catch (error) {
      console.error("Erreur lors de l'action de vérification:", error);
      alert(
        `Une erreur est survenue : ${
          error instanceof Error ? error.message : "Erreur inconnue"
        }`
      );
    }
  };

  const frontImageUrl = `${API_URL}/uploads/${request.frontImageUrl}`;
  const backImageUrl = request.backImageUrl
    ? `${API_URL}/uploads/${request.backImageUrl}`
    : null;
  const selfieImageUrl = request.selfieImageUrl
    ? `${API_URL}/uploads/${request.selfieImageUrl}`
    : null;

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">Vérification d'identité</h2>
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-800"
            >
              <X size={24} />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Colonne de gauche : Informations */}
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-gray-500">
                  Utilisateur
                </h3>
                <p>{request.user.fullName}</p>
                <p className="text-xs text-gray-400">{request.user.email}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">
                  Type de document
                </h3>
                <p>{request.documentType.replace("_", " ")}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">
                  Date de soumission
                </h3>
                <p>{new Date(request.createdAt).toLocaleDateString("fr-FR")}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">
                  Instruction pour le selfie
                </h3>
                <p className="p-2 bg-blue-50 border border-blue-200 text-blue-800 rounded-md mt-1 text-sm">
                  {request.selfieInstruction || "Aucune instruction"}
                </p>
              </div>
            </div>

            {/* Colonne de droite : Boutons pour voir les images */}
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-gray-500">
                Documents Soumis
              </h3>
              <button
                onClick={() => setImageToView(frontImageUrl)}
                className="w-full ..."
              >
                <Eye className="mr-2" size={16} /> Voir l'image Recto
              </button>
              {backImageUrl && (
                <button
                  onClick={() => setImageToView(backImageUrl)}
                  className="w-full ..."
                >
                  <Eye className="mr-2" size={16} /> Voir l'image Verso
                </button>
              )}
            </div>
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-gray-500">
                Selfie de vérification
              </h3>
              {selfieImageUrl ? (
                <button
                  onClick={() => setImageToView(selfieImageUrl)}
                  className="w-full ..."
                >
                  <Eye className="mr-2" size={16} /> Voir le selfie
                </button>
              ) : (
                <p className="text-sm text-gray-400">Aucun selfie fourni.</p>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="mt-6 flex justify-end space-x-3 border-t pt-4">
            <button
              onClick={() => handleAction("reject")}
              className="px-4 py-2 bg-red-50 text-red-600 rounded-md flex items-center hover:bg-red-100"
            >
              <XCircle size={16} className="mr-2" /> Rejeter
            </button>
            <button
              onClick={() => handleAction("approve")}
              className="px-4 py-2 bg-green-50 text-green-600 rounded-md flex items-center hover:bg-green-100"
            >
              <CheckCircle size={16} className="mr-2" /> Approuver
            </button>
          </div>
        </div>
      </div>

      {imageToView && (
        <ImageViewer src={imageToView} onClose={() => setImageToView(null)} />
      )}
    </>
  );
}
