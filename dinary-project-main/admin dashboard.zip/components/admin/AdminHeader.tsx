"use client";

import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Bell, Search } from "lucide-react";

export default function AdminHeader() {
  const { user } = useAuth(); // On ne récupère plus la fonction "logout" ici
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const notificationsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        notificationsRef.current &&
        !notificationsRef.current.contains(event.target as Node)
      ) {
        setIsNotificationsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const toggleNotifications = () =>
    setIsNotificationsOpen(!isNotificationsOpen);

  if (!user) {
    return (
      <header className="h-16 border-b bg-white flex items-center justify-between px-6 sticky top-0 z-10 shadow-sm">
        <div className="w-96 h-8 bg-gray-200 rounded-lg animate-pulse"></div>
        <div className="flex items-center space-x-4">
          <div className="w-8 h-8 bg-gray-200 rounded-full animate-pulse"></div>
          <div className="w-24 h-8 bg-gray-200 rounded-lg animate-pulse"></div>
        </div>
      </header>
    );
  }

  const getInitials = (name: string) => {
    if (!name) return "AD";
    const names = name.split(" ");
    return names
      .map((n) => n[0])
      .join("")
      .substring(0, 2)
      .toUpperCase();
  };

  return (
    <header className="h-16 border-b bg-white flex items-center justify-between px-6 sticky top-0 z-10 shadow-sm">
      {/* Section de recherche */}
      <div className="flex items-center w-96">
        <div className="relative w-full">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={18} className="text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Rechercher utilisateurs, commerçants..."
            className="w-full pl-10 pr-4 py-2 rounded-lg border focus:border-blue-500 focus:outline-none text-sm"
          />
        </div>
      </div>

      {/* Section Notifications et Profil (simplifiée) */}
      <div className="flex items-center space-x-4">
        {/* Notifications */}
        <div className="relative" ref={notificationsRef}>
          <button
            onClick={toggleNotifications}
            className="relative p-2 rounded-full hover:bg-gray-100 focus:outline-none transition-colors duration-200"
            aria-label="Notifications"
          >
            <Bell
              size={20}
              className={
                isNotificationsOpen ? "text-blue-500" : "text-gray-600"
              }
            />
            <span className="absolute top-1 right-1 h-4 w-4 rounded-full bg-red-500 border-2 border-white text-xs flex items-center justify-center text-white animate-pulse">
              3
            </span>
          </button>

          {isNotificationsOpen && (
            <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg py-2 border z-10 transform origin-top-right transition-all duration-200 ease-out">
              {/* Le contenu des notifications reste ici si nécessaire */}
            </div>
          )}
        </div>

        {/* ✅ MODIFICATION : Profil sans menu déroulant */}
        <div className="flex items-center space-x-2">
          <div className="h-8 w-8 rounded-full bg-blue-500 flex items-center justify-center text-white font-medium">
            {getInitials(user.fullName)}
          </div>
          <span className="text-sm font-medium hidden md:block">
            {user.username}
          </span>
        </div>
      </div>
    </header>
  );
}
