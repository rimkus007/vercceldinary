"use client";

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  useRef,
} from "react";
import { useAuth } from "@/context/AuthContext";

// --- Interfaces (inchangées) ---
interface ApiNotification {
  id: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}
export interface Notification {
  id: string;
  title: string;
  message: string;
  type: "transaction" | "reward" | "promo" | "system" | "alert";
  isRead: boolean;
  timestamp: string;
  link?: string;
  icon?: string;
}
interface NotificationsContextType {
  notifications: Notification[];
  unreadCount: number;
  markAllAsRead: () => void;
  deleteAllNotifications: () => void;
}

const NotificationsContext = createContext<
  NotificationsContextType | undefined
>(undefined);

export const useNotifications = () => {
  const context = useContext(NotificationsContext);
  if (context === undefined) {
    throw new Error(
      "useNotifications doit être utilisé à l'intérieur d'un NotificationsProvider"
    );
  }
  return context;
};

// --- Formatage (inchangé) ---
const formatApiNotification = (notif: ApiNotification): Notification => {
  let title = "Notification";
  let type: Notification["type"] = "system";
  let icon = "🔔";
  if (notif.message.toLowerCase().includes("approuvée")) {
    title = "Recharge Approuvée";
    type = "transaction";
    icon = "✅";
  } else if (notif.message.toLowerCase().includes("rejetée")) {
    title = "Recharge Rejetée";
    type = "alert";
    icon = "❌";
  } else if (notif.message.toLowerCase().includes("bonus")) {
    title = "Bonus Reçu";
    type = "reward";
    icon = "🎁";
  }
  return {
    id: notif.id,
    title,
    message: notif.message,
    type,
    isRead: notif.isRead,
    timestamp: notif.createdAt,
    icon,
    link: "/historique",
  };
};

export const NotificationsProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const { token } = useAuth();
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const fetchNotifications = useCallback(async (currentToken: string) => {
    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/notifications`,
        {
          headers: { Authorization: `Bearer ${currentToken}` },
        }
      );
      if (response.ok) {
        const data: ApiNotification[] = await response.json();
        setNotifications(data.map(formatApiNotification));
      }
    } catch (error) {
      console.error("Erreur de connexion pour les notifications:", error);
    }
  }, []);

  useEffect(() => {
    const startPolling = (currentToken: string) => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      fetchNotifications(currentToken);
      intervalRef.current = setInterval(
        () => fetchNotifications(currentToken),
        15000
      );
    };
    const stopPolling = () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
    if (token) {
      startPolling(token);
    } else {
      stopPolling();
      setNotifications([]);
    }
    return () => stopPolling();
  }, [token, fetchNotifications]);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  // --- 👇 VOICI LA CORRECTION 👇 ---
  const markAllAsRead = async () => {
    if (!token || unreadCount === 0) return;

    // 1. Mise à jour visuelle immédiate (inchangée)
    setNotifications((prev) =>
      prev.map((notification) => ({ ...notification, isRead: true }))
    );

    // 2. Envoi de la requête au backend (corrigée)
    try {
      await fetch(`${process.env.NEXT_PUBLIC_API_URL}/notifications/read-all`, {
        method: "PATCH",
        // On ajoute les en-têtes et un corps vide pour plus de robustesse
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({}), // Un corps vide est parfois nécessaire
      });
    } catch (error) {
      console.error("Échec de la mise à jour des notifications:", error);
      // En cas d'erreur, on recharge les notifications pour annuler le changement visuel
      if (token) fetchNotifications(token);
    }
  };

  // Delete all notifications
  const deleteAllNotifications = async () => {
    if (!token) return;
    setNotifications([]); // Clear visually immediately
    try {
      await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/notifications/delete-all`,
        {
          method: "DELETE",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );
    } catch (error) {
      console.error("Échec de la suppression des notifications:", error);
      // Reload notifications if error
      if (token) fetchNotifications(token);
    }
  };

  const value = {
    notifications,
    unreadCount,
    markAllAsRead,
    deleteAllNotifications,
  };

  return (
    <NotificationsContext.Provider value={value}>
      {children}
    </NotificationsContext.Provider>
  );
};
