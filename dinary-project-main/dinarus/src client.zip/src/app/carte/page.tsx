"use client";

import React, {
  useState,
  useEffect,
  useMemo,
  useCallback,
  useRef,
} from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import PageHeader from "@/components/layouts/PageHeader";
import PromoBanner from "@/components/common/PromoBanner";
import SuggestCommerceModal, {
  CommerceSubmission,
} from "@/components/modals/SuggestCommerceModal";
import { useAuth } from "@/context/AuthContext";
import { useRouter } from "next/navigation";
import dynamic from "next/dynamic";

// --- INTERFACES (Types de données) ---
interface Badge {
  id: string;
  label: string;
  emoji: string;
  color: string;
}
interface Product {
  id: string;
  name: string;
  price: number;
  description?: string;
}
export interface Commerce {
  id: string;
  name: string;
  description: string | null;
  category: string;
  address: string | null;
  latitude: number;
  longitude: number;
  rating: number;
  distance?: number;
  products?: Product[];
  badges?: Badge[];
  promoActive?: boolean;
  promoValue?: string;
}

// --- EMOJIS (Constantes) ---
const CategoryEmojis: Record<string, string> = {
  restaurant: "🍽️",
  groceries: "🥬",
  retail: "🛍️",
  fashion: "👕",
  health: "💊",
  tech: "📱",
  loisirs: "🎮",
  all: "🔍",
};

// --- COMPOSANTS INTERNES ---

const StarRating = React.memo(({ rating }: { rating: number }) => {
  const safeRating = Math.max(0, Math.min(5, rating));
  const fullStars = Math.floor(safeRating);

  return (
    <div className="flex items-center">
      {[...Array(fullStars)].map((_, i) => (
        <svg
          key={`full-${i}`}
          className="w-4 h-4 text-yellow-400"
          fill="currentColor"
          viewBox="0 0 20 20"
        >
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      ))}
      <span className="ml-1 text-xs text-gray-600 font-medium">
        {safeRating.toFixed(1)}
      </span>
    </div>
  );
});
StarRating.displayName = "StarRating";

const CommerceItem = React.memo(
  ({
    commerce,
    onSelect,
  }: {
    commerce: Commerce;
    onSelect: (commerce: Commerce) => void;
  }) => (
    <motion.div
      className="flex items-center py-3 border-b border-gray-100 cursor-pointer hover:bg-gray-50 rounded-lg px-2"
      onClick={() => onSelect(commerce)}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      whileTap={{ scale: 0.98 }}
    >
      <div className="w-12 h-12 rounded-xl bg-gray-900 flex items-center justify-center text-white shadow-sm mr-4 flex-shrink-0">
        <span className="text-2xl">{CategoryEmojis[commerce.category]}</span>
      </div>
      <div className="flex-grow">
        <h3 className="font-semibold">{commerce.name}</h3>
        <div className="flex items-center text-sm text-gray-500">
          <span>À {commerce.distance?.toFixed(0)}m</span>
          <span className="mx-2">•</span>
          <StarRating rating={commerce.rating} />
        </div>
      </div>
    </motion.div>
  )
);
CommerceItem.displayName = "CommerceItem";

const ProductItem = React.memo(({ product }: { product: Product }) => (
  <div className="flex justify-between items-center py-3 border-b border-gray-100 last:border-b-0">
    <div>
      <h4 className="font-medium text-sm">{product.name}</h4>
      {product.description && (
        <p className="text-xs text-gray-500">{product.description}</p>
      )}
    </div>
    <div className="text-right">
      <p className="font-semibold text-sm">{product.price} DA</p>
    </div>
  </div>
));
ProductItem.displayName = "ProductItem";

const CommerceDetail = ({
  commerce,
  onClose,
}: {
  commerce: Commerce;
  onClose: () => void;
}) => {
  return (
    <motion.div
      className="fixed inset-0 bg-black/60 z-[1000] flex items-center justify-center p-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
    >
      <motion.div
        className="bg-white w-full max-w-sm mx-auto rounded-2xl p-5 shadow-xl"
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 50, opacity: 0 }}
        transition={{ type: "spring", stiffness: 400, damping: 30 }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-12 h-1.5 bg-gray-300 rounded-full mx-auto mb-4" />
        <div className="flex items-start mb-4">
          <div
            className={`w-14 h-14 rounded-xl flex items-center justify-center text-white shadow-sm mr-4 ${
              commerce.promoActive ? "bg-green-600" : "bg-gray-900"
            }`}
          >
            <span className="text-2xl">
              {CategoryEmojis[commerce.category]}
            </span>
          </div>
          <div className="flex-grow">
            <h2 className="font-bold text-xl">{commerce.name}</h2>
            <p className="text-sm text-gray-500">{commerce.description}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 -mt-2 -mr-2 rounded-full hover:bg-gray-100"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-gray-50 rounded-xl p-3 text-center">
            <p className="text-xs text-gray-500">Distance</p>
            <p className="font-bold">{commerce.distance?.toFixed(0)}m</p>
          </div>
          <div className="bg-gray-50 rounded-xl p-3 text-center">
            <p className="text-xs text-gray-500">Note</p>
            <p className="font-bold">{commerce.rating.toFixed(1)} ★</p>
          </div>
          <div className="bg-gray-50 rounded-xl p-3 text-center">
            <p className="text-xs text-gray-500">Status</p>
            <p className="font-bold text-green-600">Ouvert</p>
          </div>
        </div>
        {commerce.products && commerce.products.length > 0 && (
          <div className="mb-6">
            <h3 className="font-bold text-lg mb-3">Produits populaires</h3>
            <div className="bg-gray-50 rounded-xl p-4">
              <div className="space-y-2 divide-y divide-gray-100">
                {commerce.products.map((product) => (
                  <ProductItem key={product.id} product={product} />
                ))}
              </div>
            </div>
          </div>
        )}
        <div className="flex gap-3 pb-4">
          <button className="flex-1 bg-black text-white py-3 rounded-xl font-medium">
            Y aller
          </button>
          <button className="flex-1 bg-gray-100 text-gray-800 py-3 rounded-xl font-medium">
            Réserver
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
};

const DynamicMap = dynamic(() => import("@/components/common/DynamicMap"), {
  ssr: false,
  loading: () => (
    <div className="relative rounded-xl h-[400px] bg-gray-100 flex items-center justify-center">
      <p>Chargement de la carte...</p>
    </div>
  ),
});

// --- PAGE PRINCIPALE ---
export default function CartePage() {
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [selectedCommerce, setSelectedCommerce] = useState<Commerce | null>(
    null
  );
  const [isSuggestModalOpen, setIsSuggestModalOpen] = useState<boolean>(false);
  const [merchants, setMerchants] = useState<Commerce[]>([]);
  const [mapCenter, setMapCenter] = useState<[number, number]>([
    43.70313, 7.26608,
  ]); // Nice par défaut
  const [isLoading, setIsLoading] = useState(true);
  const { token, isLoading: isAuthLoading } = useAuth();
  const router = useRouter();
  const [searchAreaCenter, setSearchAreaCenter] = useState<
    [number, number] | null
  >(null);
  const [showSearchButton, setShowSearchButton] = useState<boolean>(false);
  const initialLoadDone = useRef(false);

  const fetchMerchants = useCallback(
    async (latitude: number, longitude: number) => {
      if (!token) return;
      const api = process.env.NEXT_PUBLIC_API_URL;
      if (!api) {
        console.error("NEXT_PUBLIC_API_URL est manquant.");
        setMerchants([]);
        setIsLoading(false);
        return;
      }
      setIsLoading(true);
      setShowSearchButton(false);
      try {
        const url = `${api}/merchants/nearby?latitude=${latitude}&longitude=${longitude}&radius=5`;
        const response = await fetch(url, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!response.ok) {
          const body = await response.text().catch(() => "");
          console.error(
            "Erreur de récupération des commerçants:",
            response.status,
            body
          );
          setMerchants([]);
          return;
        }
        const data = await response.json();
        setMerchants(Array.isArray(data) ? data : []);
      } catch (error) {
        console.error("Erreur de connexion:", error);
        setMerchants([]);
      } finally {
        setIsLoading(false);
      }
    },
    [token]
  );

  useEffect(() => {
    if (token && !initialLoadDone.current) {
      initialLoadDone.current = true;
      const onSuccess = (position: GeolocationPosition) => {
        const { latitude, longitude } = position.coords;
        setMapCenter([latitude, longitude]);
        fetchMerchants(latitude, longitude);
      };
      const onError = (error: GeolocationPositionError) => {
        console.error(
          "Erreur de géo., utilisation de la position par défaut.",
          error
        );
        fetchMerchants(mapCenter[0], mapCenter[1]);
      };
      try {
        navigator.geolocation.getCurrentPosition(onSuccess, onError, {
          enableHighAccuracy: true,
          timeout: 7000,
        });
      } catch (e) {
        onError(e as any);
      }
    }
  }, [token, fetchMerchants, mapCenter]);

  const handleSuggestionSubmit = (data: CommerceSubmission) => {
    console.log("Suggestion soumise:", data);
    setIsSuggestModalOpen(false);
  };
  const handleSearchArea = () => {
    if (searchAreaCenter) {
      fetchMerchants(searchAreaCenter[0], searchAreaCenter[1]);
    }
  };
  const handleMoveEnd = useCallback((lat: number, lng: number) => {
    if (initialLoadDone.current) {
      setSearchAreaCenter([lat, lng]);
      setShowSearchButton(true);
    }
  }, []);
  const filteredBusinesses = useMemo(
    () =>
      filterCategory === "all"
        ? merchants
        : merchants.filter((b) => b.category === filterCategory),
    [merchants, filterCategory]
  );

  if (isAuthLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p>Chargement de votre session...</p>
      </div>
    );
  }

  return (
    <div className="bg-white min-h-screen mb-16">
      <PageHeader
        title="Carte"
        emoji="📍"
        actionButton={
          <button className="p-2">
            <span className="text-lg">🔍</span>
          </button>
        }
      />
      <div className="px-5">
        <div className="my-4">
          <PromoBanner
            title="+1000DA"
            description="Parraine un commerçant et gagne +1000DA"
            emoji="🎁"
            action={() => router.push("/inviter")}
            actionLabel="Parrainer"
          />
        </div>
        <h2 className="text-xl font-semibold mb-3">Commerçants à proximité</h2>
        <div className="relative">
          <DynamicMap
            center={mapCenter}
            merchants={filteredBusinesses}
            onMoveEnd={handleMoveEnd}
          />
          <AnimatePresence>
            {showSearchButton && (
              <motion.div
                className="absolute bottom-4 left-1/2 -translate-x-1/2 z-[500]"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
              >
                <button
                  onClick={handleSearchArea}
                  className="bg-black text-white px-4 py-2 rounded-full shadow-lg text-sm font-semibold flex items-center"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 mr-2"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 4v5h5M20 20v-5h-5M4 20h5v-5M20 4h-5v5"
                    />
                  </svg>
                  Rechercher dans cette zone
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        <div className="mt-4">
          <div className="flex gap-2 overflow-x-auto pb-3 -mx-1 px-1 scrollbar-hide">
            {Object.entries(CategoryEmojis).map(([category, emoji]) => (
              <button
                key={category}
                onClick={() => setFilterCategory(category)}
                className={`flex items-center px-3 py-1.5 rounded-full whitespace-nowrap transition-colors ${
                  filterCategory === category
                    ? "bg-black text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                <span className="mr-1.5">{emoji}</span>
                <span className="text-sm font-medium">
                  {category.charAt(0).toUpperCase() + category.slice(1)}
                </span>
              </button>
            ))}
          </div>
          <div className="mt-2 mb-20">
            {isLoading ? (
              <p className="text-center text-gray-500 py-8">
                Recherche des commerces...
              </p>
            ) : filteredBusinesses.length > 0 ? (
              filteredBusinesses.map((commerce) => (
                <CommerceItem
                  key={commerce.id}
                  commerce={commerce}
                  onSelect={() => setSelectedCommerce(commerce)}
                />
              ))
            ) : (
              <div className="py-8 text-center">
                <p className="text-gray-500">
                  Aucun commerçant trouvé dans cette zone.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
      <div className="fixed bottom-20 right-5 flex flex-col items-end space-y-3">
        <Link
          href="/suggestions"
          className="bg-white text-black py-2 px-4 rounded-full shadow-md border border-gray-200 flex items-center text-sm font-medium"
        >
          <span className="mr-2">📋</span> Mes suggestions
        </Link>
        <button
          className="bg-black text-white py-3 px-5 rounded-full shadow-lg flex items-center font-semibold"
          onClick={() => setIsSuggestModalOpen(true)}
        >
          <span className="mr-2">➕</span> Suggérer
        </button>
      </div>
      <AnimatePresence>
        {selectedCommerce && (
          <CommerceDetail
            commerce={selectedCommerce}
            onClose={() => setSelectedCommerce(null)}
          />
        )}
      </AnimatePresence>
      <SuggestCommerceModal
        isOpen={isSuggestModalOpen}
        onClose={() => setIsSuggestModalOpen(false)}
        onSubmit={handleSuggestionSubmit}
      />
    </div>
  );
}
