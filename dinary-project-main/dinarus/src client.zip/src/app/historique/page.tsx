// app/historique/page.tsx
"use client";

import React, { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { motion } from "framer-motion";
import PageHeader from "@/components/layouts/PageHeader";
import TransactionReceipt, {
  TransactionDetails,
} from "@/components/modals/TransactionReceipt";

export default function Historique() {
  const { user, token, isLoading } = useAuth();

  const [error, setError] = useState<string | null>(null);
  const [selectedFilter, setSelectedFilter] = useState("Tout");
  const filters = ["Tout", "Entrées", "Sorties", "Récompenses"];
  const [showReceipt, setShowReceipt] = useState(false);
  const [selectedTransaction, setSelectedTransaction] =
    useState<TransactionDetails | null>(null);
  const [transactions, setTransactions] = useState<{ [key: string]: any[] }>(
    {}
  );

  useEffect(() => {
    const fetchData = async () => {
      if (!token || !user) {
        return;
      }

      try {
        const [walletRes, missionsRes] = await Promise.all([
          fetch("http://localhost:3001/api/wallet/transactions", {
            headers: { Authorization: `Bearer ${token}` },
          }),
          fetch("http://localhost:3001/api/gamification/missions", {
            headers: { Authorization: `Bearer ${token}` },
          }),
        ]);

        if (walletRes.status === 401 || missionsRes.status === 401) {
          setError("Accès non autorisé. Veuillez vous reconnecter.");
          return;
        }

        let walletTxs: any[] = [];
        if (walletRes.ok) {
          const walletData = await walletRes.json();
          walletTxs = walletData.map((tx: any) => {
            const isSender = tx.sender?.user?.username === user.username;
            const isManualRecharge =
              tx.type === "recharge" &&
              tx.description?.toLowerCase().includes("manuel");
            const isSortie = isSender || tx.amount < 0;
            return {
              id: tx.id,
              rawDate: tx.createdAt,
              type: tx.type,
              category: isSortie ? "Sortie" : "Entrée",
              icon:
                tx.type === "recharge"
                  ? isManualRecharge
                    ? "🎁" // icône propre pour gain manuel
                    : "📥"
                  : tx.type === "payment"
                  ? "💳"
                  : "💸",
              bgColor: isSortie ? "bg-red-100" : "bg-green-100",
              name: isManualRecharge
                ? "Recharge libre (gain)"
                : tx.description || tx.type || "Transaction",
              date: new Date(tx.createdAt).toLocaleDateString("fr-FR", {
                day: "2-digit",
                month: "short",
                year: "numeric",
              }),
              amount: tx.amount,
              commission: tx.commission ?? 0,
              isPositive: !isSortie,
              points: isManualRecharge
                ? "+gain"
                : tx.xpGained
                ? `+${tx.xpGained} points`
                : "",
            };
          });
        }

        let missionRewards: any[] = [];
        if (missionsRes.ok) {
          const missionsData = await missionsRes.json();
          missionRewards = missionsData
            .filter((m: any) => m.isCompleted && m.xpReward > 0)
            .map((m: any) => ({
              id: m.id,
              rawDate: m.completedAt,
              type: "reward",
              category: "Récompense",
              icon: "🎯",
              bgColor: "bg-blue-100",
              name: `Mission: ${m.title}`,
              date: m.completedAt
                ? new Date(m.completedAt).toLocaleDateString("fr-FR", {
                    day: "2-digit",
                    month: "short",
                    year: "numeric",
                  })
                : "",
              amount: `+${m.xpReward}`,
              isPositive: true,
              points: `+${m.xpReward} points`,
            }));
        }

        const allItems = [...walletTxs, ...missionRewards].sort(
          (a, b) =>
            new Date(b.rawDate).getTime() - new Date(a.rawDate).getTime()
        );

        if (allItems.length === 0) {
          setError("Aucune transaction ou mission trouvée.");
        } else {
          const grouped = allItems.reduce((acc, item) => {
            const monthYear = new Date(item.rawDate).toLocaleString("fr-FR", {
              month: "long",
              year: "numeric",
            });
            if (!acc[monthYear]) {
              acc[monthYear] = [];
            }
            acc[monthYear].push(item);
            return acc;
          }, {});
          setTransactions(grouped);
        }
      } catch (err) {
        setError(
          "Erreur de récupération de l'historique. Veuillez réessayer plus tard."
        );
        console.error("[Historique] Fetch error:", err);
      }
    };

    if (!isLoading) {
      fetchData();
    }
  }, [isLoading, token, user]);

  const filterTransactions = (month: string, filter: string) => {
    if (!transactions[month]) return [];
    if (filter === "Tout") return transactions[month];
    return transactions[month].filter((t: any) => {
      if (filter === "Entrées") return t.category === "Entrée";
      if (filter === "Sorties") return t.category === "Sortie";
      if (filter === "Récompenses") return t.type === "reward";
      return false;
    });
  };

  const handleTransactionClick = (transaction: TransactionDetails) => {
    setSelectedTransaction(transaction);
    setShowReceipt(true);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p>Chargement de l&apos;historique...</p>
      </div>
    );
  }

  return (
    <div className="bg-white min-h-screen mb-16">
      <PageHeader
        title="Historique"
        emoji="📊"
        showBackButton={true}
        backTo="/dashboard"
      />

      <div className="px-5 pb-10">
        {error ? (
          <div className="bg-red-100 text-red-700 rounded-xl p-4 my-6 text-center">
            {error}
          </div>
        ) : (
          <>
            <div className="mb-6 flex items-center overflow-x-auto pb-2 -mx-1 px-1">
              {filters.map((filter) => (
                <button
                  key={filter}
                  className={`px-4 py-2 ${
                    selectedFilter === filter
                      ? "bg-black text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  } text-sm rounded-full whitespace-nowrap mr-2 transition-colors`}
                  onClick={() => setSelectedFilter(filter)}
                >
                  {filter}
                </button>
              ))}
            </div>

            {Object.keys(transactions).map((month) => {
              const filteredTransactions = filterTransactions(
                month,
                selectedFilter
              );
              if (filteredTransactions.length === 0) return null;

              return (
                <motion.div
                  key={month}
                  className="mb-6"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <h2 className="text-lg font-bold mb-4 capitalize">{month}</h2>
                  <div className="space-y-4">
                    {filteredTransactions.map((tx, index) => (
                      <motion.div
                        key={tx.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.05, duration: 0.2 }}
                        whileTap={{ scale: 0.98 }}
                        className="p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-all cursor-pointer"
                        onClick={() => handleTransactionClick(tx)}
                      >
                        <div className="flex justify-between items-center">
                          <div className="flex items-center">
                            <div
                              className={`w-11 h-11 ${tx.bgColor} rounded-xl flex items-center justify-center mr-3`}
                            >
                              <span className="text-xl">{tx.icon}</span>
                            </div>
                            <div>
                              <p className="font-medium">{tx.name}</p>
                              <p className="text-xs text-gray-500">{tx.date}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p
                              className={`font-medium ${
                                tx.isPositive ? "text-green-600" : ""
                              }`}
                            >
                              {tx.amount} DA
                            </p>
                            {typeof tx.commission !== "undefined" &&
                              tx.commission > 0 && (
                                <p className="text-xs text-amber-600 font-semibold">
                                  Commission: {tx.commission} DA
                                </p>
                              )}
                            {tx.points && (
                              <p className="text-xs text-gray-500">
                                {tx.points}
                              </p>
                            )}
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              );
            })}
          </>
        )}
      </div>

      <TransactionReceipt
        isOpen={showReceipt}
        onClose={() => setShowReceipt(false)}
        transaction={
          selectedTransaction
            ? {
                ...selectedTransaction,
                commission: selectedTransaction.commission,
              }
            : null
        }
      />
    </div>
  );
}
