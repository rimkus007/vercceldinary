// src/app/scanner/page.tsx
"use client";

import React, { useState, useEffect, useRef, useCallback } from "react";
import { Html5Qrcode, Html5QrcodeScannerState } from "html5-qrcode";
import { useAuth } from "@/context/AuthContext";
import { useRouter } from "next/navigation";
import PageHeader from "@/components/layouts/PageHeader";
import { motion } from "framer-motion";
import { RefreshCw, Upload, CheckCircle } from "lucide-react";

// --- Composants de Confirmation et de Succès (inchangés) ---
const PaymentConfirmation = ({
  paymentData,
  onConfirm,
  onCancel,
  merchantName,
}) => (
  <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
    <motion.div
      initial={{ y: 50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="bg-white rounded-2xl p-6 w-full max-w-sm text-center shadow-xl"
    >
      <h2 className="text-xl font-bold mb-2">Confirmer le paiement</h2>
      <p className="text-gray-600 mb-4">Voulez-vous vraiment payer :</p>
      <div className="my-4">
        <span className="text-4xl font-bold text-black block">
          {paymentData.amount.toLocaleString("fr-FR", {
            minimumFractionDigits: 2,
          })}{" "}
          DA
        </span>
        <span className="text-gray-700">
          à <span className="font-semibold">{merchantName}</span>
        </span>
      </div>
      <div className="flex flex-col gap-3 mt-6">
        <button
          onClick={onConfirm}
          className="bg-black text-white py-3 rounded-xl font-semibold hover:bg-gray-800 transition-colors"
        >
          Confirmer et Payer
        </button>
        <button
          onClick={onCancel}
          className="bg-gray-100 text-black py-3 rounded-xl font-semibold hover:bg-gray-200 transition-colors"
        >
          Annuler
        </button>
      </div>
    </motion.div>
  </div>
);

const PaymentSuccess = ({ amount, merchantName, onDone }) => (
  <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className="bg-white rounded-2xl p-6 w-full max-w-sm text-center shadow-xl"
    >
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.2, type: "spring" }}
      >
        <CheckCircle className="w-16 h-16 text-green-500 mx-auto" />
      </motion.div>
      <h2 className="text-2xl font-bold mt-4">Paiement réussi !</h2>
      <p className="text-gray-600 mt-2">
        Vous avez payé{" "}
        <span className="font-semibold text-black">
          {amount.toLocaleString("fr-FR", { minimumFractionDigits: 2 })} DA
        </span>{" "}
        à <span className="font-semibold text-black">{merchantName}</span>.
      </p>
      <button
        onClick={onDone}
        className="w-full mt-6 bg-black text-white py-3 rounded-xl font-semibold hover:bg-gray-800 transition-colors"
      >
        Terminé
      </button>
    </motion.div>
  </div>
);

// --- Page Principale du Scanner ---
export default function ScannerPage() {
  const [paymentData, setPaymentData] = useState(null);
  const [merchantName, setMerchantName] = useState("");
  const [error, setError] = useState("");
  const [isSuccess, setIsSuccess] = useState(false);
  const { token } = useAuth();
  const router = useRouter();
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [cameras, setCameras] = useState([]);
  const [activeCameraId, setActiveCameraId] = useState<string | null>(null);

  const onScanSuccess = useCallback(
    async (decodedText: string) => {
      if (scannerRef.current?.isScanning) {
        await scannerRef.current.stop();
      }
      try {
        const data = JSON.parse(decodedText);
        if (data.merchantUserId && data.amount) {
          const res = await fetch(
            `${process.env.NEXT_PUBLIC_API_URL}/users/${data.merchantUserId}/public`,
            { headers: { Authorization: `Bearer ${token}` } }
          );
          if (!res.ok) throw new Error("Commerçant non trouvé.");
          const merchantInfo = await res.json();
          setMerchantName(merchantInfo.fullName || merchantInfo.username);
          setPaymentData(data);
        } else {
          throw new Error("QR Code non reconnu par Dinary.");
        }
      } catch (e) {
        setError(e.message || "QR Code invalide.");
        setTimeout(() => setError(""), 3000);
      }
    },
    [token]
  );

  const startScanner = useCallback(
    async (deviceId: string) => {
      if (!scannerRef.current || scannerRef.current.isScanning) return;
      setError("");

      const config = { fps: 10, qrbox: { width: 250, height: 250 } };

      try {
        await scannerRef.current.start(
          { deviceId: { exact: deviceId } },
          config,
          onScanSuccess,
          (err) => {}
        );
      } catch (err) {
        setError("Impossible de démarrer la caméra.");
      }
    },
    [onScanSuccess]
  );

  useEffect(() => {
    scannerRef.current = new Html5Qrcode("qr-reader", false);

    Html5Qrcode.getCameras()
      .then((devices) => {
        if (devices && devices.length) {
          setCameras(devices);
          const rearCamera =
            devices.find((d) => d.label.toLowerCase().includes("back")) ||
            devices[0];
          setActiveCameraId(rearCamera.id);
        } else {
          setError("Aucune caméra n'a été trouvée.");
        }
      })
      .catch(() => setError("Erreur d'accès aux caméras."));

    return () => {
      if (scannerRef.current?.isScanning) {
        scannerRef.current.stop().catch(() => {});
      }
    };
  }, []);

  useEffect(() => {
    if (activeCameraId && !paymentData && !isSuccess) {
      startScanner(activeCameraId);
    }
  }, [activeCameraId, paymentData, isSuccess, startScanner]);

  const handleCameraToggle = async () => {
    if (cameras.length > 1 && scannerRef.current && activeCameraId) {
      const currentIndex = cameras.findIndex((c) => c.id === activeCameraId);
      const nextIndex = (currentIndex + 1) % cameras.length;

      if (scannerRef.current.isScanning) {
        await scannerRef.current.stop();
      }
      setActiveCameraId(cameras[nextIndex].id);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      scannerRef.current
        ?.scanFile(e.target.files[0], true)
        .then(onScanSuccess)
        .catch(() => setError("Aucun QR code trouvé dans l'image."));
    }
  };

  const handleConfirmPayment = async () => {
    if (!paymentData || !token) return;
    try {
      // --- LA CORRECTION EST ICI ---
      // On ajoute "/api" au début de l'URL
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/wallet/pay-qr`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(paymentData),
        }
      );
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Le paiement a échoué.");
      }

      // On met à jour l'état pour afficher l'écran de succès
      setIsSuccess(true);
    } catch (e) {
      setError(e.message);
      setPaymentData(null); // On remet le scanner en marche en cas d'erreur
    }
  };

  if (isSuccess) {
    return (
      <PaymentSuccess
        amount={paymentData.amount}
        merchantName={merchantName}
        onDone={() => router.push("/dashboard")}
      />
    );
  }
  if (paymentData) {
    return (
      <PaymentConfirmation
        paymentData={paymentData}
        merchantName={merchantName}
        onConfirm={handleConfirmPayment}
        onCancel={() => {
          setPaymentData(null);
          setError("");
        }}
      />
    );
  }

  return (
    <div className="bg-white min-h-screen">
      <PageHeader title="Scanner" hasBackButton={true} backTo="/dashboard" />

      <div className="p-5 flex flex-col items-center">
        {/* Le carré de scan */}
        <div className="w-full max-w-sm aspect-square bg-gray-900 rounded-2xl overflow-hidden shadow-lg border-4 border-gray-200 relative">
          <div id="qr-reader"></div>
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-[70%] h-[70%] border-2 border-white/50 rounded-lg animate-pulse"></div>
          </div>
        </div>

        {error && (
          <div className="mt-4 bg-red-100 text-red-700 p-3 rounded-lg text-center text-sm w-full max-w-sm">
            {error}
          </div>
        )}

        {/* Les boutons de contrôle */}
        <div className="mt-6 flex items-center justify-center gap-6 w-full max-w-sm">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="image/*"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex flex-col items-center gap-2 text-gray-700 p-3 rounded-lg hover:bg-gray-100"
          >
            <Upload size={28} />
            <span className="text-xs font-medium">Importer</span>
          </button>

          <button
            onClick={handleCameraToggle}
            className="flex flex-col items-center gap-2 text-gray-700 p-3 rounded-lg hover:bg-gray-100 disabled:opacity-50"
            disabled={cameras.length <= 1}
          >
            <RefreshCw size={28} />
            <span className="text-xs font-medium">Changer</span>
          </button>
        </div>
      </div>
    </div>
  );
}
