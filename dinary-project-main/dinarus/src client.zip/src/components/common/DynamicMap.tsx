// src/components/common/DynamicMap.tsx

"use client";

import React, { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Correction pour l'icône par défaut de Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl:
    "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
});

interface DynamicMapProps {
  center: [number, number];
  merchants: any[];
  onMoveEnd: (lat: number, lng: number) => void;
}

const DynamicMap: React.FC<DynamicMapProps> = ({
  center,
  merchants,
  onMoveEnd,
}) => {
  const mapRef = useRef<L.Map | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const onMoveEndRef = useRef(onMoveEnd);
  onMoveEndRef.current = onMoveEnd;

  // Effet pour initialiser la carte UNE SEULE FOIS
  useEffect(() => {
    if (containerRef.current && !mapRef.current) {
      const map = L.map(containerRef.current, {
        center: center,
        zoom: 13,
        scrollWheelZoom: true,
        zoomControl: true,
      });

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution:
          '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      }).addTo(map);

      map.on("moveend", () => {
        const mapCenter = map.getCenter();
        onMoveEndRef.current(mapCenter.lat, mapCenter.lng);
      });

      mapRef.current = map;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Tableau de dépendances vide pour ne s'exécuter qu'une fois

  // Effet pour recentrer la carte quand la prop 'center' change
  useEffect(() => {
    if (mapRef.current) {
      mapRef.current.setView(center, 13);
    }
  }, [center]);

  // Effet pour mettre à jour les marqueurs
  useEffect(() => {
    if (mapRef.current) {
      mapRef.current.eachLayer((layer) => {
        if (layer instanceof L.Marker) {
          mapRef.current?.removeLayer(layer);
        }
      });

      merchants.forEach((merchant) => {
        if (merchant.latitude && merchant.longitude) {
          L.marker([merchant.latitude, merchant.longitude])
            .addTo(mapRef.current!)
            .bindPopup(`<b>${merchant.name}</b><br>${merchant.address || ""}`);
        }
      });
    }
  }, [merchants]);

  return (
    <div
      ref={containerRef}
      style={{
        height: "400px",
        width: "100%",
        borderRadius: "12px",
        zIndex: 0,
      }}
    />
  );
};

export default DynamicMap;
