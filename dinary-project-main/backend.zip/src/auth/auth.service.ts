// src/auth/auth.service.ts

import {
  Injectable,
  UnauthorizedException,
  ConflictException,
} from '@nestjs/common';
import { UsersService } from '../users/users.service';
import { JwtService } from '@nestjs/jwt';
import { CreateUserDto } from '../users/dto/create-user.dto';
import { LoginDto } from './dto/login.dto';
import * as bcrypt from 'bcrypt';
import { PrismaService } from '../prisma/prisma.service';
import { RegisterMerchantDto } from './dto/register-merchant.dto';
import { User, Prisma } from '@prisma/client';
import { nanoid } from 'nanoid';

@Injectable()
export class AuthService {
  constructor(
    private usersService: UsersService,
    private jwtService: JwtService,
    private prisma: PrismaService,
  ) {}

  async signIn(loginDto: LoginDto): Promise<{ access_token: string }> {
    const user = await this.usersService.findOneByEmail(loginDto.email);
    if (!user) {
      throw new UnauthorizedException('Email ou mot de passe invalide');
    }
    // 👇 LA CORRECTION EST ICI 👇
    const isMatch = await bcrypt.compare(
      loginDto.password,
      user.hashedPassword,
    );
    if (!isMatch) {
      throw new UnauthorizedException('Email ou mot de passe invalide');
    }
    const payload = {
      username: user.username,
      email: user.email,
      sub: user.id,
      role: user.role,
    };
    return {
      access_token: this.jwtService.sign(payload),
    };
  }

  // Le reste de votre fichier auth.service.ts reste inchangé...

  async register(
    createUserDto: CreateUserDto,
  ): Promise<Omit<User, 'hashedPassword'>> {
    const {
      password,
      referralCode: providedReferralCode,
      ...rest
    } = createUserDto;
    const hashedPassword = await bcrypt.hash(password, 10);
    let referredById: string | undefined = undefined;

    if (providedReferralCode) {
      const referrer =
        await this.usersService.findOneByReferralCode(providedReferralCode);
      if (referrer) {
        referredById = referrer.id;
      }
    }
    const referralCode = `DINARY-${nanoid(8).toUpperCase()}`;
    const userData: Prisma.UserCreateInput = {
      ...rest,
      hashedPassword: hashedPassword,
      referralCode: referralCode,
    };

    if (referredById) {
      userData.referredBy = { connect: { id: referredById } };
    }
    const user = await this.usersService.createUser(userData);

    if (referredById) {
      console.log(
        `L'utilisateur ${user.username} a été parrainé par l'ID ${referredById}`,
      );
    }
    const { hashedPassword: _, ...result } = user;
    return result;
  }

  async registerMerchant(registerMerchantDto: RegisterMerchantDto) {
    const {
      name,
      address,
      category,
      password,
      referralCode: providedReferralCode,
      ...userData
    } = registerMerchantDto;

    const existingUser = await this.usersService.findOneByEmail(userData.email);
    if (existingUser) {
      throw new ConflictException('Un compte avec cet email existe déjà.');
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    let referredById: string | undefined = undefined;
    if (providedReferralCode) {
      const referrer =
        await this.usersService.findOneByReferralCode(providedReferralCode);
      if (referrer) {
        referredById = referrer.id;
      }
    }

    // On utilise une seule transaction pour tout créer de manière atomique
    return this.prisma.$transaction(async (tx) => {
      // 1. Créer l'utilisateur
      const user = await tx.user.create({
        data: {
          ...userData,
          hashedPassword: hashedPassword,
          role: 'MERCHANT',
          referralCode: `DINARY-${nanoid(8).toUpperCase()}`,
          ...(referredById && {
            referredBy: { connect: { id: referredById } },
          }),
        },
      });

      // 2. Créer le portefeuille associé
      await tx.wallet.create({
        data: {
          userId: user.id,
        },
      });

      // 3. Créer le profil de gamification associé
      await tx.userProfile.create({
        data: {
          userId: user.id,
        },
      });

      // 4. Créer le profil marchand
      const merchant = await tx.merchant.create({
        data: {
          userId: user.id,
          name,
          address,
          category,
        },
      });

      const { hashedPassword: _, ...userResult } = user;
      return { user: userResult, merchant };
    });
  }
}
