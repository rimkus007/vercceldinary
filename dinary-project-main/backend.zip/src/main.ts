import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe } from '@nestjs/common';
import { join } from 'path';
import * as express from 'express';
// ✅ NOUVEL IMPORT NÉCESSAIRE
import { NestExpressApplication } from '@nestjs/platform-express';

async function bootstrap() {
  // ✅ CORRECTION : Changer le type de 'app' pour avoir accès à 'useStaticAssets'
  const app = await NestFactory.create<NestExpressApplication>(AppModule);

  app.setGlobalPrefix('api');

  // ✅ CORRECTION : LA LIGNE LA PLUS IMPORTANTE
  // Cette ligne dit à ton serveur : "Le dossier 'uploads' à la racine du projet
  // est maintenant public."
  app.useStaticAssets(join(process.cwd(), 'uploads'), {
    prefix: '/uploads', // On garde le préfixe pour que les URLs soient propres
  });

  app.enableCors({
    origin: [
      'http://localhost:3000',
      'http://localhost:3003',
      'http://localhost:3002',
    ],
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    credentials: true,
  });

  app.useGlobalPipes(
    new ValidationPipe({
      transform: true,
    }),
  );

  await app.listen(3001);
  console.log(`Application is running on: ${await app.getUrl()}`);
}
bootstrap();
