import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
  UnauthorizedException,
  ConflictException,
} from '@nestjs/common';
import { PrismaService } from 'src/prisma/prisma.service';
import { SendMoneyDto } from './dto/send-money.dto';
import { GamificationService } from 'src/gamification/gamification.service';
import { CommissionService } from './commission.service';
import { RechargeDto } from './dto/recharge.dto';
import { PayQrDto } from './dto/pay-qr.dto';
import PDFDocument from 'pdfkit';
import * as QRCode from 'qrcode';
import { RechargeByMerchantDto } from './dto/recharge-by-merchant.dto';
import { NotificationsService } from '../notifications/notifications.service';
import { Prisma } from '@prisma/client';
import { RefundItemsDto } from './dto/refund-items.dto';
import { ProductsService } from '../products/products.service';
@Injectable()
export class WalletService {
  private paymentStatuses = new Map<
    string,
    'pending' | 'completed' | 'failed'
  >();
  private rechargeStatuses = new Map<
    string,
    { status: 'pending' | 'completed' | 'failed'; merchantName?: string }
  >();
  constructor(
    private readonly prisma: PrismaService,
    private readonly gamificationService: GamificationService,
    private readonly commissionService: CommissionService,
    private readonly notificationsService: NotificationsService,
    private readonly productsService: ProductsService,
  ) {}

  // ... (le reste de votre service)
  private async checkAndApplyReferralBonus(userId: string) {
    // 1. On récupère l'utilisateur et son parrain
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: { referredBy: { include: { wallet: true } } }, // On inclut le portefeuille du parrain
    });

    // 2. On vérifie si l'utilisateur a bien un parrain et un portefeuille
    if (!user || !user.referredById || !user.referredBy?.wallet) {
      return; // Pas de parrain ou portefeuille du parrain introuvable, on arrête
    }

    const referrerId = user.referredById;
    const referrerWalletId = user.referredBy.wallet.id;

    // 3. On vérifie si une récompense a DÉJÀ été donnée pour ce parrainage
    const existingBonus = await this.prisma.transaction.findFirst({
      where: {
        receiverId: referrerWalletId,
        type: 'bonus',
        description: { contains: user.username },
      },
    });

    if (existingBonus) {
      return; // Une récompense a déjà été donnée, on ne fait rien
    }

    // 4. On compte uniquement les transactions où le filleul est l'EXPÉDITEUR
    //    et qui sont des transferts ou des paiements.
    const actionTransactionCount = await this.prisma.transaction.count({
      where: {
        sender: { userId: userId }, // L'utilisateur est celui qui envoie
        type: { in: ['transfer', 'payment'] }, // Seuls les transferts et paiements comptent
      },
    });

    // 5. On vérifie si c'est bien la PREMIÈRE action de ce type
    if (actionTransactionCount === 1) {
      const rewardAmount = user.role === 'MERCHANT' ? 1000 : 500;
      const rewardDescription = `Bonus de parrainage pour ${user.username}`;

      // On procède au paiement et à la notification (inchangé)
      await this.prisma.wallet.update({
        where: { id: referrerWalletId },
        data: { balance: { increment: rewardAmount } },
      });

      await this.prisma.transaction.create({
        data: {
          amount: rewardAmount,
          type: 'bonus',
          description: rewardDescription,
          receiverId: referrerWalletId,
        },
      });

      await this.gamificationService.addXp(referrerId, 100);

      await this.prisma.notification.create({
        data: {
          userId: referrerId,
          message: `🎉 Félicitations ! Votre filleul ${user.fullName} a fait sa première transaction. Vous avez gagné ${rewardAmount} DA !`,
        },
      });
    }
  }
  getRechargeStatus(rechargeId: string) {
    const statusInfo = this.rechargeStatuses.get(rechargeId);
    if (statusInfo?.status === 'completed') {
      this.rechargeStatuses.delete(rechargeId); // Nettoyer après la lecture
      return statusInfo;
    }
    return statusInfo || { status: 'pending' };
  }
  async rechargeClientByMerchant(
    merchantId: string,
    dto: RechargeByMerchantDto,
  ): Promise<{ message: string }> {
    const { userId: clientId, amount, rechargeRequestId } = dto;

    // On met la demande en attente
    this.rechargeStatuses.set(rechargeRequestId, { status: 'pending' });

    const merchant = await this.prisma.user.findUnique({
      where: { id: merchantId },
      include: { wallet: true, merchantProfile: true },
    });

    const client = await this.prisma.user.findUnique({
      where: { id: clientId },
      include: { wallet: true },
    });

    if (!merchant || !merchant.wallet || !merchant.merchantProfile) {
      throw new NotFoundException('Profil commerçant introuvable.');
    }

    if (!client || !client.wallet) {
      throw new NotFoundException('Client introuvable.');
    }

    if (merchant.wallet.balance < amount) {
      this.rechargeStatuses.set(rechargeRequestId, { status: 'failed' });
      throw new BadRequestException(
        'Solde insuffisant pour effectuer cette recharge.',
      );
    }

    try {
      await this.prisma.$transaction(async (tx) => {
        // 1. Débiter le commerçant
        await tx.wallet.update({
          where: { id: merchant.wallet!.id },
          data: { balance: { decrement: amount } },
        });

        // 2. Créditer le client
        await tx.wallet.update({
          where: { id: client.wallet!.id },
          data: { balance: { increment: amount } },
        });

        // 3. Enregistrer la transaction de sortie pour le commerçant
        await tx.transaction.create({
          data: {
            amount,
            type: 'MERCHANT_RECHARGE_DEBIT',
            description: `Recharge du client ${client.username}`,
            status: 'COMPLETED',
            senderId: merchant.wallet!.id,
            receiverId: client.wallet!.id,
          },
        });

        // 4. Enregistrer la transaction d'entrée pour le client
        await tx.transaction.create({
          data: {
            amount,
            type: 'RECHARGE_FROM_MERCHANT',
            description: `Recharge par ${merchant.merchantProfile!.name}`,
            status: 'COMPLETED',
            senderId: merchant.wallet!.id,
            receiverId: client.wallet!.id,
          },
        });
      });

      // Mettre à jour le statut avec le nom du marchand
      this.rechargeStatuses.set(rechargeRequestId, {
        status: 'completed',
        merchantName: merchant.merchantProfile!.name,
      });

      // 5. Notifications et Gamification
      await this.notificationsService.create({
        user: { connect: { id: merchant.id } },
        message: `✅ Recharge client réussie ! Vous avez rechargé ${client.username} de ${amount} DA.`,
      });

      await this.notificationsService.create({
        user: { connect: { id: client.id } },
        message: `💰 Votre compte a été rechargé de ${amount} DA par ${merchant.merchantProfile.name}.`,
      });

      // Donner 50 XP au marchand pour cette action
      await this.gamificationService.addXp(merchant.id, 50);

      return { message: 'Recharge effectuée avec succès.' };
    } catch (error) {
      this.rechargeStatuses.set(rechargeRequestId, { status: 'failed' });
      console.error(
        'Erreur durant la transaction de recharge par commerçant:',
        error,
      );
      throw new BadRequestException("La recharge n'a pas pu être complétée.");
    }
  }
  async payQr(senderUserId: string, payQrDto: PayQrDto) {
    const { merchantUserId, amount, paymentRequestId, cart } = payQrDto;
    if (senderUserId === merchantUserId) {
      throw new BadRequestException('Vous ne pouvez pas vous payer vous-même.');
    }

    const xpToAward =
      await this.gamificationService.calculateXpForTransaction('payment');

    try {
      await this.prisma.$transaction(async (tx) => {
        // La logique pour trouver les portefeuilles et mettre à jour les soldes est correcte.
        const senderWallet = await tx.wallet.findUnique({
          where: { userId: senderUserId },
        });
        if (!senderWallet || senderWallet.balance < amount) {
          throw new BadRequestException('Solde insuffisant.');
        }

        const receiverWallet = await tx.wallet.findUnique({
          where: { userId: merchantUserId },
        });
        if (!receiverWallet) {
          throw new NotFoundException('Portefeuille du commerçant non trouvé.');
        }

        await tx.wallet.update({
          where: { id: senderWallet.id },
          data: { balance: { decrement: amount } },
        });
        await tx.wallet.update({
          where: { id: receiverWallet.id },
          data: { balance: { increment: amount } },
        });

        // 1. On prépare les données de base de la transaction.
        //    J'utilise `connect` pour lier les relations, c'est une meilleure pratique avec Prisma.
        const transactionData: Prisma.TransactionCreateInput = {
          amount,
          type: 'payment',
          description: `Paiement QR à ${receiverWallet.id}`,
          sender: { connect: { id: senderWallet.id } },
          receiver: { connect: { id: receiverWallet.id } },
          xpGained: xpToAward,
        };

        // 2. On ajoute dynamiquement le panier SEULEMENT s'il a été fourni.
        if (cart && cart.length > 0) {
          // On le caste en `any` pour que Prisma l'accepte sans erreur de typage.
          transactionData.cart = cart as any;
        }

        // 3. On crée la transaction avec notre objet de données proprement construit.
        await tx.transaction.create({
          data: transactionData,
        });
      });
      if (cart && cart.length > 0) {
        try {
          // On ne passe que l'ID et la quantité pour la déduction
          const itemsToDecrease = cart.map((item) => ({
            id: item.id,
            quantity: item.quantity,
          }));
          await this.productsService.decreaseStock(itemsToDecrease);
        } catch (stockError) {
          // Si la déduction du stock échoue, on enregistre l'erreur mais on ne bloque pas le paiement.
          // C'est un choix de conception important. Le paiement a déjà eu lieu.
          console.error(
            'Erreur lors de la déduction du stock après le paiement:',
            stockError,
          );
        }
      }

      if (paymentRequestId) {
        this.paymentStatuses.set(paymentRequestId, 'completed');
      }

      await this.checkAndApplyReferralBonus(senderUserId);
      await this.checkAndApplyReferralBonus(merchantUserId);

      await this.gamificationService.addXp(senderUserId, xpToAward);

      return { message: 'Paiement effectué avec succès.' };
    } catch (error) {
      if (paymentRequestId) {
        this.paymentStatuses.set(paymentRequestId, 'failed');
      }
      throw error;
    }
  }
  async refundItemsFromTransaction(
    merchantUserId: string,
    refundDto: RefundItemsDto,
  ) {
    const { transactionId, items: itemsToRefund } = refundDto;

    return this.prisma.$transaction(async (tx) => {
      const originalTransaction = await tx.transaction.findUnique({
        where: { id: transactionId },
        include: { sender: true, receiver: true },
      });

      if (!originalTransaction) {
        throw new NotFoundException('Transaction originale non trouvée.');
      }
      if (originalTransaction.receiver?.userId !== merchantUserId) {
        throw new UnauthorizedException('Action non autorisée.');
      }
      if (originalTransaction.status === 'refunded') {
        throw new ConflictException(
          'Cette transaction a déjà été entièrement remboursée.',
        );
      }

      const cart = originalTransaction.cart as any[];
      if (!cart) {
        throw new BadRequestException(
          'Cette transaction ne contient aucun article.',
        );
      }

      let refundAmount = 0;
      const updatedCart = cart.map((item) => {
        // Initialiser refundedQuantity s'il n'existe pas
        const refundedQty = item.refundedQuantity || 0;

        const itemToRefund = itemsToRefund.find((i) => i.id === item.id);
        if (itemToRefund) {
          const maxRefundable = item.quantity - refundedQty;
          if (itemToRefund.quantity > maxRefundable) {
            throw new BadRequestException(
              `Vous ne pouvez pas rembourser plus de ${maxRefundable} pour l'article "${item.name}".`,
            );
          }

          refundAmount += item.price * itemToRefund.quantity;
          return {
            ...item,
            refundedQuantity: refundedQty + itemToRefund.quantity,
          };
        }
        return item;
      });

      if (refundAmount <= 0) {
        throw new BadRequestException('Aucun article valide à rembourser.');
      }

      const merchantWallet = await tx.wallet.findUnique({
        where: { userId: merchantUserId },
      });
      if (!merchantWallet || merchantWallet.balance < refundAmount) {
        throw new BadRequestException(
          'Solde insuffisant pour le remboursement.',
        );
      }

      // Mouvements d'argent
      await tx.wallet.update({
        where: { id: merchantWallet.id },
        data: { balance: { decrement: refundAmount } },
      });
      await tx.wallet.update({
        where: { id: originalTransaction.senderId! },
        data: { balance: { increment: refundAmount } },
      });

      const allRefunded = updatedCart.every(
        (item) => (item.refundedQuantity || 0) === item.quantity,
      );

      // Mettre à jour la transaction originale
      await tx.transaction.update({
        where: { id: transactionId },
        data: {
          cart: updatedCart as any,
          status: allRefunded ? 'refunded' : 'partially_refunded',
        },
      });

      // Créer une transaction de type "refund"
      await tx.transaction.create({
        data: {
          amount: refundAmount,
          type: 'refund',
          description: `Remboursement de ${itemsToRefund.length} article(s)`,
          senderId: merchantWallet.id,
          receiverId: originalTransaction.senderId!,
          status: 'completed',
          reference: transactionId,
          cart: itemsToRefund as any,
        },
      });

      return { message: 'Remboursement effectué avec succès.' };
    });
  }

  async sendMoney(senderUserId: string, sendMoneyDto: SendMoneyDto) {
    const {
      amount,
      receiverId,
      scheduleType = 'now',
      plannedDate,
    } = sendMoneyDto;

    // --- CORRECTION 2 : Calculer les XP avant la transaction ---
    const xpToAward =
      await this.gamificationService.calculateXpForTransaction('transfer');

    if (scheduleType === 'now') {
      // Immediate transfer with commission
      const result = await this.prisma.$transaction(async (tx) => {
        const senderWallet = await tx.wallet.findUnique({
          where: { userId: senderUserId },
        });
        if (!senderWallet)
          throw new NotFoundException(
            "Portefeuille de l'expéditeur non trouvé.",
          );

        // Calculate commission for send_money action
        const commission = await this.commissionService.calculateCommission(
          'send_money',
          amount,
        );
        const totalToDeduct = amount + commission;

        if (senderWallet.balance < totalToDeduct)
          throw new BadRequestException('Solde insuffisant.');

        const receiverWallet = await tx.wallet.findUnique({
          where: { userId: receiverId },
        });
        if (!receiverWallet)
          throw new NotFoundException(
            'Portefeuille du destinataire non trouvé.',
          );
        if (senderWallet.id === receiverWallet.id)
          throw new BadRequestException(
            "Vous ne pouvez pas vous envoyer de l'argent à vous-même.",
          );

        // Deduct total (amount + commission) from sender
        await tx.wallet.update({
          where: { id: senderWallet.id },
          data: { balance: { decrement: totalToDeduct } },
        });
        // Credit amount to receiver
        await tx.wallet.update({
          where: { id: receiverWallet.id },
          data: { balance: { increment: amount } },
        });

        // Credit commission to system/admin wallet (assume userId = 'admin' for now)
        if (commission > 0) {
          const adminWallet = await tx.wallet.findUnique({
            where: { userId: 'admin' },
          });
          if (adminWallet) {
            await tx.wallet.update({
              where: { id: adminWallet.id },
              data: { balance: { increment: commission } },
            });
          }
        }

        const receiver = await tx.user.findUnique({
          where: { id: receiverId },
        });
        if (!receiver)
          throw new NotFoundException('Utilisateur destinataire introuvable.');

        await (tx.transaction as any).create({
          data: {
            amount,
            type: 'transfer',
            description: `Transfert à ${receiver.username}`,
            senderId: senderWallet.id,
            receiverId: receiverWallet.id,
            xpGained: xpToAward,
            scheduledType: 'now',
            commission,
          },
        });
        return { message: 'Transfert effectué avec succès.', commission };
      });

      await this.checkAndApplyReferralBonus(senderUserId);
      await this.checkAndApplyReferralBonus(receiverId);

      await this.gamificationService.addXp(senderUserId, xpToAward);
      await this.gamificationService.updateMissionProgress(
        senderUserId,
        'TRANSFER',
      );

      return result;
    } else if (scheduleType === 'deferred' || scheduleType === 'planned') {
      // Save a planned/deferred transfer (not executed yet)
      await this.prisma.scheduledTransfer.create({
        data: {
          senderId: senderUserId,
          receiverId,
          amount,
          type: scheduleType,
          plannedDate: plannedDate ? new Date(plannedDate) : null,
          status: 'PENDING',
        },
      });
      return {
        message:
          scheduleType === 'deferred'
            ? 'Transfert différé enregistré.'
            : 'Transfert planifié enregistré.',
      };
    }
  }

  async recharge(userId: string, rechargeDto: RechargeDto) {
    // Vérifier que l'utilisateur est vérifié
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: {
        identityVerification: {
          select: { status: true },
        },
      },
    });

    if (user?.identityVerification?.status !== 'VERIFIED') {
      throw new ForbiddenException(
        'Votre identité doit être vérifiée pour pouvoir recharger votre compte.',
      );
    }
    const { amount, reference } = rechargeDto;

    const wallet = await this.findOneByUserId(userId);
    if (!wallet) {
      throw new NotFoundException('Portefeuille non trouvé.');
    }

    // 👇 MODIFICATION PRINCIPALE ICI 👇
    // Nous créons maintenant une "RechargeRequest" pour que l'admin la valide.
    const newRechargeRequest = await this.prisma.rechargeRequest.create({
      data: {
        amount,
        reference,
        status: 'PENDING', // Le statut est explicitement mis en attente
        receiver: {
          // On lie la demande au portefeuille du client
          connect: {
            id: wallet.id,
          },
        },
      },
    });

    return {
      message:
        'Votre demande de recharge a été soumise et est en cours de vérification.',
      details: newRechargeRequest,
    };
  }

  getPaymentStatus(requestId: string) {
    const status = this.paymentStatuses.get(requestId);
    if (status === 'completed') {
      this.paymentStatuses.delete(requestId);
      return { status: 'completed' };
    }
    return { status: status || 'pending' };
  }

  async searchUsers(query: string, currentUserId: string) {
    if (!query || query.trim().length < 2) {
      return [];
    }
    return this.prisma.user.findMany({
      where: {
        id: { not: currentUserId },
        OR: [
          { username: { contains: query, mode: 'insensitive' } },
          { fullName: { contains: query, mode: 'insensitive' } },
          { email: { contains: query, mode: 'insensitive' } },
          { phoneNumber: { contains: query, mode: 'insensitive' } },
        ],
      },
      select: {
        id: true,
        username: true,
        fullName: true,
        phoneNumber: true,
      },
      take: 10,
    });
  }
  async getTransactionDetailsForMerchant(
    merchantUserId: string,
    transactionId: string,
  ) {
    const transaction = await this.prisma.transaction.findUnique({
      where: { id: transactionId },
      include: {
        sender: { include: { user: { select: { fullName: true } } } },
        receiver: { include: { user: { select: { fullName: true } } } },
      },
    });

    if (!transaction) {
      throw new NotFoundException('Transaction non trouvée.');
    }

    // On vérifie que le marchand est bien celui qui a reçu l'argent
    if (transaction.receiver?.userId !== merchantUserId) {
      throw new UnauthorizedException(
        'Cette transaction ne vous concerne pas.',
      );
    }

    // On peut maintenant retourner les détails nécessaires au frontend
    return {
      id: transaction.id,
      amount: transaction.amount,
      date: transaction.createdAt,
      clientName: transaction.sender?.user?.fullName || 'Client Inconnu',
      status: transaction.status,
      cart: transaction.cart,
    };
  }
  // NOUVELLE FONCTION POUR DEMANDER UN RETRAIT
  async requestWithdrawal(userId: string, amount: number, bankDetails: any) {
    const wallet = await this.findOneByUserId(userId);
    if (!wallet || wallet.balance < amount) {
      throw new BadRequestException(
        'Solde insuffisant pour effectuer cette demande de retrait.',
      );
    }

    const newRequest = await this.prisma.withdrawalRequest.create({
      data: {
        amount,
        userId,
        bankDetails, // On stocke les informations bancaires
        status: 'PENDING',
      },
    });

    // Optionnel : Notifier l'admin, mais pour l'instant il verra la demande dans son dashboard

    return {
      message: 'Votre demande de retrait a été soumise avec succès.',
      request: newRequest,
    };
  }

  async getTransactions(userId: string) {
    const wallet = await this.findOneByUserId(userId);
    if (!wallet) throw new NotFoundException('Portefeuille non trouvé.');
    const txs = await this.prisma.transaction.findMany({
      where: { OR: [{ senderId: wallet.id }, { receiverId: wallet.id }] },
      include: {
        sender: {
          select: { user: { select: { username: true, fullName: true } } },
        },
        receiver: {
          select: { user: { select: { username: true, fullName: true } } },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: 20,
    });
    // Always include commission in the response
    return txs.map((tx) => ({
      ...tx,
      commission: tx.commission ?? 0,
      cart: tx.cart,
    }));
  }

  async findOneByUserId(userId: string) {
    let wallet = await this.prisma.wallet.findUnique({ where: { userId } });
    if (!wallet) {
      wallet = await this.prisma.wallet.create({ data: { userId } });
    }
    return wallet;
  }

  async transferMoney({
    senderId,
    receiverId,
    amount,
    scheduledType = 'now',
    plannedDate,
    description,
  }: {
    senderId: string;
    receiverId: string;
    amount: number;
    scheduledType?: 'now' | 'deferred' | 'planned';
    plannedDate?: Date;
    description?: string;
  }) {
    if (scheduledType === 'now') {
      // Immediate transfer: create Transaction and update balances
      return this.prisma.$transaction(async (tx) => {
        // Deduct from sender
        await tx.wallet.update({
          where: { userId: senderId },
          data: { balance: { decrement: amount } },
        });
        // Add to receiver
        await tx.wallet.update({
          where: { userId: receiverId },
          data: { balance: { increment: amount } },
        });
        // Get wallet IDs (guaranteed to exist after update)
        const senderWallet = await tx.wallet.findUnique({
          where: { userId: senderId },
        });
        const receiverWallet = await tx.wallet.findUnique({
          where: { userId: receiverId },
        });
        if (!senderWallet || !receiverWallet)
          throw new Error('Wallet not found during transfer');
        // Create transaction record
        return tx.transaction.create({
          data: {
            amount,
            type: 'TRANSFER',
            description,
            senderId: senderWallet.id,
            receiverId: receiverWallet.id,
            status: 'completed',
            scheduledType: 'now',
          },
        });
      });
    } else {
      // Deferred or planned: create ScheduledTransfer, do NOT update balances yet
      return this.prisma.scheduledTransfer.create({
        data: {
          senderId,
          receiverId,
          amount,
          type: scheduledType,
          plannedDate,
          status: 'PENDING',
        },
      });
    }
  }

  // Add a method to process scheduled transfers (to be called by a cron job or manually)
  async processScheduledTransfers() {
    const now = new Date();
    const transfers = await this.prisma.scheduledTransfer.findMany({
      where: {
        status: 'PENDING',
        plannedDate: { lte: now },
      },
    });

    for (const transfer of transfers) {
      await this.prisma.$transaction(async (tx) => {
        // Deduct from sender
        await tx.wallet.update({
          where: { userId: transfer.senderId },
          data: { balance: { decrement: transfer.amount } },
        });
        // Add to receiver
        await tx.wallet.update({
          where: { userId: transfer.receiverId },
          data: { balance: { increment: transfer.amount } },
        });
        // Get wallet IDs (guaranteed to exist after update)
        const senderWallet = await tx.wallet.findUnique({
          where: { userId: transfer.senderId },
        });
        const receiverWallet = await tx.wallet.findUnique({
          where: { userId: transfer.receiverId },
        });
        if (!senderWallet || !receiverWallet)
          throw new Error(
            'Wallet not found during scheduled transfer processing',
          );
        // Create transaction record
        await tx.transaction.create({
          data: {
            amount: transfer.amount,
            type: 'TRANSFER',
            senderId: senderWallet.id,
            receiverId: receiverWallet.id,
            status: 'completed',
            scheduledType: transfer.type,
          },
        });
        // Mark scheduled transfer as completed
        await tx.scheduledTransfer.update({
          where: { id: transfer.id },
          data: { status: 'COMPLETED' },
        });
      });
    }
    return { processed: transfers.length };
  }

  async generateInvoicePdf(
    transactionId: string,
    requestingUserId: string,
  ): Promise<Buffer> {
    const transaction = await this.prisma.transaction.findUnique({
      where: { id: transactionId },
      include: {
        sender: { include: { user: { select: { fullName: true } } } },
        receiver: { include: { user: { select: { fullName: true } } } },
      },
    });

    if (!transaction) {
      throw new NotFoundException('Transaction non trouvée.');
    }
    if (
      transaction.sender?.userId !== requestingUserId &&
      transaction.receiver?.userId !== requestingUserId
    ) {
      throw new UnauthorizedException(
        "Vous n'êtes pas autorisé à accéder à cette facture.",
      );
    }

    return new Promise(async (resolve, reject) => {
      try {
        const doc = new PDFDocument({ size: 'A4', margin: 50 });
        const buffers: Buffer[] = [];
        doc.on('data', buffers.push.bind(buffers));
        doc.on('end', () => resolve(Buffer.concat(buffers)));

        // --- EN-TÊTE ---
        doc
          .fontSize(20)
          .font('Helvetica-Bold')
          .text('DINARY', { align: 'center' });
        doc
          .fontSize(12)
          .font('Helvetica')
          .text('Reçu de Paiement', { align: 'center' });
        doc.moveDown(2);

        // --- INFOS TRANSACTION ---
        doc.fontSize(10);
        doc.text(`De: ${transaction.sender?.user?.fullName || 'Inconnu'}`);
        doc.text(`À: ${transaction.receiver?.user?.fullName || 'Inconnu'}`);
        doc.text(
          `Date: ${new Date(transaction.createdAt).toLocaleString('fr-FR')}`,
        );
        doc.text(`ID Transaction: ${transaction.id}`);
        doc.moveDown(2);

        // --- TABLEAU DES ARTICLES ---
        const cart = transaction.cart as any[];
        if (cart && cart.length > 0) {
          doc.fontSize(12).font('Helvetica-Bold').text('Articles achetés');
          doc.moveDown();

          const tableTop = doc.y;
          const itemX = 50;
          const qtyX = 300;
          const priceX = 380;
          const totalX = 460;

          // Dessiner les en-têtes
          doc.fontSize(10).font('Helvetica-Bold');
          doc.text('Article', itemX, tableTop);
          doc.text('Qté', qtyX, tableTop, { width: 40, align: 'right' });
          doc.text('Prix Unitaire', priceX, tableTop, {
            width: 70,
            align: 'right',
          });
          doc.text('Total', totalX, tableTop, { width: 70, align: 'right' });
          doc.moveDown(0.5);
          const headerY = doc.y;
          doc
            .lineCap('butt')
            .moveTo(itemX, headerY)
            .lineTo(540, headerY)
            .stroke();

          // Dessiner les lignes
          doc.font('Helvetica');
          cart.forEach((item) => {
            doc.moveDown(0.5);
            const itemY = doc.y;
            doc.text(item.name, itemX, itemY, { width: 240 });
            doc.text(item.quantity.toString(), qtyX, itemY, {
              width: 40,
              align: 'right',
            });
            doc.text(`${item.price.toFixed(2)}`, priceX, itemY, {
              width: 70,
              align: 'right',
            });
            doc.text(
              `${(item.price * item.quantity).toFixed(2)}`,
              totalX,
              itemY,
              { width: 70, align: 'right' },
            );
          });
          doc.moveDown(0.5);
          const tableBottomY = doc.y;
          doc
            .lineCap('butt')
            .moveTo(itemX, tableBottomY)
            .lineTo(540, tableBottomY)
            .stroke();
        }

        // --- TOTAL FINAL ---
        doc.moveDown(1);
        doc.fontSize(12).font('Helvetica-Bold');
        doc.text('Montant Total:', 350, doc.y, { align: 'right', width: 100 });
        doc.text(`${transaction.amount.toFixed(2)} DA`, 460, doc.y, {
          align: 'right',
          width: 70,
        });
        doc.moveDown(3);

        // --- QR CODE ---
        const qrCodeData = JSON.stringify({ transactionId: transaction.id });
        const qrCodeImage = await QRCode.toDataURL(qrCodeData);
        doc.image(qrCodeImage, { fit: [100, 100], align: 'center' });
        doc
          .fontSize(8)
          .font('Helvetica')
          .text('Scannez pour un remboursement', { align: 'center' });

        // --- PIED DE PAGE ---
        doc
          .fontSize(10)
          .font('Helvetica')
          .text("Merci d'utiliser Dinary.", 50, 750, { align: 'center' });

        doc.end();
      } catch (error) {
        reject(error);
      }
    });
  }
  async refundTransaction(merchantUserId: string, transactionId: string) {
    return this.prisma.$transaction(async (tx) => {
      // 1. Trouver la transaction originale
      const originalTransaction = await tx.transaction.findUnique({
        where: { id: transactionId },
        include: { sender: true, receiver: true },
      });

      if (!originalTransaction) {
        throw new NotFoundException('Transaction originale non trouvée.');
      }

      // 2. Vérifier que le demandeur est bien le marchand qui a reçu l'argent
      if (originalTransaction.receiver?.userId !== merchantUserId) {
        throw new UnauthorizedException(
          "Vous n'êtes pas autorisé à rembourser cette transaction.",
        );
      }

      // 3. Vérifier que la transaction n'est pas déjà remboursée
      if (originalTransaction.status === 'refunded') {
        throw new ConflictException('Cette transaction a déjà été remboursée.');
      }

      // 4. Vérifier que le marchand a assez d'argent pour rembourser
      const merchantWallet = await tx.wallet.findUnique({
        where: { userId: merchantUserId },
      });
      if (
        !merchantWallet ||
        merchantWallet.balance < originalTransaction.amount
      ) {
        throw new BadRequestException(
          'Solde insuffisant pour effectuer le remboursement.',
        );
      }

      // 5. Effectuer le mouvement d'argent inverse
      // Débiter le marchand
      await tx.wallet.update({
        where: { id: merchantWallet.id },
        data: { balance: { decrement: originalTransaction.amount } },
      });
      // Créditer le client (l'expéditeur original)
      await tx.wallet.update({
        where: { id: originalTransaction.senderId! },
        data: { balance: { increment: originalTransaction.amount } },
      });

      // 6. Mettre à jour le statut de la transaction originale
      await tx.transaction.update({
        where: { id: transactionId },
        data: { status: 'refunded' },
      });

      // 7. Créer une nouvelle transaction de type "refund" pour l'historique
      const refundTransaction = await tx.transaction.create({
        data: {
          amount: originalTransaction.amount,
          type: 'refund',
          description: `Remboursement pour la transaction ${transactionId.substring(0, 8)}`,
          senderId: merchantWallet.id, // Le marchand est maintenant l'expéditeur
          receiverId: originalTransaction.senderId!, // Le client est le destinataire
          status: 'completed',
          reference: transactionId, // Référence à la transaction originale
        },
      });

      return {
        message: 'Remboursement effectué avec succès.',
        refundTransaction,
      };
    });
  }
}
