export class CreateWalletDto {}
