// src/wallet/dto/refund-items.dto.ts
import {
  IsArray,
  IsNotEmpty,
  IsString,
  ValidateNested,
  IsInt,
  Min,
} from 'class-validator';
import { Type } from 'class-transformer';

class RefundItemDto {
  @IsString()
  id: string;

  @IsString()
  name: string;

  // 👇 AJOUTEZ CES LIGNES 👇
  @IsInt()
  @Min(1)
  quantity: number;
}

export class RefundItemsDto {
  @IsString()
  @IsNotEmpty()
  transactionId: string;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => RefundItemDto)
  items: RefundItemDto[];
}
