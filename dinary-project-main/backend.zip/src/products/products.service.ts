// src/products/products.service.ts

import {
  Injectable,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateProductDto } from './dto/create-product.dto';
import { promises as fs } from 'fs';
import * as path from 'path';

@Injectable()
export class ProductsService {
  constructor(private prisma: PrismaService) {}

  private async getMerchantFromUserId(userId: string) {
    const merchant = await this.prisma.merchant.findUnique({
      where: { userId },
    });
    if (!merchant) {
      throw new UnauthorizedException(
        'Profil commerçant non trouvé pour cet utilisateur.',
      );
    }
    return merchant;
  }

  async create(
    createProductDto: CreateProductDto,
    userId: string,
    file?: Express.Multer.File,
  ) {
    const merchant = await this.getMerchantFromUserId(userId);
    let imageUrl: string | undefined = undefined;

    if (file) {
      const filename = `${userId}-${Date.now()}${path.extname(
        file.originalname,
      )}`;
      const imagePath = path.join(
        process.cwd(),
        'uploads',
        'products',
        filename,
      );
      await fs.mkdir(path.dirname(imagePath), { recursive: true });
      await fs.writeFile(imagePath, file.buffer);

      // ✅ CORRECTION : On inclut /uploads dans l'URL sauvegardée
      imageUrl = `/uploads/products/${filename}`;
    }

    return this.prisma.product.create({
      data: {
        ...createProductDto,
        imageUrl,
        merchant: { connect: { id: merchant.id } },
      },
    });
  }

  // ... (findAllForUser reste identique)
  async findAllForUser(userId: string) {
    const merchant = await this.getMerchantFromUserId(userId);
    return this.prisma.product.findMany({
      where: { merchantId: merchant.id },
      orderBy: { createdAt: 'desc' },
    });
  }

  async update(
    id: string,
    updateProductDto: CreateProductDto,
    userId: string,
    file?: Express.Multer.File,
  ) {
    const merchant = await this.getMerchantFromUserId(userId);
    const product = await this.prisma.product.findUnique({ where: { id } });

    if (!product || product.merchantId !== merchant.id) {
      throw new UnauthorizedException('Produit non trouvé ou non autorisé.');
    }

    let imageUrl: string | null | undefined = product.imageUrl;

    if (file) {
      if (product.imageUrl) {
        const oldPath = path.join(process.cwd(), product.imageUrl);
        await fs.unlink(oldPath).catch((err) => console.error(err));
      }

      const filename = `${userId}-${Date.now()}${path.extname(file.originalname)}`;
      const imagePath = path.join('uploads', 'products', filename);
      await fs.mkdir(path.dirname(imagePath), { recursive: true });
      await fs.writeFile(imagePath, file.buffer);

      // ✅ CORRECTION : On inclut aussi /uploads ici
      imageUrl = `/uploads/products/${filename}`;
    }

    return this.prisma.product.update({
      where: { id },
      data: {
        ...updateProductDto,
        imageUrl,
      },
    });
  }

  // ... (les autres fonctions remove et decreaseStock ne changent pas)
  async remove(productId: string, userId: string) {
    const merchant = await this.getMerchantFromUserId(userId);
    const product = await this.prisma.product.findUnique({
      where: { id: productId },
    });

    if (!product) {
      throw new NotFoundException('Produit non trouvé.');
    }
    if (product.merchantId !== merchant.id) {
      throw new UnauthorizedException('Action non autorisée.');
    }

    if (product.imageUrl) {
      const imagePath = path.join(process.cwd(), product.imageUrl);
      await fs.unlink(imagePath).catch((err) => console.error(err));
    }

    await this.prisma.product.delete({ where: { id: productId } });
    return { message: 'Produit supprimé avec succès.' };
  }

  async decreaseStock(items: { id: string; quantity: number }[]) {
    return this.prisma.$transaction(async (tx) => {
      for (const item of items) {
        const product = await tx.product.findUnique({ where: { id: item.id } });
        if (!product) {
          throw new NotFoundException(
            `Produit avec l'ID ${item.id} non trouvé.`,
          );
        }
        if (product.stock !== null && product.stock < item.quantity) {
          throw new Error(
            `Stock insuffisant pour le produit "${product.name}".`,
          );
        }
        await tx.product.update({
          where: { id: item.id },
          data: {
            stock: {
              decrement: item.quantity,
            },
          },
        });
      }
    });
  }
}
