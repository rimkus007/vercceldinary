import {
  Injectable,
  ConflictException,
  InternalServerErrorException,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from 'src/prisma/prisma.service';
import { CreateMerchantDto } from './dto/create-merchant.dto';
import { SuggestMerchantDto } from './dto/suggest-merchant.dto';
import { NearbyMerchantsDto } from './dto/nearby-merchants.dto';
import { UpdateMerchantDto } from './dto/update-merchant.dto';
import { Prisma } from '@prisma/client';
import { fetch } from 'undici';

function clean<T extends Record<string, any>>(obj: T) {
  return Object.fromEntries(
    Object.entries(obj).filter(([, v]) => v !== undefined),
  ) as Partial<T>;
}

// ---------- Geocoding helpers (OpenStreetMap / Nominatim) ----------
async function geocodeAddress(
  address: string,
): Promise<{ lat: number; lng: number } | null> {
  if (!address?.trim()) return null;
  try {
    const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q=${encodeURIComponent(
      address,
    )}`;
    const res = await fetch(url, {
      headers: { 'User-Agent': 'dinary-merchant/1.0 (support@dinary.app)' },
    });
    if (!res.ok) return null;
    const list = (await res.json()) as Array<{ lat: string; lon: string }>;
    if (!list?.length) return null;
    return { lat: parseFloat(list[0].lat), lng: parseFloat(list[0].lon) };
  } catch {
    return null;
  }
}

// reverse geocoding simple (Nominatim)
async function reverseGeocode(
  lat: number,
  lon: number,
): Promise<string | null> {
  try {
    const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}&accept-language=fr`;
    const res = await fetch(url, { headers: { 'User-Agent': 'dinary/1.0' } });
    if (!res.ok) return null;
    const json = (await res.json()) as { display_name?: string };
    return json.display_name ?? null;
  } catch {
    return null;
  }
}

@Injectable()
export class MerchantsService {
  constructor(private prisma: PrismaService) {}

  // ---------- NEARBY ----------
  async findNearby(nearbyMerchantsDto: NearbyMerchantsDto) {
    const { latitude, longitude, radius } = nearbyMerchantsDto;
    if (
      typeof latitude !== 'number' ||
      typeof longitude !== 'number' ||
      typeof radius !== 'number'
    ) {
      throw new BadRequestException(
        'latitude, longitude et radius sont requis.',
      );
    }

    const radiusInMeters = radius * 1000;

    // 1) Essai avec PostGIS (ST_DWithin / geography)
    try {
      const rows = await this.prisma.$queryRaw<
        Array<{ id: string; distance: number }>
      >`
        SELECT id,
               ST_Distance(
                 ST_MakePoint(longitude, latitude)::geography,
                 ST_MakePoint(${longitude}, ${latitude})::geography
               ) AS distance
        FROM "Merchant"
        WHERE longitude IS NOT NULL AND latitude IS NOT NULL
          AND ST_DWithin(
              ST_MakePoint(longitude, latitude)::geography,
              ST_MakePoint(${longitude}, ${latitude})::geography,
              ${radiusInMeters}
          )
        ORDER BY distance;
      `;

      if (!rows.length) return [];

      const ids = rows.map((r) => r.id);
      const merchants = await this.prisma.merchant.findMany({
        where: { id: { in: ids } },
        include: { products: true },
      });

      const distMap = new Map(rows.map((r) => [r.id, r.distance]));
      const merged = merchants
        .map((m) => ({ ...m, distance: distMap.get(m.id) ?? 0 }))
        .sort((a, b) => a.distance - b.distance);

      return merged;
    } catch (e: any) {
      // 2) Fallback Haversine si PostGIS absent (ex: code 42704 “type geography n'existe pas”)
      const rows = await this.prisma.$queryRaw<
        Array<{ id: string; distance: number }>
      >`
        SELECT id,
               6371000 * acos(
                 LEAST(1, GREATEST(-1,
                   cos(radians(${latitude})) * cos(radians(latitude)) *
                   cos(radians(longitude) - radians(${longitude})) +
                   sin(radians(${latitude})) * sin(radians(latitude))
                 ))
               ) AS distance
        FROM "Merchant"
        WHERE longitude IS NOT NULL AND latitude IS NOT NULL
        ORDER BY distance
        LIMIT 500;
      `;

      const filtered = rows.filter((r) => r.distance <= radiusInMeters);
      if (!filtered.length) return [];

      const ids = filtered.map((r) => r.id);
      const merchants = await this.prisma.merchant.findMany({
        where: { id: { in: ids } },
        include: { products: true },
      });

      const distMap = new Map(filtered.map((r) => [r.id, r.distance]));
      const merged = merchants
        .map((m) => ({ ...m, distance: distMap.get(m.id) ?? 0 }))
        .sort((a, b) => a.distance - b.distance);

      return merged;
    }
  }

  // ---------- CREATE ----------
  async create(userId: string, createMerchantDto: CreateMerchantDto) {
    const { name, category, description, address } = createMerchantDto;

    const existing = await this.prisma.merchant.findUnique({
      where: { userId },
    });
    if (existing) {
      throw new ConflictException(
        'Cet utilisateur a déjà un profil de commerçant.',
      );
    }

    let latitude: number | null = null;
    let longitude: number | null = null;

    if (address) {
      const c = await geocodeAddress(address);
      if (c) {
        latitude = c.lat;
        longitude = c.lng;
      }
    }

    try {
      return await this.prisma.merchant.create({
        data: {
          name,
          category,
          description,
          address,
          latitude,
          longitude,
          userId,
        },
      });
    } catch (error) {
      console.error('Erreur lors de la création du commerçant:', error);
      throw new InternalServerErrorException(
        'Une erreur est survenue lors de la création du commerçant.',
      );
    }
  }

  // ---------- ME ----------
  async findMe(userId: string) {
    const merchant = await this.prisma.merchant.findUnique({
      where: { userId },
    });
    if (!merchant) {
      throw new NotFoundException(
        'Profil de commerçant non trouvé pour cet utilisateur.',
      );
    }
    return merchant;
  }

  async updateMerchant(userId: string, dto: UpdateMerchantDto) {
    const merchant = await this.prisma.merchant.findUnique({
      where: { userId },
    });
    if (!merchant) {
      throw new NotFoundException('Profil commerçant non trouvé.');
    }
    return this.prisma.merchant.update({
      where: { id: merchant.id },
      data: dto, // Le DTO contient les champs à mettre à jour
    });
  }

  // PATCH /merchants/me
  async updateByUserId(userId: string, dto: UpdateMerchantDto) {
    const merchant = await this.prisma.merchant.findUnique({
      where: { userId },
    });
    if (!merchant) throw new NotFoundException('Profil commerçant non trouvé.');

    const data: Prisma.MerchantUpdateInput = { ...dto };

    // Si l’adresse est fournie, on (re)géocode pour rafraîchir lat/lng
    if (typeof dto.address === 'string' && dto.address.trim().length > 0) {
      const c = await geocodeAddress(dto.address);
      if (c) {
        (data as any).latitude = c.lat;
        (data as any).longitude = c.lng;
      }
    }

    return this.prisma.merchant.update({
      where: { id: merchant.id },
      data,
    });
  }

  async updateLocation(
    userId: string,
    latitude: number,
    longitude: number,
    address?: string, // L'adresse est optionnelle
  ) {
    const merchant = await this.prisma.merchant.findUnique({
      where: { userId },
    });
    if (!merchant) {
      throw new NotFoundException('Profil commerçant non trouvé.');
    }

    // Le backend se charge de trouver l'adresse si elle n'est pas fournie
    const finalAddress =
      address ||
      (await reverseGeocode(latitude, longitude)) ||
      merchant.address;

    return this.prisma.merchant.update({
      where: { id: merchant.id },
      data: {
        latitude,
        longitude,
        address: finalAddress,
      },
    });
  }
  // ---------- Suggestions ----------
  async suggest(userId: string, suggestMerchantDto: SuggestMerchantDto) {
    const { address } = suggestMerchantDto;

    let latitude: number | null = null;
    let longitude: number | null = null;

    // Si une adresse est fournie, on essaie de la géocoder
    if (address) {
      const coordinates = await geocodeAddress(address);
      if (coordinates) {
        latitude = coordinates.lat;
        longitude = coordinates.lng;
      }
    }

    return this.prisma.merchantSuggestion.create({
      data: {
        ...suggestMerchantDto,
        suggestedById: userId,
        latitude, // 👈 On sauvegarde la latitude
        longitude, // 👈 On sauvegarde la longitude
      },
    });
  }

  async findMySuggestions(userId: string) {
    return this.prisma.merchantSuggestion.findMany({
      where: { suggestedById: userId },
      orderBy: { createdAt: 'desc' },
    });
  }
  async findAllOfficial() {
    // Le filtre "where" a été supprimé car userId est un champ
    // obligatoire et ne peut jamais être null.
    // Cette fonction récupère donc tous les commerçants officiels.
    return this.prisma.merchant.findMany({
      include: {
        user: {
          select: { email: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  // MODIFICATION : Renommez et clarifiez la fonction des suggestions
  async findAllSuggestions() {
    return this.prisma.merchantSuggestion.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        suggestedBy: {
          select: {
            id: true,
            fullName: true,
            email: true,
          },
        },
      },
    });
  }
  // ---------- Dashboard ----------
  async getDashboardData(userId: string) {
    const merchant = await this.prisma.merchant.findUnique({
      where: { userId },
      include: {
        user: {
          include: {
            wallet: true,
            profile: true,
          },
        },
      },
    });

    if (!merchant || !merchant.user.wallet) {
      throw new NotFoundException(
        'Profil commerçant ou portefeuille introuvable.',
      );
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const transactionsToday = await this.prisma.transaction.findMany({
      where: {
        receiverId: merchant.user.wallet.id,
        createdAt: { gte: today, lt: tomorrow },
      },
    });

    const revenueToday = transactionsToday.reduce(
      (sum, tx) => sum + tx.amount,
      0,
    );
    const transactionsTodayCount = transactionsToday.length;
    const newCustomersToday = Math.floor(transactionsTodayCount / 3);

    const recentTransactions = await this.prisma.transaction.findMany({
      where: { receiverId: merchant.user.wallet.id },
      orderBy: { createdAt: 'desc' },
      take: 5,
      include: {
        sender: {
          include: { user: { select: { fullName: true } } },
        },
      },
    });

    return {
      balance: merchant.user.wallet.balance,
      xp: merchant.user.profile?.xp || 0,
      level: merchant.user.profile?.level || 1,
      nextLevelXP: 1000,
      xpPercentage: ((merchant.user.profile?.xp || 0) / 1000) * 100,
      revenueToday,
      transactionsToday: transactionsTodayCount,
      newCustomersToday,
      missionProgress: 3,
      missionTotal: 5,
      recentTransactions: recentTransactions.map((tx) => ({
        id: tx.id,
        amount: tx.amount,
        user: tx.sender?.user?.fullName || 'Client Inconnu',
        type: tx.type,
        date: tx.createdAt.toISOString(),
      })),
    };
  }
}
