// Fichier : src/merchants/merchants.controller.ts

import {
  Controller,
  Get,
  Post,
  Body,
  UseGuards,
  Req,
  Query,
  Patch,
  UnauthorizedException,
} from '@nestjs/common';
import { MerchantsService } from './merchants.service';
import { CreateMerchantDto } from './dto/create-merchant.dto';
import { SuggestMerchantDto } from './dto/suggest-merchant.dto';
import { NearbyMerchantsDto } from './dto/nearby-merchants.dto';
import { UpdateLocationDto } from './dto/update-location.dto';
import { UpdateMerchantDto } from './dto/update-merchant.dto';
import { JwtAuthGuard } from '../auth/guards/JwtAuthGuard'; // ✅ Utiliser JwtAuthGuard

@Controller('merchants')
@UseGuards(JwtAuthGuard) // ✅ Appliquer le guard à tout le contrôleur
export class MerchantsController {
  constructor(private readonly merchantsService: MerchantsService) {}

  // ✅ Fonction utilitaire pour récupérer l'ID utilisateur de manière fiable
  private getUserId(req: any): string {
    const userId = req.user?.id || req.user?.sub;
    if (!userId) {
      throw new UnauthorizedException(
        'ID utilisateur non trouvé dans le token',
      );
    }
    return userId;
  }

  @Patch('me')
  async updateMe(@Req() req: any, @Body() dto: UpdateMerchantDto) {
    const userId = this.getUserId(req);
    return this.merchantsService.updateMerchant(userId, dto);
  }

  @Post()
  create(@Req() req: any, @Body() createMerchantDto: CreateMerchantDto) {
    const userId = this.getUserId(req);
    return this.merchantsService.create(userId, createMerchantDto);
  }

  @Get('me')
  findMyProfile(@Req() req: any) {
    const userId = this.getUserId(req);
    return this.merchantsService.findMe(userId);
  }

  @Get('dashboard')
  getDashboardData(@Req() req: any) {
    const userId = this.getUserId(req);
    return this.merchantsService.getDashboardData(userId);
  }

  @Post('suggest')
  suggest(@Req() req: any, @Body() suggestMerchantDto: SuggestMerchantDto) {
    const userId = this.getUserId(req);
    return this.merchantsService.suggest(userId, suggestMerchantDto);
  }

  @Get('suggestions/my')
  findMySuggestions(@Req() req: any) {
    const userId = this.getUserId(req);
    return this.merchantsService.findMySuggestions(userId);
  }

  @Get('nearby')
  findNearby(@Query() nearbyMerchantsDto: NearbyMerchantsDto) {
    return this.merchantsService.findNearby(nearbyMerchantsDto);
  }

  @Patch('me/location')
  async updateMyLocation(@Req() req: any, @Body() dto: UpdateLocationDto) {
    const userId = this.getUserId(req);
    return this.merchantsService.updateLocation(
      userId,
      dto.latitude,
      dto.longitude,
      dto.address,
    );
  }
}
