export class Merchant {}
