// src/gamification/gamification.service.ts

import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { MissionStatus } from '@prisma/client';
import { getXpForLevel } from './level.constants'; // Assurez-vous que ce fichier de secours existe

@Injectable()
export class GamificationService {
  constructor(private prisma: PrismaService) {}

  /**
   * Trouve le profil de gamification d'un utilisateur. S'il n'existe pas, il le crée.
   */
  async getProfile(userId: string) {
    // CORRECTION : On utilise "userProfile" au lieu de "gamification"
    let profile = await this.prisma.userProfile.findUnique({
      where: { userId },
    });

    if (!profile) {
      // CORRECTION : On utilise "userProfile"
      profile = await this.prisma.userProfile.create({
        data: { userId },
      });
    }

    const nextLevelNumber = profile.level + 1;

    const nextLevelRule = await this.prisma.levelRule.findUnique({
      where: { level: nextLevelNumber },
    });

    const xpToNextLevel = nextLevelRule
      ? nextLevelRule.xpRequired
      : getXpForLevel(profile.level);

    return {
      ...profile,
      xpToNextLevel,
    };
  }

  /**
   * Ajoute de l'XP à un utilisateur et vérifie s'il doit monter de niveau.
   */
  async addXp(userId: string, xp: number) {
    // CORRECTION : On utilise "userProfile"
    const updatedProfile = await this.prisma.userProfile.update({
      where: { userId },
      data: { xp: { increment: xp } },
    });

    await this.checkLevelUp(userId, updatedProfile.xp);
    return updatedProfile;
  }

  /**
   * Vérifie et applique la montée de niveau en se basant sur les règles de l'admin.
   */
  async checkLevelUp(userId: string, currentXp: number): Promise<boolean> {
    // CORRECTION : On utilise "userProfile"
    const profile = await this.prisma.userProfile.findUnique({
      where: { userId },
    });
    if (!profile) return false;

    const nextLevelNumber = profile.level + 1;
    const nextLevelRule = await this.prisma.levelRule.findUnique({
      where: { level: nextLevelNumber },
    });

    const xpForNextLevel = nextLevelRule
      ? nextLevelRule.xpRequired
      : getXpForLevel(profile.level);

    if (currentXp >= xpForNextLevel) {
      const remainingXp = currentXp - xpForNextLevel;
      // CORRECTION : On utilise "userProfile"
      await this.prisma.userProfile.update({
        where: { userId },
        data: {
          level: { increment: 1 },
          xp: remainingXp,
        },
      });
      // Appel récursif pour gérer les montées de plusieurs niveaux
      await this.checkLevelUp(userId, remainingXp);
      return true;
    }
    return false;
  }

  /**
   * Calcule les XP pour une transaction selon les règles de l'admin.
   */
  async calculateXpForTransaction(transactionType: string): Promise<number> {
    const rule = await this.prisma.xpRule.findFirst({
      where: {
        action: {
          equals: transactionType,
          mode: 'insensitive',
        },
        isActive: true,
      },
    });
    return rule ? rule.xpValue : 0;
  }

  /**
   * Récupère le classement.
   */
  async getLeaderboard() {
    // CORRECTION : On utilise "userProfile"
    return this.prisma.userProfile.findMany({
      orderBy: { xp: 'desc' },
      take: 10,
      include: {
        user: {
          select: {
            username: true,
            fullName: true,
          },
        },
      },
    });
  }

  /**
   * Met à jour la progression d'une mission pour un utilisateur.
   */
  async updateMissionProgress(
    userId: string,
    missionType: string,
    progressToAdd: number = 1,
  ) {
    const userProfile = await this.getProfile(userId);

    const missions = await this.prisma.mission.findMany({
      where: {
        type: { equals: missionType, mode: 'insensitive' },
        status: MissionStatus.ACTIVE,
      },
    });

    if (!missions.length) return;

    for (const mission of missions) {
      let userMission = await this.prisma.userMission.findUnique({
        where: {
          // CORRECTION : Le champ unique est "userProfileId_missionId"
          userProfileId_missionId: {
            userProfileId: userProfile.id,
            missionId: mission.id,
          },
        },
      });

      if (!userMission) {
        userMission = await this.prisma.userMission.create({
          data: {
            // CORRECTION : Le champ est "userProfileId"
            userProfileId: userProfile.id,
            missionId: mission.id,
          },
        });
      }

      if (userMission.isCompleted) continue;

      const newProgress = userMission.progress + progressToAdd;

      if (newProgress >= mission.goal) {
        await this.prisma.userMission.update({
          where: { id: userMission.id },
          data: {
            progress: mission.goal,
            isCompleted: true,
            completedAt: new Date(),
          },
        });
        await this.addXp(userId, mission.xpReward);
        await this.prisma.notification.create({
          data: {
            userId,
            message: `🎉 Mission accomplie : "${mission.title}" ! Vous avez gagné ${mission.xpReward} XP.`,
          },
        });
      } else {
        await this.prisma.userMission.update({
          where: { id: userMission.id },
          data: { progress: newProgress },
        });
      }
    }
  }

  /**
   * Récupère toutes les missions et la progression de l'utilisateur.
   */
  async getUserMissionsWithProgress(userId: string) {
    const userProfile = await this.getProfile(userId);

    const allMissions = await this.prisma.mission.findMany();
    const userMissions = await this.prisma.userMission.findMany({
      // CORRECTION : Le champ de recherche est "userProfileId"
      where: { userProfileId: userProfile.id },
    });

    return allMissions.map((mission) => {
      const userProgress = userMissions.find(
        (um) => um.missionId === mission.id,
      );
      return {
        ...mission,
        progress: userProgress?.progress || 0,
        isCompleted: userProgress?.isCompleted || false,
        completedAt: userProgress?.completedAt || null,
      };
    });
  }
  async getLevelRules() {
    return this.prisma.levelRule.findMany({
      orderBy: {
        level: 'asc',
      },
    });
  }
}
