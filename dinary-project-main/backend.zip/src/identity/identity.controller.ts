// src/identity/identity.controller.ts
import {
  Controller,
  Post,
  UseGuards,
  UseInterceptors,
  UploadedFiles,
  Body,
  Request,
  Get,
  UnauthorizedException,
} from '@nestjs/common';

import { AuthGuard } from '@nestjs/passport';
import { FileFieldsInterceptor } from '@nestjs/platform-express';
import { JwtAuthGuard } from 'src/auth/guards/JwtAuthGuard';
import { GetUser } from '../auth/decorators/get-user.decorator';
import type { User } from '@prisma/client';
import { IdentityService } from './identity.service';
import { CreateIdentityVerificationDto } from './dto/create-identity-verification.dto';

@UseGuards(AuthGuard('jwt'))
@Controller('identity')
export class IdentityController {
  constructor(private readonly identityService: IdentityService) {}

  private getUserId(req: any): string {
    const userId = req.user?.sub;
    if (!userId) {
      throw new UnauthorizedException(
        'ID utilisateur non trouvé dans le token.',
      );
    }
    return userId;
  }

  @Post('upload')
  @UseInterceptors(
    FileFieldsInterceptor([
      { name: 'frontImage', maxCount: 1 },
      { name: 'backImage', maxCount: 1 },
      { name: 'selfieImage', maxCount: 1 },
    ]),
  )
  async submitDocuments(
    @GetUser() user: User,
    @UploadedFiles()
    files: {
      frontImage?: Express.Multer.File[];
      backImage?: Express.Multer.File[];
      selfieImage?: Express.Multer.File[]; // <-- AJOUTÉ
    },
    @Body() createDto: CreateIdentityVerificationDto,
  ) {
    return this.identityService.submitDocuments(
      user.id,
      createDto.documentType,
      createDto.selfieInstruction, // <-- AJOUTÉ
      files,
    );
  }

  @Get('status')
  getStatus(@Request() req) {
    const userId = this.getUserId(req);
    return this.identityService.getStatus(userId);
  }
}
