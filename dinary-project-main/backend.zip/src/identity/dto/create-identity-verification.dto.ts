// src/identity/dto/create-identity-verification.dto.ts

import { IsIn, IsNotEmpty, IsString } from 'class-validator';

export class CreateIdentityVerificationDto {
  @IsNotEmpty()
  @IsIn(['ID_CARD', 'PASSPORT', 'DRIVER_LICENSE'])
  documentType: 'ID_CARD' | 'PASSPORT' | 'DRIVER_LICENSE';

  // NOUVEAU: Ajout de la validation pour l'instruction du selfie
  @IsNotEmpty()
  @IsString()
  selfieInstruction: string;
}
