// src/identity/identity.service.ts
import {
  Injectable,
  ConflictException,
  NotFoundException,
} from '@nestjs/common';
import { PrismaService } from 'src/prisma/prisma.service';
import { v4 as uuidv4 } from 'uuid'; // Pour générer des noms de fichiers uniques
import * as fs from 'fs'; // Pour interagir avec le système de fichiers
import * as path from 'path'; // Pour gérer les chemins de fichiers

@Injectable()
export class IdentityService {
  constructor(private prisma: PrismaService) {}

  async submitDocuments(
    userId: string,
    documentType: 'ID_CARD' | 'PASSPORT' | 'DRIVER_LICENSE',
    selfieInstruction: string,
    files: {
      frontImage?: Express.Multer.File[];
      backImage?: Express.Multer.File[];
      selfieImage?: Express.Multer.File[];
    },
  ) {
    const existingVerification =
      await this.prisma.identityVerification.findUnique({
        where: { userId },
      });

    if (existingVerification && existingVerification.status !== 'REJECTED') {
      throw new ConflictException(
        'Vous avez déjà une vérification en cours ou approuvée.',
      );
    }

    if (!files.frontImage || !files.selfieImage) {
      // NOUVEAU: on vérifie aussi le selfie
      throw new NotFoundException(
        'Les images du document et le selfie sont obligatoires.',
      );
    }

    // --- NOUVELLE LOGIQUE DE SAUVEGARDE ---

    // 1. Définir le chemin de sauvegarde (ex: /uploads/documents/)
    const uploadPath = path.join(process.cwd(), 'uploads', 'documents');
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }

    const frontImage = files.frontImage[0];
    const frontImageExt = path.extname(frontImage.originalname);
    const frontImageName = `${uuidv4()}${frontImageExt}`;
    fs.writeFileSync(path.join(uploadPath, frontImageName), frontImage.buffer);
    const frontImageUrl = `documents/${frontImageName}`;

    let backImageUrl: string | null = null;
    if (files.backImage && files.backImage.length > 0) {
      const backImage = files.backImage[0];
      const backImageExt = path.extname(backImage.originalname);
      const backImageName = `${uuidv4()}${backImageExt}`;
      fs.writeFileSync(path.join(uploadPath, backImageName), backImage.buffer);
      backImageUrl = `documents/${backImageName}`;
    }

    const selfieImage = files.selfieImage[0];
    const selfieImageExt = path.extname(selfieImage.originalname);
    const selfieImageName = `${uuidv4()}${selfieImageExt}`;
    fs.writeFileSync(
      path.join(uploadPath, selfieImageName),
      selfieImage.buffer,
    );
    const selfieImageUrl = `documents/${selfieImageName}`;

    // --- FIN DE LA NOUVELLE LOGIQUE ---

    return this.prisma.identityVerification.upsert({
      where: { userId },
      update: {
        status: 'PENDING',
        documentType,
        frontImageUrl, // Sauvegarde le nouveau chemin
        backImageUrl,
        selfieImageUrl,
        selfieInstruction,
        rejectionReason: null,
      },
      create: {
        userId,
        documentType,
        frontImageUrl,
        backImageUrl,
        selfieImageUrl,
        selfieInstruction,
      },
    });
  }

  async getStatus(userId: string) {
    // ... (votre code existant ici, pas de changement nécessaire)
    const verification = await this.prisma.identityVerification.findUnique({
      where: { userId },
      select: {
        status: true,
        rejectionReason: true,
        documentType: true,
      },
    });

    if (!verification) {
      return { status: 'NOT_SUBMITTED' };
    }
    return verification;
  }
}
