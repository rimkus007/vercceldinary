// src/app.module.ts
import {
  Module,
  NestModule,
  MiddlewareConsumer, // <--- AJOUT IMPORTANT
} from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { PrismaModule } from './prisma/prisma.module';
import { MerchantsModule } from './merchants/merchants.module';
import { RequestsModule } from './requests/requests.module';
import { WalletModule } from './wallet/wallet.module';
import { GamificationModule } from './gamification/gamification.module';
import { AdminModule } from './admin/admin.module';
import { ProductsModule } from './products/products.module';
import { NotificationsModule } from './notifications/notifications.module';
import { FriendsModule } from './friends/friends.module';
import { IdentityModule } from './identity/identity.module';
import { UpdateUserActivityMiddleware } from './middleware/update-user-activity.middleware'; // <--- AJOUT IMPORTANT

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    PrismaModule,
    UsersModule, // UsersModule doit être ici pour que le middleware puisse l'utiliser
    AuthModule,
    MerchantsModule,
    RequestsModule,
    WalletModule,
    GamificationModule,
    AdminModule,
    ProductsModule,
    NotificationsModule,
    FriendsModule,
    IdentityModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
// La correction cruciale est d'implémenter NestModule
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(UpdateUserActivityMiddleware).forRoutes('*'); // Applique le middleware à TOUTES les routes
  }
}
