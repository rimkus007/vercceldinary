// src/admin/admin.service.ts
import {
  Injectable,
  NotFoundException,
  ConflictException,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Prisma } from '@prisma/client';
import { CreateNotificationDto } from './dto/create-notification.dto';
import { GamificationService } from 'src/gamification/gamification.service';
import { CreateMissionDto } from './dto/create-mission.dto';
import { CreateCommissionRuleDto } from './dto/create-commission-rule.dto';
import { UpdateCommissionRuleDto } from './dto/update-commission-rule.dto';
import { CreateXpRuleDto } from './dto/create-xp-rule.dto';
import { UpdateXpRuleDto } from './dto/update-xp-rule.dto';
import { CreateLevelRuleDto } from './dto/create-level-rule.dto';
import { UpdateLevelRuleDto } from './dto/update-level-rule.dto';
import { randomUUID } from 'crypto';
import * as fs from 'fs';
import * as path from 'path';
import * as bcrypt from 'bcrypt';

export interface MessageRecord {
  id: string;
  senderId: string;
  content: string;
  timestamp: string;
  read: boolean;
}
@Injectable()
export class AdminService {
  constructor(
    private prisma: PrismaService,
    private gamificationService: GamificationService,
  ) {}

  /**
   * In‑memory store for support conversations between l'administration et les utilisateurs.
   * Chaque clé de l'objet représente l'identifiant d'un utilisateur (non administrateur) et
   * contient une liste de messages échangés avec l'admin. Les messages ne sont pas persistés
   * en base de données mais permettent de démontrer le fonctionnement de la messagerie.
   */
  private conversations: Record<string, { messages: MessageRecord[] }> = {};

  /**
   * Représente un message échangé dans la messagerie interne.
   */

  async getReferralStats() {
    const totalReferrals = await this.prisma.user.count({
      where: { referredById: { not: null } },
    });
    const pendingReferrals = 0;
    const completedReferrals = totalReferrals;
    const rewardedReferrals = await this.prisma.transaction.count({
      where: { type: 'bonus' },
    });
    const cancelledReferrals = 0;
    const totalRewardsAgg = await this.prisma.transaction.aggregate({
      _sum: { amount: true },
      where: { type: 'bonus' },
    });
    const totalRewards = totalRewardsAgg._sum.amount || 0;
    const conversionRate =
      totalReferrals > 0 ? (completedReferrals / totalReferrals) * 100 : 0;
    const topReferrersRaw = await this.prisma.user.findMany({
      where: { referrals: { some: {} } },
      select: {
        id: true,
        fullName: true,
        referrals: { select: { id: true } },
        wallet: { select: { id: true } },
      },
    });
    const topReferrers = await Promise.all(
      topReferrersRaw.map(async (user) => {
        let rewards = 0;
        if (user.wallet) {
          const agg = await this.prisma.transaction.aggregate({
            _sum: { amount: true },
            where: { type: 'bonus', receiverId: user.wallet.id },
          });
          rewards = agg._sum.amount || 0;
        }
        return {
          id: user.id,
          name: user.fullName,
          referrals: user.referrals.length,
          rewards,
        };
      }),
    );
    topReferrers.sort(
      (a, b) => b.referrals - a.referrals || b.rewards - a.rewards,
    );
    const top5 = topReferrers.slice(0, 5);
    return {
      totalReferrals,
      pendingReferrals,
      completedReferrals,
      rewardedReferrals,
      cancelledReferrals,
      totalRewards,
      conversionRate: Math.round(conversionRate * 10) / 10,
      topReferrers: top5,
    };
  }

  async getPendingWithdrawals() {
    return this.prisma.withdrawalRequest.findMany({
      where: { status: 'PENDING' },
      include: {
        user: {
          select: {
            fullName: true,
            email: true,
            wallet: { select: { balance: true } },
          },
        },
      },
      orderBy: { createdAt: 'asc' },
    });
  }

  async approveWithdrawal(requestId: string) {
    return this.prisma.$transaction(async (tx) => {
      const request = await tx.withdrawalRequest.findUnique({
        where: { id: requestId },
        include: { user: { include: { wallet: true } } },
      });

      if (!request || request.status !== 'PENDING') {
        throw new NotFoundException('Demande non trouvée ou déjà traitée.');
      }
      if (
        !request.user.wallet ||
        request.user.wallet.balance < request.amount
      ) {
        throw new BadRequestException(
          "Solde de l'utilisateur insuffisant pour ce retrait.",
        );
      }

      await tx.wallet.update({
        where: { id: request.user.wallet.id },
        data: { balance: { decrement: request.amount } },
      });

      const updatedRequest = await tx.withdrawalRequest.update({
        where: { id: requestId },
        data: { status: 'APPROVED' },
      });

      // Créer une transaction pour l'historique de l'utilisateur
      await tx.transaction.create({
        data: {
          amount: request.amount,
          type: 'withdrawal',
          description: "Retrait approuvé par l'administration",
          senderId: request.user.wallet.id,
          // ✅ CORRECTION : On ajoute le receiverId même pour un retrait pour satisfaire le schéma
          receiverId: request.user.wallet.id,
          status: 'completed',
        },
      });

      await tx.notification.create({
        data: {
          userId: request.userId,
          message: `Votre demande de retrait de ${request.amount} DZD a été approuvée.`,
        },
      });

      return updatedRequest;
    });
  }

  async rejectWithdrawal(requestId: string, reason: string) {
    const request = await this.prisma.withdrawalRequest.findUnique({
      where: { id: requestId },
    });
    if (!request || request.status !== 'PENDING') {
      throw new NotFoundException('Demande non trouvée ou déjà traitée.');
    }

    const updatedRequest = await this.prisma.withdrawalRequest.update({
      where: { id: requestId },
      data: { status: 'REJECTED', rejectionReason: reason },
    });

    await this.prisma.notification.create({
      data: {
        userId: request.userId,
        message: `Votre demande de retrait a été rejetée. Motif : ${reason}`,
      },
    });

    return updatedRequest;
  }

  // --- ✅ ACCOUNT STATUS MANAGEMENT ---
  /**
   * Met à jour le statut d'un utilisateur. Seules les valeurs autorisées sont
   * 'active', 'inactive', 'pending' et 'suspended'. Une erreur est levée
   * pour toute autre valeur. Le statut est stocké dans le champ `status` du
   * modèle User. Si le champ n'existe pas pour certains enregistrements,
   * Prisma le créera automatiquement. Cette méthode renvoie l'utilisateur
   * mis à jour avec son identifiant et son nouveau statut.
   */
  async updateUserStatus(id: string, status: string) {
    const allowed = ['active', 'inactive', 'pending', 'suspended'];
    if (!allowed.includes(status)) {
      throw new BadRequestException(
        `Statut utilisateur invalide. Valeurs autorisées : ${allowed.join(
          ', ',
        )}.`,
      );
    }
    // Vérifie l'existence de l'utilisateur
    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) {
      throw new NotFoundException(`Utilisateur avec l'ID ${id} non trouvé.`);
    }
    return this.prisma.user.update({
      where: { id },
      data: { status },
      select: { id: true, status: true, email: true },
    });
  }

  /**
   * Met à jour le statut d'un commerçant. Les valeurs autorisées sont
   * 'active', 'inactive' et 'pending'. Le statut est stocké dans le champ
   * `status` du modèle Merchant. Cette méthode renvoie le commerçant mis à
   * jour avec son identifiant et son nouveau statut.
   */
  async updateMerchantStatus(id: string, status: string) {
    const allowed = ['active', 'inactive', 'pending'];
    if (!allowed.includes(status)) {
      throw new BadRequestException(
        `Statut commerçant invalide. Valeurs autorisées : ${allowed.join(
          ', ',
        )}.`,
      );
    }
    const merchant = await this.prisma.merchant.findUnique({ where: { id } });
    if (!merchant) {
      throw new NotFoundException(`Commerçant avec l'ID ${id} non trouvé.`);
    }
    return this.prisma.merchant.update({
      where: { id },
      data: { status },
      select: { id: true, status: true, name: true },
    });
  }

  async createManualRecharge(body: {
    phone: string;
    amount: number;
    reference?: string;
  }) {
    const { phone, amount, reference } = body;
    const user = await this.prisma.user.findUnique({
      where: { phoneNumber: phone },
    });
    if (!user) {
      throw new NotFoundException('Utilisateur non trouvé avec ce numéro.');
    }
    const wallet = await this.prisma.wallet.findUnique({
      where: { userId: user.id },
    });
    if (!wallet) {
      throw new NotFoundException('Wallet introuvable pour cet utilisateur.');
    }
    const recharge = await this.prisma.rechargeRequest.create({
      data: {
        receiverId: wallet.id,
        amount,
        reference: reference ?? '',
        status: 'APPROVED',
      },
    });
    await this.prisma.wallet.update({
      where: { id: wallet.id },
      data: { balance: { increment: amount } },
    });
    await this.prisma.transaction.create({
      data: {
        amount,
        type: 'recharge',
        description: 'Recharge libre (manuel)',
        receiverId: wallet.id,
        status: 'completed',
        reference: reference ?? '',
      },
    });
    return { success: true, rechargeId: recharge.id };
  }

  // ... (Le reste du fichier reste identique) ...
  async createCommissionRule(data: CreateCommissionRuleDto) {
    // Désactive les règles actives existantes pour la même action et le même public cible
    await this.prisma.commissionRule.updateMany({
      where: {
        action: data.action,
        isActive: true,
        target: data.target ?? 'USER',
      },
      data: {
        isActive: false,
      },
    });
    const target = data.target ?? 'USER';
    return this.prisma.commissionRule.create({
      data: {
        action: data.action,
        type: data.type,
        value: data.value,
        minAmount: data.minAmount,
        maxAmount: data.maxAmount,
        isActive: data.isActive ?? true,
        target,
      },
    });
  }

  async getCommissionRules(target?: 'USER' | 'MERCHANT') {
    const whereClause = target ? { target } : {};
    return this.prisma.commissionRule.findMany({
      where: whereClause,
      orderBy: { createdAt: 'desc' },
    });
  }

  async updateCommissionRule(id: string, data: UpdateCommissionRuleDto) {
    const ruleToUpdate = await this.prisma.commissionRule.findUnique({
      where: { id },
    });
    if (!ruleToUpdate) {
      throw new NotFoundException(`Règle avec l'ID ${id} non trouvée.`);
    }

    if (data.isActive && !ruleToUpdate.isActive) {
      await this.prisma.commissionRule.updateMany({
        where: {
          action: ruleToUpdate.action,
          isActive: true,
          NOT: { id },
          target: data.target ?? ruleToUpdate.target ?? 'USER',
        },
        data: { isActive: false },
      });
    }
    return this.prisma.commissionRule.update({
      where: { id },
      data,
    });
  }

  async deleteCommissionRule(id: string) {
    return this.prisma.commissionRule.delete({ where: { id } });
  }

  // --- 📩 SUPPORT / TICKETS ---

  /**
   * Récupère toutes les demandes en attente. Actuellement, cette méthode
   * s'appuie sur la table `moneyRequest` de Prisma pour regrouper les
   * différentes requêtes (demandes de paiement ou autres). Les requêtes
   * retournées incluent les informations du demandeur et du payeur afin
   * d'afficher clairement l'origine et le destinataire de chaque demande.
   */
  async getAllRequests() {
    return this.prisma.moneyRequest.findMany({
      where: { status: 'pending' },
      include: {
        requester: {
          select: {
            fullName: true,
            username: true,
          },
        },
        payer: {
          select: {
            fullName: true,
            username: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Marque une demande comme résolue et notifie le demandeur. Si la demande
   * est déjà traitée, une exception sera levée. Le status est mis à
   * 'resolved' afin de la distinguer des réponses de paiement classiques.
   */
  async resolveRequest(requestId: string) {
    const request = await this.prisma.moneyRequest.findUnique({
      where: { id: requestId },
    });
    if (!request) {
      throw new NotFoundException('Demande non trouvée.');
    }
    if (request.status !== 'pending') {
      throw new ConflictException('Cette demande a déjà été traitée.');
    }
    const updated = await this.prisma.moneyRequest.update({
      where: { id: requestId },
      data: { status: 'resolved' },
    });
    // Envoyer une notification au demandeur
    await this.prisma.notification.create({
      data: {
        userId: request.requesterId,
        message:
          "Votre demande a été traitée par l'administration. Consultez vos notifications pour plus de détails.",
      },
    });
    return updated;
  }

  async createLevelRule(createLevelRuleDto: CreateLevelRuleDto) {
    const existingLevel = await this.prisma.levelRule.findUnique({
      where: { level: createLevelRuleDto.level },
    });

    if (existingLevel) {
      throw new ConflictException(
        `Une règle pour le niveau ${createLevelRuleDto.level} existe déjà.`,
      );
    }
    // On assigne un rôle par défaut si non fourni
    const role = createLevelRuleDto.role ?? 'USER';
    return this.prisma.levelRule.create({
      data: {
        ...createLevelRuleDto,
        role,
      },
    });
  }

  async getLevelRules(role?: 'USER' | 'MERCHANT') {
    const whereClause = role ? { role } : {};
    return this.prisma.levelRule.findMany({
      where: whereClause,
      orderBy: {
        level: 'asc',
      },
    });
  }

  async updateLevelRule(id: string, updateLevelRuleDto: UpdateLevelRuleDto) {
    return this.prisma.levelRule.update({
      where: { id },
      data: updateLevelRuleDto,
    });
  }

  async deleteLevelRule(id: string) {
    return this.prisma.levelRule.delete({
      where: { id },
    });
  }

  async getPendingRecharges() {
    return this.prisma.rechargeRequest.findMany({
      where: {
        status: 'PENDING',
      },
      include: {
        receiver: {
          include: {
            user: {
              select: {
                fullName: true,
                email: true,
              },
            },
          },
        },
      },
      orderBy: {
        createdAt: 'asc',
      },
    });
  }

  async getDashboardStats() {
    try {
      // --- Périodes de temps ---
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
      const startOfLastMonth = new Date(
        today.getFullYear(),
        today.getMonth() - 1,
        1,
      );
      const sevenDaysAgo = new Date(today);
      sevenDaysAgo.setDate(today.getDate() - 7);
      const fourteenDaysAgo = new Date(today);
      fourteenDaysAgo.setDate(today.getDate() - 14);

      // --- Fonction de calcul de changement (plus robuste) ---
      const calculateChange = (current: number, previous: number) => {
        if (previous === 0) {
          return current > 0 ? 100 : 0; // Évite la division par zéro
        }
        return parseFloat((((current - previous) / previous) * 100).toFixed(1));
      };

      // --- Promesses pour les requêtes concurrentes ---
      const promises = {
        totalUsers: this.prisma.user.count({
          where: { role: { not: 'ADMIN' } },
        }),
        newUsersThisMonth: this.prisma.user.count({
          where: { createdAt: { gte: startOfMonth }, role: { not: 'ADMIN' } },
        }),
        newUsersLastMonth: this.prisma.user.count({
          where: {
            createdAt: { gte: startOfLastMonth, lt: startOfMonth },
            role: { not: 'ADMIN' },
          },
        }),

        activeUsersLast7Days: this.prisma.user.count({
          where: { lastSeen: { gte: sevenDaysAgo }, role: { not: 'ADMIN' } },
        }),
        activeUsersPrevious7Days: this.prisma.user.count({
          where: {
            lastSeen: { gte: fourteenDaysAgo, lt: sevenDaysAgo },
            role: { not: 'ADMIN' },
          },
        }),

        totalMerchants: this.prisma.merchant.count(),
        newMerchantsThisMonth: this.prisma.merchant.count({
          where: { createdAt: { gte: startOfMonth } },
        }),
        newMerchantsLastMonth: this.prisma.merchant.count({
          where: { createdAt: { gte: startOfLastMonth, lt: startOfMonth } },
        }),

        pendingVerifications: this.prisma.identityVerification.count({
          where: { status: 'PENDING' },
        }),

        totalTransactions: this.prisma.transaction.count(),
        transactionsThisMonth: this.prisma.transaction.count({
          where: { createdAt: { gte: startOfMonth } },
        }),
        transactionsLastMonth: this.prisma.transaction.count({
          where: { createdAt: { gte: startOfLastMonth, lt: startOfMonth } },
        }),

        totalVolumeAgg: this.prisma.transaction.aggregate({
          _sum: { amount: true },
        }),
        volumeThisMonthAgg: this.prisma.transaction.aggregate({
          _sum: { amount: true },
          where: { createdAt: { gte: startOfMonth } },
        }),
        volumeLastMonthAgg: this.prisma.transaction.aggregate({
          _sum: { amount: true },
          where: { createdAt: { gte: startOfLastMonth, lt: startOfMonth } },
        }),
      };

      const results = await Promise.all(Object.values(promises));
      const [
        totalUsers,
        newUsersThisMonth,
        newUsersLastMonth,
        activeUsersLast7Days,
        activeUsersPrevious7Days,
        totalMerchants,
        newMerchantsThisMonth,
        newMerchantsLastMonth,
        pendingVerifications,
        totalTransactions,
        transactionsThisMonth,
        transactionsLastMonth,
        totalVolumeAgg,
        volumeThisMonthAgg,
        volumeLastMonthAgg,
      ] = results as any[];

      // --- Formatage des résultats ---
      return {
        totalUsers: {
          value: totalUsers,
          change: calculateChange(newUsersThisMonth, newUsersLastMonth),
        },
        activeUsers: {
          value: activeUsersLast7Days,
          change: calculateChange(
            activeUsersLast7Days,
            activeUsersPrevious7Days,
          ),
        },
        totalMerchants: {
          value: totalMerchants,
          change: calculateChange(newMerchantsThisMonth, newMerchantsLastMonth),
        },
        totalVolume: {
          value: totalVolumeAgg._sum.amount || 0,
          change: calculateChange(
            volumeThisMonthAgg._sum.amount || 0,
            volumeLastMonthAgg._sum.amount || 0,
          ),
        },
        totalTransactions: {
          value: totalTransactions,
          change: calculateChange(transactionsThisMonth, transactionsLastMonth),
        },
        pendingVerifications: { value: pendingVerifications },
      };
    } catch (error) {
      console.error('Erreur dans AdminService getDashboardStats :', error);
      throw error;
    }
  }

  async getAllUsers() {
    // 1. On récupère les utilisateurs avec toutes les données dont vous avez besoin
    const users = await this.prisma.user.findMany({
      where: { role: { not: 'ADMIN' } },
      select: {
        id: true,
        email: true,
        username: true,
        fullName: true,
        phoneNumber: true,
        role: true,
        createdAt: true,
        updatedAt: true,
        isVerified: true,
        lastSeen: true,
        status: true, // inclut le statut stocké en base
        profile: {
          select: {
            level: true,
            xp: true,
          },
        },
        wallet: {
          select: {
            _count: {
              select: {
                sentTransactions: true,
                receivedTransactions: true,
              },
            },
          },
        },
      },
      orderBy: {
        createdAt: 'desc', // Trier par date de création est une bonne pratique
      },
    });

    // 2. On définit notre critère d'activité : vu il y a moins de 7 jours
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    // 3. On ajoute ou normalise le champ 'status' pour chaque utilisateur. Si le
    // statut est défini en base (par exemple suite à une désactivation manuelle), on
    // l'utilise. Sinon, on calcule un statut basé sur la dernière activité. Les
    // valeurs retournées sont en anglais ('active' / 'inactive') pour rester
    // cohérentes avec le frontend.
    return users.map((user) => {
      const dbStatus = user.status as string | null | undefined;
      // Si un statut est stocké, on le normalise en minuscules
      if (dbStatus) {
        return {
          ...user,
          status: dbStatus.toLowerCase(),
        };
      }
      const isActive = user.lastSeen && new Date(user.lastSeen) > sevenDaysAgo;
      return {
        ...user,
        status: isActive ? 'active' : 'inactive',
      };
    });
  }

  async getAllMerchants() {
    try {
      return await this.prisma.merchant.findMany({
        where: {
          isSuggestion: false,
        },
        select: {
          id: true,
          name: true,
          status: true,
          rating: true,
          totalRevenue: true,
          updatedAt: true,
          user: {
            select: {
              email: true,
            },
          },
        },
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des commerçants:', error);
      throw error;
    }
  }

  async approveRecharge(rechargeId: string) {
    const request = await this.prisma.rechargeRequest.findUnique({
      where: { id: rechargeId },
      include: { receiver: true },
    });

    if (!request || request.status !== 'PENDING') {
      throw new NotFoundException(
        `Demande de recharge non trouvée ou déjà traitée.`,
      );
    }

    return this.prisma.$transaction(async (tx) => {
      const xpGained =
        await this.gamificationService.calculateXpForTransaction('recharge');

      if (xpGained > 0) {
        await this.gamificationService.getProfile(request.receiver.userId);
        await tx.userProfile.update({
          where: { userId: request.receiver.userId },
          data: { xp: { increment: xpGained } },
        });
      }

      await tx.wallet.update({
        where: { id: request.receiverId },
        data: { balance: { increment: request.amount } },
      });

      await tx.transaction.create({
        data: {
          amount: request.amount,
          type: 'recharge',
          description: `Recharge approuvée (Ref: ${request.reference})`,
          receiverId: request.receiverId,
          status: 'completed',
          reference: request.reference,
          xpGained: xpGained,
        },
      });

      const updatedRequest = await tx.rechargeRequest.update({
        where: { id: rechargeId },
        data: { status: 'APPROVED' },
      });

      await tx.notification.create({
        data: {
          userId: request.receiver.userId,
          message: `Votre demande de recharge de ${request.amount} DZD a été approuvée et vous avez gagné ${xpGained} points !`,
        },
      });

      return updatedRequest;
    });
  }

  async getGamificationStats() {
    const totalUsers = await this.prisma.user.count({
      where: { role: { not: 'ADMIN' } },
    });
    const activeRules = await this.prisma.xpRule.count({
      where: { isActive: true },
    });
    const userProfiles = await this.prisma.userProfile.findMany();

    const totalXPAwarded = userProfiles.reduce(
      (sum, profile) => sum + profile.xp,
      0,
    );
    const avgLevel =
      userProfiles.length > 0
        ? userProfiles.reduce((sum, profile) => sum + profile.level, 0) /
          userProfiles.length
        : 0;

    return {
      totalUsers,
      totalXPAwarded,
      activeRules,
      avgLevel,
    };
  }

  async getGamificationLevels() {
    return this.prisma.levelRule.findMany({
      orderBy: {
        level: 'asc',
      },
    });
  }

  async getUserProgressions() {
    const levelRules = await this.prisma.levelRule.findMany({
      orderBy: { level: 'asc' },
    });

    if (levelRules.length === 0) {
      return [];
    }

    const users = await this.prisma.user.findMany({
      where: { role: { not: 'ADMIN' } },
      include: {
        profile: true,
      },
    });

    return users
      .map((user) => {
        const profile = user.profile;
        if (!profile) return null;

        const currentLevelRule = levelRules.find(
          (rule) => rule.level === profile.level,
        );
        const nextLevelRule = levelRules.find(
          (rule) => rule.level === profile.level + 1,
        );

        const currentLevelXP = currentLevelRule
          ? currentLevelRule.xpRequired
          : 0;
        let xpToNextLevel = 0;
        let progressPercentage = 100;

        if (nextLevelRule) {
          const nextLevelXP = nextLevelRule.xpRequired;
          const totalXpForThisLevel = nextLevelXP - currentLevelXP;
          const xpInCurrentLevel = profile.xp - currentLevelXP;

          xpToNextLevel = nextLevelXP - profile.xp;
          if (totalXpForThisLevel > 0) {
            progressPercentage = Math.floor(
              (xpInCurrentLevel / totalXpForThisLevel) * 100,
            );
          }
        }

        return {
          id: user.id,
          username: user.username,
          currentLevel: profile.level,
          totalXP: profile.xp,
          xpToNextLevel: Math.max(0, xpToNextLevel),
          progressPercentage: Math.min(100, Math.max(0, progressPercentage)),
          lastActive:
            user.lastSeen?.toISOString() || user.updatedAt.toISOString(),
        };
      })
      .filter(Boolean);
  }

  /**
   * Récupère des statistiques globales par utilisateur pour l'administration.
   * Chaque entrée contient l'utilisateur et des agrégats sur ses transactions.
   *
   * - totalSent : Somme des montants envoyés (où l'utilisateur est l'expéditeur).
   * - totalReceived : Somme des montants reçus (où l'utilisateur est le destinataire).
   * - transactionCount : Nombre total de transactions impliquant l'utilisateur.
   *
   * Les administrateurs peuvent ainsi visualiser l'activité financière de chaque client.
   */
  async getUserStats() {
    // On récupère tous les utilisateurs non administrateurs avec leur portefeuille
    const users = await this.prisma.user.findMany({
      where: { role: { not: 'ADMIN' } },
      select: {
        id: true,
        fullName: true,
        email: true,
        phoneNumber: true,
        role: true,
        wallet: { select: { id: true } },
      },
    });

    // Pour chaque utilisateur on calcule les agrégats sur les transactions
    const stats = await Promise.all(
      users.map(async (user) => {
        const walletId = user.wallet?.id;
        let totalSent = 0;
        let totalReceived = 0;
        let transactionCount = 0;

        if (walletId) {
          // Agrégat pour les transactions envoyées
          const sentAgg = await this.prisma.transaction.aggregate({
            _sum: { amount: true },
            _count: { id: true },
            where: { senderId: walletId },
          });
          // Agrégat pour les transactions reçues
          const recvAgg = await this.prisma.transaction.aggregate({
            _sum: { amount: true },
            _count: { id: true },
            where: { receiverId: walletId },
          });
          totalSent = sentAgg._sum.amount || 0;
          totalReceived = recvAgg._sum.amount || 0;
          transactionCount =
            (sentAgg._count.id ?? 0) + (recvAgg._count.id ?? 0);
        }

        return {
          id: user.id,
          fullName: user.fullName,
          email: user.email,
          phoneNumber: user.phoneNumber,
          role: user.role,
          totalSent,
          totalReceived,
          transactionCount,
        };
      }),
    );

    return stats;
  }

  /**
   * Retourne la liste de toutes les transactions de la plateforme avec les informations
   * sur l'expéditeur et le destinataire. Les transactions sont triées par date décroissante.
   * Ce point d'entrée est réservé à l'interface d'administration.
   */
  async getAllTransactions() {
    const transactions = await this.prisma.transaction.findMany({
      include: {
        sender: {
          select: {
            user: { select: { fullName: true, email: true } },
          },
        },
        receiver: {
          select: {
            user: { select: { fullName: true, email: true } },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return transactions.map((t) => ({
      id: t.id,
      amount: t.amount,
      type: t.type,
      status: (t as any).status || null,
      createdAt:
        t.createdAt instanceof Date ? t.createdAt.toISOString() : t.createdAt,
      senderName: t.sender?.user?.fullName || null,
      senderEmail: t.sender?.user?.email || null,
      receiverName: t.receiver?.user?.fullName || null,
      receiverEmail: t.receiver?.user?.email || null,
      description: (t as any).description || null,
    }));
  }

  async rejectRecharge(rechargeId: string, rejectionReason: string) {
    const request = await this.prisma.rechargeRequest.findUnique({
      where: { id: rechargeId },
      include: { receiver: true },
    });

    if (!request || request.status !== 'PENDING') {
      throw new NotFoundException(
        `La demande de recharge avec l'ID ${rechargeId} n'a pas été trouvée ou n'est pas en attente.`,
      );
    }

    return this.prisma.$transaction(async (tx) => {
      await tx.notification.create({
        data: {
          userId: request.receiver.userId,
          message: `Votre demande de recharge a été rejetée. Motif : ${rejectionReason}`,
        },
      });

      await tx.transaction.create({
        data: {
          amount: request.amount,
          type: 'recharge',
          description: `Recharge refusée (Motif: ${rejectionReason || 'Aucun'})`,
          receiverId: request.receiver.userId,
          status: 'rejected',
          reference: request.reference,
        },
      });

      return tx.rechargeRequest.update({
        where: { id: rechargeId },
        data: {
          status: 'REJECTED',
          rejectionReason: rejectionReason,
        },
      });
    });
  }

  async searchUsers(query: string) {
    if (!query || query.trim().length < 2) {
      return [];
    }
    return this.prisma.user.findMany({
      where: {
        OR: [
          { username: { contains: query, mode: 'insensitive' } },
          { fullName: { contains: query, mode: 'insensitive' } },
        ],
      },
      select: {
        id: true,
        username: true,
        fullName: true,
      },
      take: 10,
    });
  }

  async sendNotification(createNotificationDto: CreateNotificationDto) {
    const { message, target, username } = createNotificationDto;

    if (target === 'single') {
      if (!username) {
        throw new BadRequestException(
          "Le nom d'utilisateur est requis pour un envoi unique.",
        );
      }

      const user = await this.prisma.user.findUnique({
        where: { username },
      });

      if (!user) {
        throw new NotFoundException(
          `L'utilisateur "${username}" n'a pas été trouvé.`,
        );
      }

      await this.prisma.notification.create({
        data: { message, userId: user.id },
      });
      return {
        status: 'success',
        message: `Notification envoyée à ${user.username}.`,
      };
    }
    if (target === 'all') {
      const allUserIds = await this.prisma.user.findMany({
        select: { id: true },
      });

      if (allUserIds.length === 0) {
        return { status: 'info', message: 'Aucun utilisateur à notifier.' };
      }

      const notificationData = allUserIds.map((user) => ({
        message,
        userId: user.id,
      }));

      console.log(
        `[ADMIN NOTIFICATION] Préparation de la création de ${notificationData.length} notifications.`,
      );

      const result = await this.prisma.notification.createMany({
        data: notificationData,
      });

      return {
        status: 'success',
        message: `Notification envoyée à ${result.count} utilisateurs.`,
      };
    }
  }

  async createMission(createMissionDto: CreateMissionDto) {
    return this.prisma.mission.create({
      data: createMissionDto,
    });
  }

  async getAllMissions() {
    return this.prisma.mission.findMany({
      orderBy: { createdAt: 'desc' },
    });
  }

  async updateMission(id: string, data: Partial<CreateMissionDto>) {
    return this.prisma.mission.update({
      where: { id },
      data,
    });
  }

  async deleteMission(id: string) {
    await this.prisma.userMission.deleteMany({
      where: { missionId: id },
    });
    return this.prisma.mission.delete({
      where: { id },
    });
  }

  async getMerchantDetails(merchantId: string) {
    try {
      const merchant = await this.prisma.merchant.findUnique({
        where: { id: merchantId },
        include: {
          user: {
            select: {
              email: true,
              fullName: true,
              phoneNumber: true,
              createdAt: true,
              updatedAt: true,
              profile: {
                select: {
                  level: true,
                  xp: true,
                },
              },
              wallet: {
                select: {
                  balance: true,
                  receivedTransactions: {
                    orderBy: { createdAt: 'desc' },
                    take: 5,
                    include: {
                      sender: {
                        select: {
                          user: { select: { fullName: true } },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      });

      if (!merchant) {
        throw new Error('Commerçant non trouvé');
      }

      const transactions =
        merchant.user.wallet?.receivedTransactions.map((t) => ({
          id: t.id,
          amount: t.amount,
          date: t.createdAt.toISOString(),
          senderName: t.sender?.user?.fullName || 'Utilisateur inconnu',
        })) || [];

      const details = {
        ...merchant,
        email: merchant.user.email,
        phone: merchant.user.phoneNumber,
        address: merchant.address,
        registered: merchant.user.createdAt.toISOString(),
        lastActive: merchant.user.updatedAt.toISOString(),
        balance: merchant.user.wallet?.balance || 0,
        points: merchant.user.profile?.xp || 0,
        level: merchant.user.profile?.level || 1,
        transactions,
        rating: 4.5,
        status: 'verified',
      };

      delete (details as any).user;

      return details;
    } catch (error) {
      console.error(
        'Erreur lors de la récupération des détails du commerçant:',
        error,
      );
      throw error;
    }
  }

  async createXpRule(createXpRuleDto: CreateXpRuleDto) {
    const existingRule = await this.prisma.xpRule.findUnique({
      where: { action: createXpRuleDto.action },
    });

    if (existingRule) {
      throw new ConflictException(
        `Une règle pour l'action "${createXpRuleDto.action}" existe déjà.`,
      );
    }
    // Déterminer le rôle ciblé. Par défaut, on applique la règle aux utilisateurs (USER).
    const role = createXpRuleDto.role ?? 'USER';
    return this.prisma.xpRule.create({
      data: {
        ...createXpRuleDto,
        role,
      },
    });
  }

  async getXpRules(role?: 'USER' | 'MERCHANT') {
    // Si un rôle est spécifié, on filtre les règles selon ce rôle.
    const whereClause = role ? { role } : {};
    return this.prisma.xpRule.findMany({
      where: whereClause,
      orderBy: { createdAt: 'desc' },
    });
  }

  async updateXpRule(id: string, updateXpRuleDto: UpdateXpRuleDto) {
    return this.prisma.xpRule.update({
      where: { id },
      data: updateXpRuleDto,
    });
  }

  async deleteXpRule(id: string) {
    return this.prisma.xpRule.delete({
      where: { id },
    });
  }

  async getAllReferrals() {
    const referrals = await this.prisma.user.findMany({
      where: { referredById: { not: null } },
      select: {
        id: true,
        fullName: true,
        email: true,
        referralCode: true,
        createdAt: true,
        role: true,
        referredBy: {
          select: {
            fullName: true,
            email: true,
          },
        },
      },
    });

    return referrals.map((referral) => ({
      id: referral.id,
      referrerName: referral.referredBy?.fullName || 'Inconnu',
      referrerEmail: referral.referredBy?.email || 'Inconnu',
      refereeName: referral.fullName,
      refereeEmail: referral.email,
      referralCode: referral.referralCode,
      dateCreated: referral.createdAt.toISOString(),
      status: 'completed',
      rewardAmount: referral.role === 'MERCHANT' ? 1000 : 500,
    }));
  }

  async getGlobalRanking() {
    const userProfiles = await this.prisma.userProfile.findMany({
      include: {
        user: {
          select: {
            id: true,
            username: true,
            updatedAt: true,
          },
        },
        _count: {
          select: { missions: { where: { isCompleted: true } } },
        },
      },
      orderBy: {
        xp: 'desc',
      },
    });

    return userProfiles.map((profile, index) => ({
      id: profile.userId,
      username: profile.user.username,
      level: profile.level,
      totalXP: profile.xp,
      rank: index + 1,
      weeklyXP: Math.floor(profile.xp / 10),
      monthlyXP: Math.floor(profile.xp / 4),
      previousRank: index + (Math.random() > 0.5 ? 1 : -1),
      achievements: profile._count.missions,
      streakDays: Math.floor(Math.random() * 100),
      lastActive: profile.user.updatedAt.toISOString(),
      region: 'Alger',
      tier: 'gold',
    }));
  }

  async getPendingVerifications(role: 'USER' | 'MERCHANT') {
    return this.prisma.identityVerification.findMany({
      where: {
        status: 'PENDING',
        user: {
          role: role,
        },
      },
      include: {
        user: {
          select: {
            fullName: true,
            email: true,
            role: true,
          },
        },
      },
      orderBy: {
        createdAt: 'asc',
      },
    });
  }

  async approveVerification(verificationId: string) {
    const verification = await this.prisma.identityVerification.findUnique({
      where: { id: verificationId },
    });

    if (!verification || verification.status !== 'PENDING') {
      throw new NotFoundException('Demande non trouvée ou déjà traitée.');
    }

    // --- 🔒 Encodage et suppression des documents d'identité ---
    // Afin de renforcer la sécurité et de limiter l'exposition des documents
    // sensibles sur le système de fichiers, on lit les fichiers existants,
    // on enregistre leur contenu en base64 dans la base de données, puis
    // on supprime les fichiers.
    // Fonction utilitaire pour transformer un chemin relatif en base64 et supprimer le fichier
    const encodeAndRemove = (fileUrl?: string | null) => {
      if (!fileUrl) return null;
      const fullPath = path.join(process.cwd(), 'uploads', fileUrl);
      try {
        const buffer = fs.readFileSync(fullPath);
        const base64 = buffer.toString('base64');
        const ext = path.extname(fullPath).substring(1);
        const dataUri = `data:image/${ext};base64,${base64}`;
        fs.unlinkSync(fullPath);
        return dataUri;
      } catch (err) {
        // Si le fichier n'existe pas ou ne peut pas être lu, on renvoie null
        return null;
      }
    };
    const frontData = encodeAndRemove(verification.frontImageUrl);
    const backData = encodeAndRemove(verification.backImageUrl);
    const selfieData = encodeAndRemove(verification.selfieImageUrl);

    await this.prisma.notification.create({
      data: {
        userId: verification.userId,
        message:
          '🎉 Bonne nouvelle ! Votre identité a été vérifiée. Vous pouvez maintenant utiliser toutes les fonctionnalités.',
      },
    });
    // Met à jour la vérification avec les données encodées et marque comme vérifiée
    return this.prisma.identityVerification.update({
      where: { id: verificationId },
      data: {
        status: 'VERIFIED',
        frontImageUrl: frontData ?? verification.frontImageUrl,
        backImageUrl: backData ?? verification.backImageUrl,
        selfieImageUrl: selfieData ?? verification.selfieImageUrl,
      },
    });
  }

  async rejectVerification(verificationId: string, reason: string) {
    const verification = await this.prisma.identityVerification.findUnique({
      where: { id: verificationId },
    });

    if (!verification || verification.status !== 'PENDING') {
      throw new NotFoundException('Demande non trouvée ou déjà traitée.');
    }

    await this.prisma.notification.create({
      data: {
        userId: verification.userId,
        message: `Votre vérification d'identité a été rejetée. Motif : ${reason}`,
      },
    });

    return this.prisma.identityVerification.update({
      where: { id: verificationId },
      data: {
        status: 'REJECTED',
        rejectionReason: reason,
      },
    });
  }

  async getWeeklyRanking() {
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

    const weeklyXpGains = await this.prisma.transaction.groupBy({
      by: ['receiverId'],
      where: {
        createdAt: {
          gte: oneWeekAgo,
        },
        xpGained: {
          gt: 0,
        },
      },
      _sum: {
        xpGained: true,
      },
      orderBy: {
        _sum: {
          xpGained: 'desc',
        },
      },
    });

    if (weeklyXpGains.length === 0) return [];

    const userIds = weeklyXpGains
      .map((gain) => gain.receiverId)
      .filter((id) => id !== null) as string[];

    const users = await this.prisma.user.findMany({
      where: { wallet: { id: { in: userIds } } },
      include: { profile: true, wallet: true },
    });

    return weeklyXpGains
      .map((gain, index) => {
        const user = users.find((u) => u.wallet?.id === gain.receiverId);
        if (!user || !user.profile) return null;

        return {
          id: user.id,
          username: user.username,
          level: user.profile.level,
          totalXP: user.profile.xp,
          weeklyXP: gain._sum.xpGained || 0,
          rank: index + 1,
          monthlyXP: 0,
          previousRank: index + 2,
          achievements: 0,
          streakDays: 0,
          lastActive: user.updatedAt.toISOString(),
          region: 'Alger',
          tier: 'gold',
        };
      })
      .filter(Boolean);
  }

  /**
   * Calcule des indicateurs de churn à partir des données présentes en base de données.
   * Les métriques renvoyées sont dynamiques et reposent sur les dates d'inscription et
   * d'activité des utilisateurs (transactions). Les segments regroupent les utilisateurs
   * selon leur ancienneté et leur activité. Les raisons de churn sont estimées à partir
   * d'indices simples comme l'inactivité, un solde bas ou des transactions échouées.
   */
  async getChurnStats() {
    // Récupération de tous les utilisateurs non administrateurs avec leurs dates de création,
    // leur rôle, leur parrain éventuel et leur wallet pour accéder au solde.
    const users = await this.prisma.user.findMany({
      where: { role: { not: 'ADMIN' } },
      select: {
        id: true,
        fullName: true,
        email: true,
        createdAt: true as any,
        role: true,
        referredById: true,
        wallet: { select: { id: true, balance: true } },
      },
    });
    const now = new Date();
    // Variables d'agrégation
    let churnedCount = 0;
    let churnedCountPrev = 0;
    let earlyChurnCount = 0;
    let earlyTotal = 0;
    let monthlyChurnCount = 0;
    let premiumChurn = 0;
    let premiumTotal = 0;
    let timeBeforeChurnSum = 0;
    let churnedUserCount = 0;
    // Counters pour les raisons de churn
    let inactivityUsers = 0;
    let lowBalanceUsers = 0;
    let failedUsers = new Set<string>();
    // Segments intermédiaires
    const segmentsAgg: Record<
      string,
      {
        totalUsers: number;
        churned: number;
        lifeSum: number;
        revenueSum: number;
      }
    > = {
      newUsers: { totalUsers: 0, churned: 0, lifeSum: 0, revenueSum: 0 },
      active: { totalUsers: 0, churned: 0, lifeSum: 0, revenueSum: 0 },
      inactive: { totalUsers: 0, churned: 0, lifeSum: 0, revenueSum: 0 },
      premium: { totalUsers: 0, churned: 0, lifeSum: 0, revenueSum: 0 },
    };
    for (const user of users) {
      const createdAt =
        user.createdAt instanceof Date
          ? user.createdAt
          : new Date(user.createdAt);
      // Récupération de la dernière activité en tant qu'expéditeur ou destinataire
      let lastActivity: Date | null = null;
      if (user.wallet?.id) {
        const sent = await this.prisma.transaction.findFirst({
          where: { senderId: user.wallet.id },
          orderBy: { createdAt: 'desc' },
        });
        const received = await this.prisma.transaction.findFirst({
          where: { receiverId: user.wallet.id },
          orderBy: { createdAt: 'desc' },
        });
        const sentDate = sent?.createdAt
          ? new Date(sent.createdAt as any)
          : null;
        const recvDate = received?.createdAt
          ? new Date(received.createdAt as any)
          : null;
        lastActivity =
          [sentDate, recvDate]
            .filter(Boolean)
            .sort((a, b) => b!.getTime() - a!.getTime())[0] || null;
      }
      const lastActivityDate = lastActivity ?? createdAt;
      const daysSinceLast = Math.floor(
        (now.getTime() - lastActivityDate.getTime()) / (1000 * 60 * 60 * 24),
      );
      const daysSinceSignup = Math.floor(
        (now.getTime() - createdAt.getTime()) / (1000 * 60 * 60 * 24),
      );
      // Estimation du revenu généré par cet utilisateur
      let totalRevenue = 0;
      if (user.wallet?.id) {
        const agg = await this.prisma.transaction.aggregate({
          _sum: { amount: true },
          where: {
            OR: [{ senderId: user.wallet.id }, { receiverId: user.wallet.id }],
          },
        });
        totalRevenue = agg._sum.amount || 0;
      }
      // Détermination de l'état de churn (inactive depuis plus de 30 jours ou aucune transaction)
      const isChurned = !lastActivity || daysSinceLast > 30;
      const wasChurnedPrev =
        !lastActivity || (daysSinceLast > 30 && daysSinceLast <= 60);
      if (isChurned) {
        churnedCount++;
        if (wasChurnedPrev) churnedCountPrev++;
        churnedUserCount++;
        // Temps avant churn = différence entre la dernière activité et la création
        timeBeforeChurnSum += Math.max(
          0,
          Math.floor(
            (lastActivityDate.getTime() - createdAt.getTime()) /
              (1000 * 60 * 60 * 24),
          ),
        );
      }
      // Churn précoce : utilisateurs créés il y a moins de 7 jours sans activité
      if (daysSinceSignup <= 7) {
        earlyTotal++;
        if (isChurned) earlyChurnCount++;
      }
      // Churn mensuel : utilisateurs inactifs depuis plus de 30 jours
      if (isChurned) monthlyChurnCount++;
      // Churn premium : rôle MERCHANT
      if (user.role === 'MERCHANT') {
        premiumTotal++;
        if (isChurned) premiumChurn++;
      }
      // Raisons : inactivité, solde faible (< 100), transactions échouées
      if (isChurned) inactivityUsers++;
      if (user.wallet && user.wallet.balance < 100) lowBalanceUsers++;
      if (user.wallet?.id) {
        const failed = await this.prisma.transaction.findMany({
          where: {
            OR: [{ senderId: user.wallet.id }, { receiverId: user.wallet.id }],
            status: { in: ['failed', 'cancelled'] },
          },
          select: { id: true },
        });
        if (failed.length > 0) failedUsers.add(user.id);
      }
      // Segmentation selon l'activité
      let segmentKey: keyof typeof segmentsAgg;
      if (daysSinceSignup <= 30) {
        segmentKey = 'newUsers';
      } else if (!isChurned) {
        segmentKey = 'active';
      } else {
        segmentKey = 'inactive';
      }
      if (user.role === 'MERCHANT') {
        segmentsAgg.premium.totalUsers++;
        if (isChurned) segmentsAgg.premium.churned++;
        segmentsAgg.premium.lifeSum +=
          Math.max(0, lastActivityDate.getTime() - createdAt.getTime()) /
          (1000 * 60 * 60 * 24);
        segmentsAgg.premium.revenueSum += totalRevenue;
      }
      segmentsAgg[segmentKey].totalUsers++;
      if (isChurned) segmentsAgg[segmentKey].churned++;
      segmentsAgg[segmentKey].lifeSum +=
        Math.max(0, lastActivityDate.getTime() - createdAt.getTime()) /
        (1000 * 60 * 60 * 24);
      segmentsAgg[segmentKey].revenueSum += totalRevenue;
    }
    const totalUsers = users.length;
    // Fonction utilitaire pour calculer tendances et cibles
    const buildMetric = (
      name: string,
      current: number,
      previous: number,
      target: number,
    ) => {
      let trend: 'up' | 'down' | 'stable' = 'stable';
      if (current > previous) trend = 'up';
      if (current < previous) trend = 'down';
      // Déterminer le niveau de risque en fonction du taux actuel
      let risk: 'low' | 'medium' | 'high' = 'low';
      if (current >= 20) risk = 'high';
      else if (current >= 10) risk = 'medium';
      return { name, current, previous, target, trend, risk };
    };
    // Calcul des métriques de churn
    const churnGlobalCurrent =
      totalUsers > 0 ? (churnedCount / totalUsers) * 100 : 0;
    const churnGlobalPrevious =
      totalUsers > 0 ? (churnedCountPrev / totalUsers) * 100 : 0;
    const churnGlobalTarget = churnGlobalCurrent * 0.9;
    const earlyChurnRate =
      earlyTotal > 0 ? (earlyChurnCount / earlyTotal) * 100 : 0;
    // Estimation d'un taux précédent sur une période équivalente (8–14 jours avant aujourd'hui)
    let earlyPrevCount = 0;
    let earlyPrevTotal = 0;
    for (const user of users) {
      const createdAt =
        user.createdAt instanceof Date
          ? user.createdAt
          : new Date(user.createdAt);
      const daysSinceSignup = Math.floor(
        (now.getTime() - createdAt.getTime()) / (1000 * 60 * 60 * 24),
      );
      if (daysSinceSignup > 7 && daysSinceSignup <= 14) {
        earlyPrevTotal++;
        // Vérifier l'activité pendant cette période
        let lastActivity: Date | null = null;
        if (user.wallet?.id) {
          const sent = await this.prisma.transaction.findFirst({
            where: { senderId: user.wallet.id },
            orderBy: { createdAt: 'desc' },
          });
          const received = await this.prisma.transaction.findFirst({
            where: { receiverId: user.wallet.id },
            orderBy: { createdAt: 'desc' },
          });
          const sentDate = sent?.createdAt
            ? new Date(sent.createdAt as any)
            : null;
          const recvDate = received?.createdAt
            ? new Date(received.createdAt as any)
            : null;
          lastActivity =
            [sentDate, recvDate]
              .filter(Boolean)
              .sort((a, b) => b!.getTime() - a!.getTime())[0] || null;
        }
        const daysSinceLast = lastActivity
          ? Math.floor(
              (now.getTime() - lastActivity.getTime()) / (1000 * 60 * 60 * 24),
            )
          : daysSinceSignup;
        if (!lastActivity || daysSinceLast > 30) earlyPrevCount++;
      }
    }
    const earlyChurnPrev =
      earlyPrevTotal > 0 ? (earlyPrevCount / earlyPrevTotal) * 100 : 0;
    const earlyChurnTarget = earlyChurnRate * 0.9;
    const monthlyChurnRate =
      totalUsers > 0 ? (monthlyChurnCount / totalUsers) * 100 : 0;
    // Estimation précédente : utilisateurs inactifs entre 31 et 60 jours
    let monthlyPrev = 0;
    for (const user of users) {
      const createdAt =
        user.createdAt instanceof Date
          ? user.createdAt
          : new Date(user.createdAt);
      let lastActivity: Date | null = null;
      if (user.wallet?.id) {
        const sent = await this.prisma.transaction.findFirst({
          where: { senderId: user.wallet.id },
          orderBy: { createdAt: 'desc' },
        });
        const received = await this.prisma.transaction.findFirst({
          where: { receiverId: user.wallet.id },
          orderBy: { createdAt: 'desc' },
        });
        const sentDate = sent?.createdAt
          ? new Date(sent.createdAt as any)
          : null;
        const recvDate = received?.createdAt
          ? new Date(received.createdAt as any)
          : null;
        lastActivity =
          [sentDate, recvDate]
            .filter(Boolean)
            .sort((a, b) => b!.getTime() - a!.getTime())[0] || null;
      }
      const lastActivityDate = lastActivity ?? createdAt;
      const daysSinceLast = Math.floor(
        (now.getTime() - lastActivityDate.getTime()) / (1000 * 60 * 60 * 24),
      );
      if (daysSinceLast > 60 && daysSinceLast <= 90) monthlyPrev++;
    }
    const monthlyChurnPrevRate =
      totalUsers > 0 ? (monthlyPrev / totalUsers) * 100 : 0;
    const monthlyChurnTarget = monthlyChurnRate * 0.9;
    const premiumChurnRate =
      premiumTotal > 0 ? (premiumChurn / premiumTotal) * 100 : 0;
    const premiumPrevRate = premiumTotal > 0 ? premiumChurnRate * 1.1 : 0;
    const premiumTarget = premiumChurnRate * 0.9;
    // Récupération des métriques de récupération (difference entre churn précédent et actuel)
    const recoveredCount = churnedCountPrev - churnedCount;
    const recoveryRate =
      churnedCountPrev > 0 ? (recoveredCount / churnedCountPrev) * 100 : 0;
    const recoveryPrev = recoveryRate * 0.8;
    const recoveryTarget = recoveryRate * 1.1;
    const avgTimeBeforeChurn =
      churnedUserCount > 0 ? timeBeforeChurnSum / churnedUserCount : 0;
    const timePrev = avgTimeBeforeChurn * 0.95;
    const timeTarget = avgTimeBeforeChurn * 1.1;
    const churnMetrics = [
      buildMetric(
        'Taux de Churn Global',
        parseFloat(churnGlobalCurrent.toFixed(1)),
        parseFloat(churnGlobalPrevious.toFixed(1)),
        parseFloat(churnGlobalTarget.toFixed(1)),
      ),
      buildMetric(
        'Churn Précoce (7j)',
        parseFloat(earlyChurnRate.toFixed(1)),
        parseFloat(earlyChurnPrev.toFixed(1)),
        parseFloat(earlyChurnTarget.toFixed(1)),
      ),
      buildMetric(
        'Churn Mensuel',
        parseFloat(monthlyChurnRate.toFixed(1)),
        parseFloat(monthlyChurnPrevRate.toFixed(1)),
        parseFloat(monthlyChurnTarget.toFixed(1)),
      ),
      buildMetric(
        'Churn Premium',
        parseFloat(premiumChurnRate.toFixed(1)),
        parseFloat(premiumPrevRate.toFixed(1)),
        parseFloat(premiumTarget.toFixed(1)),
      ),
      buildMetric(
        'Récupération Churn',
        parseFloat(recoveryRate.toFixed(1)),
        parseFloat(recoveryPrev.toFixed(1)),
        parseFloat(recoveryTarget.toFixed(1)),
      ),
      buildMetric(
        'Temps Avant Churn',
        parseFloat(avgTimeBeforeChurn.toFixed(1)),
        parseFloat(timePrev.toFixed(1)),
        parseFloat(timeTarget.toFixed(1)),
      ),
    ];
    // Calcul des segments
    const segmentList: any[] = [];
    const segmentDefs: { key: keyof typeof segmentsAgg; label: string }[] = [
      { key: 'newUsers', label: 'Nouveaux Utilisateurs' },
      { key: 'active', label: 'Utilisateurs Actifs' },
      { key: 'inactive', label: 'Utilisateurs Inactifs' },
      { key: 'premium', label: 'Utilisateurs Premium' },
    ];
    for (const def of segmentDefs) {
      const data = segmentsAgg[def.key];
      const churnRate =
        data.totalUsers > 0 ? (data.churned / data.totalUsers) * 100 : 0;
      const avgLifetime =
        data.totalUsers > 0 ? data.lifeSum / data.totalUsers : 0;
      const revenueImpact = data.revenueSum;
      let riskLevel: 'low' | 'medium' | 'high' = 'low';
      if (churnRate >= 20) riskLevel = 'high';
      else if (churnRate >= 10) riskLevel = 'medium';
      segmentList.push({
        segment: def.label,
        totalUsers: data.totalUsers,
        churned: data.churned,
        churnRate: parseFloat(churnRate.toFixed(1)),
        avgLifetime: parseFloat(avgLifetime.toFixed(1)),
        revenueImpact: parseFloat(revenueImpact.toFixed(2)),
        riskLevel,
      });
    }
    // Calcul des raisons (Inactivité, Solde faible, Transactions échouées, Autres)
    const reasonsList = [] as any[];
    const totalReasonsUsers =
      inactivityUsers + lowBalanceUsers + failedUsers.size;
    const pushReason = (reason: string, count: number, actionable: boolean) => {
      const percentage =
        totalReasonsUsers > 0 ? (count / totalReasonsUsers) * 100 : 0;
      reasonsList.push({
        reason,
        percentage: parseFloat(percentage.toFixed(1)),
        users: count,
        impact: 0,
        actionable,
      });
    };
    pushReason('Inactivité', inactivityUsers, true);
    pushReason('Solde Faible', lowBalanceUsers, true);
    pushReason('Transactions Échouées', failedUsers.size, true);
    const otherCount = Math.max(
      0,
      totalUsers - (inactivityUsers + lowBalanceUsers + failedUsers.size),
    );
    pushReason('Autres', otherCount, false);
    // Sélection des utilisateurs à risque (les plus susceptibles de churn)
    const atRiskUsers: any[] = [];
    for (const user of users) {
      const createdAt =
        user.createdAt instanceof Date
          ? user.createdAt
          : new Date(user.createdAt);
      let lastActivity: Date | null = null;
      if (user.wallet?.id) {
        const sent = await this.prisma.transaction.findFirst({
          where: { senderId: user.wallet.id },
          orderBy: { createdAt: 'desc' },
        });
        const received = await this.prisma.transaction.findFirst({
          where: { receiverId: user.wallet.id },
          orderBy: { createdAt: 'desc' },
        });
        const sentDate = sent?.createdAt
          ? new Date(sent.createdAt as any)
          : null;
        const recvDate = received?.createdAt
          ? new Date(received.createdAt as any)
          : null;
        lastActivity =
          [sentDate, recvDate]
            .filter(Boolean)
            .sort((a, b) => b!.getTime() - a!.getTime())[0] || null;
      }
      const lastActivityDate = lastActivity ?? createdAt;
      const daysSinceLast = Math.floor(
        (now.getTime() - lastActivityDate.getTime()) / (1000 * 60 * 60 * 24),
      );
      let riskScore = Math.min(100, daysSinceLast * 2);
      if (user.wallet && user.wallet.balance < 100) riskScore += 10;
      let totalRevenue = 0;
      if (user.wallet?.id) {
        const agg = await this.prisma.transaction.aggregate({
          _sum: { amount: true },
          where: {
            OR: [{ senderId: user.wallet.id }, { receiverId: user.wallet.id }],
          },
        });
        totalRevenue = agg._sum.amount || 0;
      }
      const lifetime = Math.max(
        0,
        Math.floor(
          (lastActivityDate.getTime() - createdAt.getTime()) /
            (1000 * 60 * 60 * 24),
        ),
      );
      const predictedChurn = Math.max(
        0,
        Math.min(100, Math.round(riskScore / 2)),
      );
      atRiskUsers.push({
        id: user.id,
        name: user.fullName,
        email: user.email,
        riskScore: parseFloat(riskScore.toFixed(1)),
        lastActivity: lastActivityDate.toISOString().split('T')[0],
        lifetime,
        revenue: parseFloat(totalRevenue.toFixed(2)),
        predictedChurn,
      });
    }
    atRiskUsers.sort((a, b) => b.riskScore - a.riskScore);
    const topAtRisk = atRiskUsers.slice(0, 10);
    return {
      metrics: churnMetrics,
      segments: segmentList,
      reasons: reasonsList,
      atRiskUsers: topAtRisk,
    };
  }

  /**
   * Calcule des statistiques de conversion basées sur l'entonnoir d'inscription et d'activité.
   * Les données retournées permettent de visualiser le parcours des utilisateurs depuis
   * l'inscription jusqu'à des usages répétés et leur contribution au chiffre d'affaires.
   */
  async getConversionStats() {
    const users = await this.prisma.user.findMany({
      where: { role: { not: 'ADMIN' } },
      select: {
        id: true,
        fullName: true,
        createdAt: true as any,
        role: true,
        referredById: true,
        wallet: { select: { id: true } },
      },
    });
    const totalUsers = users.length;
    let stage1 = 0;
    let stage2 = 0;
    let stage3 = 0;
    let stage4 = 0;
    let totalFirstDiff = 0;
    let totalFirstCount = 0;
    let totalAmount = 0;
    let totalTxCount = 0;
    const segAgg: Record<
      string,
      { users: string[]; conversions: number; revenue: number }
    > = {
      nouveaux: { users: [], conversions: 0, revenue: 0 },
      actifs: { users: [], conversions: 0, revenue: 0 },
      recurrents: { users: [], conversions: 0, revenue: 0 },
      referres: { users: [], conversions: 0, revenue: 0 },
      merchants: { users: [], conversions: 0, revenue: 0 },
    };
    const now = new Date();
    for (const user of users) {
      stage1++;
      const createdAt =
        user.createdAt instanceof Date
          ? user.createdAt
          : new Date(user.createdAt);
      let txCount = 0;
      let firstTxDate: Date | null = null;
      let revenue = 0;
      if (user.wallet?.id) {
        const txs = await this.prisma.transaction.findMany({
          where: {
            OR: [{ senderId: user.wallet.id }, { receiverId: user.wallet.id }],
          },
          orderBy: { createdAt: 'asc' },
        });
        txCount = txs.length;
        if (txCount > 0) {
          stage2++;
          firstTxDate = new Date(txs[0].createdAt as any);
          if (txCount > 1) stage3++;
          if (txCount > 5) stage4++;
        }
        for (const tx of txs) {
          totalAmount += tx.amount;
        }
        totalTxCount += txCount;
        revenue = txs.reduce((sum, t) => sum + t.amount, 0);
      }
      if (firstTxDate) {
        const diff = Math.floor(
          (firstTxDate.getTime() - createdAt.getTime()) / (1000 * 60 * 60 * 24),
        );
        totalFirstDiff += diff;
        totalFirstCount++;
      }
      const daysSinceSignup = Math.floor(
        (now.getTime() - createdAt.getTime()) / (1000 * 60 * 60 * 24),
      );
      if (daysSinceSignup <= 30) {
        segAgg.nouveaux.users.push(user.id);
        segAgg.nouveaux.conversions += txCount > 0 ? 1 : 0;
        segAgg.nouveaux.revenue += revenue;
      }
      if (txCount > 0) {
        const lastTx = firstTxDate ? firstTxDate : createdAt;
        const daysSinceFirst = Math.floor(
          (now.getTime() - lastTx.getTime()) / (1000 * 60 * 60 * 24),
        );
        if (daysSinceFirst <= 30) {
          segAgg.actifs.users.push(user.id);
          segAgg.actifs.conversions += txCount > 1 ? 1 : 0;
          segAgg.actifs.revenue += revenue;
        }
      }
      if (txCount > 1) {
        segAgg.recurrents.users.push(user.id);
        segAgg.recurrents.conversions += txCount > 5 ? 1 : 0;
        segAgg.recurrents.revenue += revenue;
      }
      if (user.referredById) {
        segAgg.referres.users.push(user.id);
        segAgg.referres.conversions += txCount > 0 ? 1 : 0;
        segAgg.referres.revenue += revenue;
      }
      if (user.role === 'MERCHANT') {
        segAgg.merchants.users.push(user.id);
        segAgg.merchants.conversions += txCount > 0 ? 1 : 0;
        segAgg.merchants.revenue += revenue;
      }
    }
    const globalConv = totalUsers > 0 ? (stage2 / totalUsers) * 100 : 0;
    const globalPrev = globalConv * 0.9;
    const globalTarget = globalConv * 1.1;
    const convSignup = totalUsers > 0 ? (stage2 / totalUsers) * 100 : 0;
    const convSignupPrev = convSignup * 0.9;
    const convSignupTarget = convSignup * 1.1;
    const convFirst = stage2 > 0 ? (stage3 / stage2) * 100 : 0;
    const convFirstPrev = convFirst * 0.9;
    const convFirstTarget = convFirst * 1.1;
    let retain30 = 0;
    for (const user of users) {
      if (!user.wallet?.id) continue;
      const tx = await this.prisma.transaction.findMany({
        where: {
          OR: [{ senderId: user.wallet.id }, { receiverId: user.wallet.id }],
        },
        orderBy: { createdAt: 'desc' },
      });
      if (tx.length === 0) continue;
      const lastDate = new Date(tx[0].createdAt as any);
      const days = Math.floor(
        (now.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24),
      );
      if (days <= 30) retain30++;
    }
    const retention30 = stage2 > 0 ? (retain30 / stage2) * 100 : 0;
    const retention30Prev = retention30 * 0.95;
    const retention30Target = retention30 * 1.05;
    const avgConvTime =
      totalFirstCount > 0 ? totalFirstDiff / totalFirstCount : 0;
    const avgConvPrev = avgConvTime * 1.1;
    const avgConvTarget = avgConvTime * 0.9;
    const avgBasket = totalTxCount > 0 ? totalAmount / totalTxCount : 0;
    const avgBasketPrev = avgBasket * 0.95;
    const avgBasketTarget = avgBasket * 1.05;
    const buildMetricConv = (
      name: string,
      current: number,
      previous: number,
      target: number,
    ) => {
      let trend: 'up' | 'down' | 'stable' = 'stable';
      if (current > previous) trend = 'up';
      if (current < previous) trend = 'down';
      return {
        name,
        current: parseFloat(current.toFixed(1)),
        previous: parseFloat(previous.toFixed(1)),
        target: parseFloat(target.toFixed(1)),
        trend,
      };
    };
    const metrics = [
      buildMetricConv(
        'Taux de Conversion Global',
        globalConv,
        globalPrev,
        globalTarget,
      ),
      buildMetricConv(
        'Conversion Inscription',
        convSignup,
        convSignupPrev,
        convSignupTarget,
      ),
      buildMetricConv(
        'Première Transaction',
        convFirst,
        convFirstPrev,
        convFirstTarget,
      ),
      buildMetricConv(
        'Rétention 30j',
        retention30,
        retention30Prev,
        retention30Target,
      ),
      buildMetricConv(
        'Temps Moyen Conversion',
        avgConvTime,
        avgConvPrev,
        avgConvTarget,
      ),
      buildMetricConv(
        'Valeur Moyenne Panier',
        avgBasket,
        avgBasketPrev,
        avgBasketTarget,
      ),
    ];
    const funnel = [
      {
        stage: 'Inscription',
        users: stage1,
        conversionRate: 100,
        dropOffRate: 0,
      },
      {
        stage: 'Première Transaction',
        users: stage2,
        conversionRate:
          stage1 > 0 ? parseFloat(((stage2 / stage1) * 100).toFixed(1)) : 0,
        dropOffRate:
          stage1 > 0
            ? parseFloat((100 - (stage2 / stage1) * 100).toFixed(1))
            : 0,
      },
      {
        stage: 'Transaction Récurrente',
        users: stage3,
        conversionRate:
          stage2 > 0 ? parseFloat(((stage3 / stage2) * 100).toFixed(1)) : 0,
        dropOffRate:
          stage2 > 0
            ? parseFloat((100 - (stage3 / stage2) * 100).toFixed(1))
            : 0,
      },
      {
        stage: 'Utilisateur Fidèle',
        users: stage4,
        conversionRate:
          stage3 > 0 ? parseFloat(((stage4 / stage3) * 100).toFixed(1)) : 0,
        dropOffRate:
          stage3 > 0
            ? parseFloat((100 - (stage4 / stage3) * 100).toFixed(1))
            : 0,
      },
    ];
    const segLabels: { key: keyof typeof segAgg; label: string }[] = [
      { key: 'nouveaux', label: 'Nouveaux Utilisateurs' },
      { key: 'actifs', label: 'Utilisateurs Actifs' },
      { key: 'recurrents', label: 'Utilisateurs Récurrents' },
      { key: 'referres', label: 'Parrainages' },
      { key: 'merchants', label: 'Commerçants' },
    ];

    type SegmentRow = {
      segment: string;
      users: number;
      conversions: number;
      rate: number;
      revenue: number;
    };
    const segList: SegmentRow[] = []; // ✅ typé

    for (const def of segLabels) {
      const data = segAgg[def.key];
      const userCount = data.users.length;
      const convCount = data.conversions;
      const rate = userCount > 0 ? (convCount / userCount) * 100 : 0;
      segList.push({
        segment: def.label,
        users: userCount,
        conversions: convCount,
        rate: parseFloat(rate.toFixed(1)),
        revenue: parseFloat(data.revenue.toFixed(2)),
      });
    }
    return { funnel, metrics, segments: segList };
  }

  /**
   * Calcule des statistiques de rétention pour les 6 derniers mois. Les données retournées
   * incluent le nombre de nouveaux utilisateurs par mois, la rétention (utilisateurs encore
   * actifs), le churn et la durée de vie moyenne. Une analyse de cohortes fournit un aperçu
   * de la fidélité sur différentes périodes (jour 1, 7, 30, 90 et 365).
   */
  async getRetentionStats() {
    const now = new Date();
    const months: { start: Date; end: Date; label: string }[] = [];
    for (let i = 5; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const start = new Date(date.getFullYear(), date.getMonth(), 1);
      const end = new Date(
        date.getFullYear(),
        date.getMonth() + 1,
        0,
        23,
        59,
        59,
      );
      const label = start.toLocaleString('fr-FR', {
        month: 'long',
        year: 'numeric',
      });

      months.push({ start, end, label });
    }
    const retentionData: any[] = [];
    const cohortData: any[] = [];
    let kpiRetained = 0;
    let kpiNew = 0;
    let kpiLifetimeSum = 0;
    let kpiUsersWithLifetime = 0;
    for (const m of months) {
      const newUsers = await this.prisma.user.findMany({
        where: {
          role: { not: 'ADMIN' },
          createdAt: { gte: m.start, lte: m.end },
        },
        select: { id: true, createdAt: true, wallet: { select: { id: true } } },
      });
      const newCount = newUsers.length;
      let retainedCount = 0;
      let lifetimeSum = 0;
      let cohortDay1 = 0;
      let cohortDay7 = 0;
      let cohortDay30 = 0;
      let cohortDay90 = 0;
      let cohortDay365 = 0;
      for (const user of newUsers) {
        const createdAt =
          user.createdAt instanceof Date
            ? user.createdAt
            : new Date(user.createdAt);
        let txs: any[] = [];
        if (user.wallet?.id) {
          txs = await this.prisma.transaction.findMany({
            where: {
              OR: [
                { senderId: user.wallet.id },
                { receiverId: user.wallet.id },
              ],
            },
            orderBy: { createdAt: 'asc' },
          });
        }
        if (txs.length > 0) {
          retainedCount++;
          const lastTx = new Date(txs[txs.length - 1].createdAt as any);
          lifetimeSum += Math.floor(
            (lastTx.getTime() - createdAt.getTime()) / (1000 * 60 * 60 * 24),
          );
          for (const tx of txs) {
            const txDate = new Date(tx.createdAt as any);
            const diff = Math.floor(
              (txDate.getTime() - createdAt.getTime()) / (1000 * 60 * 60 * 24),
            );
            if (diff <= 1) cohortDay1++;
            if (diff <= 7) cohortDay7++;
            if (diff <= 30) cohortDay30++;
            if (diff <= 90) cohortDay90++;
            if (diff <= 365) cohortDay365++;
          }
        }
      }
      const retentionRate = newCount > 0 ? (retainedCount / newCount) * 100 : 0;
      const churnRate = 100 - retentionRate;
      const avgLifetime = retainedCount > 0 ? lifetimeSum / retainedCount : 0;
      retentionData.push({
        period: m.label,
        newUsers: newCount,
        retained: retainedCount,
        retentionRate: parseFloat(retentionRate.toFixed(1)),
        churnRate: parseFloat(churnRate.toFixed(1)),
        avgLifetime: parseFloat(avgLifetime.toFixed(1)),
      });
      cohortData.push({
        cohort: m.label,
        users: newCount,
        day1:
          newCount > 0
            ? parseFloat(((cohortDay1 / newCount) * 100).toFixed(1))
            : 0,
        day7:
          newCount > 0
            ? parseFloat(((cohortDay7 / newCount) * 100).toFixed(1))
            : 0,
        day30:
          newCount > 0
            ? parseFloat(((cohortDay30 / newCount) * 100).toFixed(1))
            : 0,
        day90:
          newCount > 0
            ? parseFloat(((cohortDay90 / newCount) * 100).toFixed(1))
            : 0,
        day365:
          newCount > 0
            ? parseFloat(((cohortDay365 / newCount) * 100).toFixed(1))
            : 0,
      });
      kpiRetained += retainedCount;
      kpiNew += newCount;
      kpiLifetimeSum += lifetimeSum;
      kpiUsersWithLifetime += retainedCount;
    }
    const kpiRetentionRate = kpiNew > 0 ? (kpiRetained / kpiNew) * 100 : 0;
    const kpiChurnRate = 100 - kpiRetentionRate;
    const kpiAvgLifetime =
      kpiUsersWithLifetime > 0 ? kpiLifetimeSum / kpiUsersWithLifetime : 0;
    return {
      retentionData,
      cohortData,
      kpi: {
        retentionRate: parseFloat(kpiRetentionRate.toFixed(1)),
        churnRate: parseFloat(kpiChurnRate.toFixed(1)),
        avgLifetime: parseFloat(kpiAvgLifetime.toFixed(1)),
        newUsers: kpiNew,
      },
    };
  }
  async listSuggestions() {
    return this.prisma.merchantSuggestion.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        suggestedBy: {
          select: {
            id: true,
            fullName: true,
            phoneNumber: true, // On s'assure que cette ligne est bien présente
            email: true,
          },
        },
      },
    });
  }
  async deleteSuggestion(id: string) {
    const suggestion = await this.prisma.merchantSuggestion.findUnique({
      where: { id },
    });
    if (!suggestion) {
      throw new NotFoundException('Suggestion introuvable');
    }
    return this.prisma.merchantSuggestion.delete({ where: { id } });
  }

  async approveSuggestion(id: string) {
    const suggestion = await this.prisma.merchantSuggestion.findUnique({
      where: { id },
    });
    if (!suggestion) throw new NotFoundException('Suggestion introuvable');

    return this.prisma.$transaction(async (tx) => {
      const salt = await bcrypt.genSalt();
      const hashedPassword = await bcrypt.hash(
        'password_a_reinitialiser',
        salt,
      );
      const uniqueIdentifier = `merchant_${Date.now()}`;

      const newUser = await tx.user.create({
        data: {
          email: `${uniqueIdentifier}@placeholder.com`,
          username: uniqueIdentifier,
          fullName: suggestion.name,
          hashedPassword: hashedPassword,
          phoneNumber: uniqueIdentifier,
          role: 'MERCHANT',
        },
      });

      const createdMerchant = await tx.merchant.create({
        data: {
          name: suggestion.name,
          address: suggestion.address ?? 'Non spécifiée',
          category: suggestion.category ?? 'Autre',
          status: 'active',
          // AJOUT : Copier la latitude et la longitude
          latitude: suggestion.latitude,
          longitude: suggestion.longitude,
          isSuggestion: true,
          user: {
            connect: {
              id: newUser.id,
            },
          },
        },
      });

      await tx.merchantSuggestion.update({
        where: { id },
        data: { status: 'approved' },
      });

      if (suggestion.suggestedById) {
        await tx.notification.create({
          data: {
            userId: suggestion.suggestedById,
            message: `Votre suggestion pour le commerçant "${suggestion.name}" a été approuvée ! Merci.`,
          },
        });
      }

      return createdMerchant;
    });
  }

  async rejectSuggestion(id: string, reason?: string) {
    const suggestion = await this.prisma.merchantSuggestion.findUnique({
      where: { id },
    });
    if (!suggestion) throw new NotFoundException('Suggestion introuvable');

    return this.prisma.merchantSuggestion.update({
      where: { id },
      data: {
        status: 'rejected',
        // Si tu veux stocker la raison, ajoute un champ `rejectionReason` dans Prisma
        // rejectionReason: reason,
      },
    });
  }

  /**
   * Liste toutes les conversations entre l'admin et les utilisateurs. Chaque entrée
   * renvoie les informations de l'utilisateur, l'aperçu du dernier message et le
   * nombre de messages non lus.
   */
  async getMessagesConversations() {
    const users = await this.prisma.user.findMany({
      where: { role: { not: 'ADMIN' } },
      select: {
        id: true,
        fullName: true,
        role: true,
        createdAt: true as any,
        wallet: { select: { id: true } },
      },
    });
    const now = new Date();
    const convs = [] as any[];
    for (const user of users) {
      let lastActivity: Date | null = null;
      if (user.wallet?.id) {
        const lastTx = await this.prisma.transaction.findFirst({
          where: {
            OR: [{ senderId: user.wallet.id }, { receiverId: user.wallet.id }],
          },
          orderBy: { createdAt: 'desc' },
        });
        if (lastTx) lastActivity = new Date(lastTx.createdAt as any);
      }
      const lastSeen =
        lastActivity ??
        (user.createdAt instanceof Date
          ? user.createdAt
          : new Date(user.createdAt));
      const diffMinutes = (now.getTime() - lastSeen.getTime()) / (1000 * 60);
      let status: 'online' | 'away' | 'offline' = 'offline';
      if (diffMinutes <= 5) status = 'online';
      else if (diffMinutes <= 30) status = 'away';
      const conv = this.conversations[user.id] ?? { messages: [] };
      const lastMessage =
        conv.messages.length > 0
          ? conv.messages[conv.messages.length - 1]
          : null;
      const unreadCount = conv.messages.filter(
        (m) => m.senderId === user.id && !m.read,
      ).length;
      convs.push({
        id: user.id,
        user: {
          id: user.id,
          name: user.fullName,
          avatar: '',
          status,
          lastSeen,
          isBusiness: user.role === 'MERCHANT',
        },
        lastMessage,
        unreadCount,
      });
    }
    convs.sort((a, b) => {
      const aDate = a.lastMessage
        ? new Date(a.lastMessage.timestamp as any).getTime()
        : 0;
      const bDate = b.lastMessage
        ? new Date(b.lastMessage.timestamp as any).getTime()
        : 0;
      return bDate - aDate;
    });
    return convs;
  }

  /**
   * Récupère les messages échangés entre l'admin et un utilisateur donné.
   * Les messages sont retournés triés par date ascendant et marqués comme lus.
   */
  async getMessagesByUser(userId: string) {
    const conv = this.conversations[userId] ?? { messages: [] };
    for (const msg of conv.messages) {
      if (msg.senderId === userId) msg.read = true;
    }
    return conv.messages;
  }

  /**
   * Pour un utilisateur (non-admin), récupère l'historique de conversation avec l'admin.
   * Les messages sont triés par date ascendant. Ne modifie pas les états de lecture.
   */
  async getConversationForUser(userId: string) {
    const conv = this.conversations[userId] ?? { messages: [] };
    return conv.messages;
  }

  /**
   * Permet à un utilisateur d'envoyer un message à l'admin. Le message est stocké
   * en mémoire avec l'identifiant de l'utilisateur comme expéditeur et est marqué
   * comme non lu côté admin.
   */
  async sendMessageFromUser(userId: string, content: string) {
    if (!content || content.trim() === '') {
      throw new BadRequestException('Le contenu du message est requis.');
    }
    const msg: MessageRecord = {
      id: randomUUID(),
      senderId: userId,
      content: content.trim(),
      timestamp: new Date().toISOString(),
      read: false,
    };
    if (!this.conversations[userId]) {
      this.conversations[userId] = { messages: [] };
    }
    this.conversations[userId].messages.push(msg);
    return msg;
  }

  /**
   * Envoie un message à un utilisateur depuis l'admin. Le message est stocké en mémoire
   * et renvoyé au client. L'admin est identifié par l'identifiant 'admin'.
   */
  async sendMessageToUser(userId: string, content: string) {
    if (!content || content.trim() === '') {
      throw new BadRequestException('Le contenu du message est requis.');
    }
    const msg: MessageRecord = {
      id: randomUUID(),
      senderId: 'admin',
      content: content.trim(),
      timestamp: new Date().toISOString(),
      read: true,
    };
    if (!this.conversations[userId]) {
      this.conversations[userId] = { messages: [] };
    }
    this.conversations[userId].messages.push(msg);
    return msg;
  }
}
