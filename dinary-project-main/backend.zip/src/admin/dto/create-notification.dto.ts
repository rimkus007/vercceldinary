import { IsString, IsNotEmpty, IsOptional, IsIn } from 'class-validator';

export class CreateNotificationDto {
  @IsString()
  @IsNotEmpty()
  message: string;

  @IsIn(['all', 'single'])
  target: 'all' | 'single';

  @IsOptional()
  @IsString()
  username?: string; // <-- Changé de userId à username
}
