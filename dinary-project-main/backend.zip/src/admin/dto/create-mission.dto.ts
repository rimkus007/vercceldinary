// src/admin/dto/create-mission.dto.ts
import {
  IsString,
  IsNotEmpty,
  IsInt,
  IsOptional,
  IsEnum,
} from 'class-validator';
import { MissionStatus } from '@prisma/client';

export class CreateMissionDto {
  @IsString()
  @IsNotEmpty()
  title: string;

  @IsString()
  @IsNotEmpty()
  description: string;

  @IsInt()
  xpReward: number;

  @IsInt()
  goal: number;

  @IsString()
  @IsNotEmpty()
  type: string;

  @IsString()
  @IsOptional()
  icon?: string;

  @IsEnum(MissionStatus)
  @IsOptional()
  status?: MissionStatus;
}
