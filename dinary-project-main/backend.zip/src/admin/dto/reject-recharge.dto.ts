export class RejectRechargeDto {
  reason: string;
}
