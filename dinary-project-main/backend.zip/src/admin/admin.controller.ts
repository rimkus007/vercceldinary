import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
  BadRequestException,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { AdminGuard } from '../auth/guards/AdminGuard';
import { AdminService } from './admin.service';
import { RejectVerificationDto } from './dto/reject-verification.dto';
// Import all DTOs
import { ManualRechargeDto } from './dto/manual-recharge.dto';
import { RejectRechargeDto } from './dto/reject-recharge.dto';
import { CreateNotificationDto } from './dto/create-notification.dto';
import { CreateMissionDto } from './dto/create-mission.dto';
import { CreateCommissionRuleDto } from './dto/create-commission-rule.dto';
import { UpdateCommissionRuleDto } from './dto/update-commission-rule.dto';
import { CreateXpRuleDto } from './dto/create-xp-rule.dto';
import { UpdateXpRuleDto } from './dto/update-xp-rule.dto';
import { CreateLevelRuleDto } from './dto/create-level-rule.dto';
import { UpdateLevelRuleDto } from './dto/update-level-rule.dto';

class RejectSuggestionDto {
  reason?: string;
}
@Controller('admin')
@UseGuards(AuthGuard('jwt'), AdminGuard)
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  // --- 📊 DASHBOARD & STATS ---
  @Get('stats')
  getDashboardStats() {
    return this.adminService.getDashboardStats();
  }

  @Get('referral-stats')
  getReferralStats() {
    return this.adminService.getReferralStats();
  }

  // --- 👥 USER & MERCHANT MANAGEMENT ---
  @Get('users')
  getAllUsers() {
    return this.adminService.getAllUsers();
  }

  @Get('users/search')
  searchUsers(@Query('q') query: string) {
    return this.adminService.searchUsers(query);
  }

  @Get('merchants')
  getAllMerchants() {
    return this.adminService.getAllMerchants();
  }

  @Get('merchants/:id')
  getMerchantDetails(@Param('id') id: string) {
    return this.adminService.getMerchantDetails(id);
  }

  @Get('referrals')
  getAllReferrals() {
    return this.adminService.getAllReferrals();
  }

  // --- 💰 RECHARGE MANAGEMENT ---
  @Post('recharges/manual')
  createManualRecharge(@Body() body: ManualRechargeDto) {
    return this.adminService.createManualRecharge(body);
  }

  @Get('recharges/pending')
  getPendingRecharges() {
    return this.adminService.getPendingRecharges();
  }

  @Patch('recharges/:id/approve')
  approveRecharge(@Param('id') id: string) {
    return this.adminService.approveRecharge(id);
  }

  @Patch('recharges/:id/reject')
  rejectRecharge(
    @Param('id') id: string,
    @Body() rejectDto: RejectRechargeDto,
  ) {
    const rejectionReason = rejectDto.reason || 'Aucun motif fourni.';
    return this.adminService.rejectRecharge(id, rejectionReason);
  }

  // --- 🔔 NOTIFICATIONS ---
  @Post('notifications/send')
  sendNotification(@Body() createNotificationDto: CreateNotificationDto) {
    return this.adminService.sendNotification(createNotificationDto);
  }

  // --- 🎯 MISSIONS (CRUD) ---
  @Post('missions')
  createMission(@Body() createMissionDto: CreateMissionDto) {
    return this.adminService.createMission(createMissionDto);
  }

  @Get('missions')
  getAllMissions() {
    return this.adminService.getAllMissions();
  }

  @Patch('missions/:id')
  updateMission(
    @Param('id') id: string,
    @Body() data: Partial<CreateMissionDto>,
  ) {
    return this.adminService.updateMission(id, data);
  }

  @Delete('missions/:id')
  deleteMission(@Param('id') id: string) {
    return this.adminService.deleteMission(id);
  }

  // --- 💲 COMMISSION RULES (CRUD) ---
  @Post('commission-rules')
  createCommissionRule(@Body() createDto: CreateCommissionRuleDto) {
    return this.adminService.createCommissionRule(createDto);
  }

  /**
   * Liste les règles de commission. Le paramètre `target` permet de filtrer
   * les commissions destinées aux utilisateurs ou aux commerçants. Exemple :
   * /admin/commission-rules?target=MERCHANT
   */
  @Get('commission-rules')
  getCommissionRules(@Query('target') target?: 'USER' | 'MERCHANT') {
    return this.adminService.getCommissionRules(target);
  }

  @Patch('commission-rules/:id')
  updateCommissionRule(
    @Param('id') id: string,
    @Body() updateDto: UpdateCommissionRuleDto,
  ) {
    return this.adminService.updateCommissionRule(id, updateDto);
  }

  @Delete('commission-rules/:id')
  deleteCommissionRule(@Param('id') id: string) {
    return this.adminService.deleteCommissionRule(id);
  }

  // --- 📨 SUPPORT / TICKETS ---
  /**
   * Récupère toutes les demandes de support envoyées par les utilisateurs ou
   * commerçants. Ces demandes sont généralement créées via l'API /requests
   * côté client. Elles sont renvoyées triées du plus récent au plus ancien.
   */
  @Get('requests')
  getRequests() {
    return this.adminService.getAllRequests();
  }

  /**
   * Marque une demande comme résolue. Cela supprime la demande de la liste
   * des tickets ouverts et envoie une notification au demandeur pour lui
   * signaler que sa requête a été traitée.
   */
  @Patch('requests/:id/resolve')
  resolveRequest(@Param('id') id: string) {
    return this.adminService.resolveRequest(id);
  }

  // --- ✨ GAMIFICATION ---
  @Get('gamification/stats')
  getGamificationStats() {
    return this.adminService.getGamificationStats();
  }

  @Get('gamification/levels')
  getGamificationLevels() {
    return this.adminService.getGamificationLevels();
  }

  @Get('gamification/user-progressions')
  getUserProgressions() {
    return this.adminService.getUserProgressions();
  }

  // --- ⭐ XP RULES (CRUD) ---
  @Post('gamification/xp-rules')
  createXpRule(@Body() createXpRuleDto: CreateXpRuleDto) {
    return this.adminService.createXpRule(createXpRuleDto);
  }

  /**
   * Liste les règles d'XP. Vous pouvez passer le paramètre `role` dans
   * la requête pour filtrer les règles destinées aux utilisateurs ou aux
   * commerçants. Exemple : /admin/gamification/xp-rules?role=MERCHANT
   */
  @Get('gamification/xp-rules')
  getXpRules(@Query('role') role?: 'USER' | 'MERCHANT') {
    return this.adminService.getXpRules(role);
  }

  @Patch('gamification/xp-rules/:id')
  updateXpRule(
    @Param('id') id: string,
    @Body() updateXpRuleDto: UpdateXpRuleDto,
  ) {
    return this.adminService.updateXpRule(id, updateXpRuleDto);
  }

  @Delete('gamification/xp-rules/:id')
  deleteXpRule(@Param('id') id: string) {
    return this.adminService.deleteXpRule(id);
  }

  @Post('gamification/level-rules')
  createLevelRule(@Body() createLevelRuleDto: CreateLevelRuleDto) {
    return this.adminService.createLevelRule(createLevelRuleDto);
  }

  /**
   * Liste les règles de niveau. Vous pouvez passer le paramètre `role` pour
   * filtrer les règles destinées aux utilisateurs ou aux commerçants.
   */
  @Get('gamification/level-rules')
  getLevelRules(@Query('role') role?: 'USER' | 'MERCHANT') {
    return this.adminService.getLevelRules(role);
  }

  @Patch('gamification/level-rules/:id')
  updateLevelRule(
    @Param('id') id: string,
    @Body() updateLevelRuleDto: UpdateLevelRuleDto,
  ) {
    return this.adminService.updateLevelRule(id, updateLevelRuleDto);
  }
  @Get('gamification/rankings')
  getGlobalRanking() {
    return this.adminService.getGlobalRanking();
  }

  @Delete('gamification/level-rules/:id')
  deleteLevelRule(@Param('id') id: string) {
    return this.adminService.deleteLevelRule(id);
  }
  @Get('gamification/rankings/weekly')
  getWeeklyRanking() {
    return this.adminService.getWeeklyRanking();
  }

  // --- 🛡️ IDENTITY VERIFICATION ---
  // MISE À JOUR: La route des vérifications en attente
  @Get('identity/pending')
  getPendingVerifications(@Query('role') role: 'USER' | 'MERCHANT' = 'USER') {
    // Accepte un paramètre 'role'
    return this.adminService.getPendingVerifications(role);
  }

  @Patch('identity/:id/approve')
  approveVerification(@Param('id') id: string) {
    return this.adminService.approveVerification(id);
  }

  @Patch('identity/:id/reject')
  rejectVerification(
    @Param('id') id: string,
    @Body() rejectDto: RejectVerificationDto,
  ) {
    return this.adminService.rejectVerification(id, rejectDto.reason);
  }
  @Get('withdrawals/pending')
  getPendingWithdrawals() {
    return this.adminService.getPendingWithdrawals();
  }

  @Patch('withdrawals/:id/approve')
  approveWithdrawal(@Param('id') id: string) {
    return this.adminService.approveWithdrawal(id);
  }

  @Patch('withdrawals/:id/reject')
  rejectWithdrawal(@Param('id') id: string, @Body('reason') reason: string) {
    if (!reason) {
      throw new BadRequestException('Un motif de rejet est requis.');
    }
    return this.adminService.rejectWithdrawal(id, reason);
  }

  // --- 📈 UTILISATEURS & TRANSACTIONS STATS ---
  /**
   * Récupère les statistiques agrégées par utilisateur (somme envoyée, reçue et nombre de transactions).
   * Accessible uniquement aux administrateurs.
   */
  @Get('users/stats')
  getUserStats() {
    return this.adminService.getUserStats();
  }

  /**
   * Retourne toutes les transactions de la plateforme avec les informations sur l'expéditeur et le destinataire.
   * Accessible uniquement aux administrateurs.
   */
  @Get('transactions')
  getAllTransactions() {
    return this.adminService.getAllTransactions();
  }

  // --- 📉 ANALYSE CHURN, CONVERSION & RÉTENTION ---
  /**
   * Statistiques de churn (attrition) pour l'ensemble des utilisateurs.
   */
  @Get('stats/churn')
  getChurnStats() {
    return this.adminService.getChurnStats();
  }

  /**
   * Statistiques de conversion pour l'entonnoir utilisateurs.
   */
  @Get('stats/conversion')
  getConversionStats() {
    return this.adminService.getConversionStats();
  }

  /**
   * Statistiques de rétention pour les utilisateurs.
   */
  @Get('stats/retention')
  getRetentionStats() {
    return this.adminService.getRetentionStats();
  }

  // --- 💬 MESSAGERIE ---
  /**
   * Liste des conversations entre l'admin et les utilisateurs avec aperçu du dernier message.
   */
  @Get('messages')
  getMessagesConversations() {
    return this.adminService.getMessagesConversations();
  }

  /**
   * Récupère l'historique des messages avec un utilisateur donné.
   */
  @Get('messages/:userId')
  getMessagesByUser(@Param('userId') userId: string) {
    return this.adminService.getMessagesByUser(userId);
  }

  /**
   * Envoie un message à un utilisateur depuis l'admin.
   */
  @Post('messages/:userId')
  sendMessageToUser(
    @Param('userId') userId: string,
    @Body('content') content: string,
  ) {
    return this.adminService.sendMessageToUser(userId, content);
  }

  // --- ✅ ACCOUNT STATUS MANAGEMENT ---
  /**
   * Met à jour le statut d'un utilisateur (actif, inactif, suspendu, en attente).
   * Permet à l'admin de désactiver ou suspendre un compte utilisateur. Le corps
   * de la requête doit contenir un champ `status` avec l'une des valeurs
   * autorisées : 'active', 'inactive', 'pending' ou 'suspended'.
   */
  @Patch('users/:id/status')
  updateUserStatus(@Param('id') id: string, @Body('status') status: string) {
    return this.adminService.updateUserStatus(id, status);
  }

  /**
   * Met à jour le statut d'un commerçant (actif, inactif ou en attente).
   * Le corps de la requête doit contenir un champ `status` avec l'une des
   * valeurs autorisées : 'active', 'inactive' ou 'pending'.
   */
  @Patch('merchants/:id/status')
  updateMerchantStatus(
    @Param('id') id: string,
    @Body('status') status: string,
  ) {
    return this.adminService.updateMerchantStatus(id, status);
  }
  @Get('suggestions')
  async listSuggestions() {
    return this.adminService.listSuggestions();
  }

  // ➜ Approuver une suggestion (crée un Merchant + passe status=approved)
  @Patch('suggestions/:id/approve')
  async approveSuggestion(@Param('id') id: string) {
    return this.adminService.approveSuggestion(id);
  }

  // ➜ Rejeter une suggestion (status=rejected + raison optionnelle)
  @Patch('suggestions/:id/reject')
  async rejectSuggestion(
    @Param('id') id: string,
    @Body() dto: RejectSuggestionDto,
  ) {
    return this.adminService.rejectSuggestion(id, dto.reason);
  }
  @Delete('suggestions/:id')
  async deleteSuggestion(@Param('id') id: string) {
    return this.adminService.deleteSuggestion(id);
  }
}
