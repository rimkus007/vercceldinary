// Fichier : backend/prisma/backfillReferrals.ts

import { PrismaClient } from '@prisma/client';
import { nanoid } from 'nanoid';

const prisma = new PrismaClient();

async function main() {
  console.log(
    'Début de la mise à jour des utilisateurs sans code de parrainage...',
  );

  // On cherche tous les utilisateurs qui n'ont pas encore de code
  const usersToUpdate = await prisma.user.findMany({
    where: {
      referralCode: null,
    },
  });

  if (usersToUpdate.length === 0) {
    console.log(
      'Tous les utilisateurs ont déjà un code de parrainage. Aucune action requise.',
    );
    return;
  }

  console.log(`Mise à jour de ${usersToUpdate.length} utilisateur(s)...`);

  // On boucle sur chaque utilisateur et on lui assigne un nouveau code unique
  for (const user of usersToUpdate) {
    const newReferralCode = `DINARY-${nanoid(6).toUpperCase()}`;
    await prisma.user.update({
      where: { id: user.id },
      data: { referralCode: newReferralCode },
    });
    console.log(` -> Code ${newReferralCode} assigné à ${user.email}`);
  }

  console.log('Mise à jour terminée avec succès !');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
