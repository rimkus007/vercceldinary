-- AlterTable
ALTER TABLE "public"."Merchant" ADD COLUMN     "isSuggestion" BOOLEAN NOT NULL DEFAULT false;
