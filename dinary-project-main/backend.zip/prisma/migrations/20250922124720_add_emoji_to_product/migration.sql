-- AlterTable
ALTER TABLE "public"."Product" ADD COLUMN     "emoji" TEXT;
