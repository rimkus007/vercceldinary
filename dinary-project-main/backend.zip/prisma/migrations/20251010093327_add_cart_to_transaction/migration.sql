-- AlterTable
ALTER TABLE "public"."Transaction" ADD COLUMN     "cart" JSONB;
