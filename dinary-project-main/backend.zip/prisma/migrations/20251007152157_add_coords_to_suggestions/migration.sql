-- AlterTable
ALTER TABLE "public"."MerchantSuggestion" ADD COLUMN     "latitude" DOUBLE PRECISION,
ADD COLUMN     "longitude" DOUBLE PRECISION;
