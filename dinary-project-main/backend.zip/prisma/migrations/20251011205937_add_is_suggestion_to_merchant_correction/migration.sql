-- AlterTable
ALTER TABLE "public"."Merchant" ALTER COLUMN "isSuggestion" DROP NOT NULL;
